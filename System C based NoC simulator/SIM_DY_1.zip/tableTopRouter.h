#ifndef TOP_R
#define TOP_R

#include "tableTopModule.h"
#include "tableNetworkInterface.h"

ofstream fp_in_payload_lat_thr;

SC_MODULE(top_4_router)
{
	/** Arrays' first dim. are routers, second - links and third - vc **/

	int total_core;

	sc_in<bool> ce , clk4x;

	sc_in<bool> clk, clr;

	sc_in<sc_uint<ADD_BIT_LEN> > *current_address_r;

	sc_signal<sc_uint<FLIT_LEN> >  *data_in_core_r;

	sc_in<bool> **full_in_core_vc_r;
	
	sc_signal<sc_uint<FLIT_LEN> > *data_out_core_r;
	
	sc_signal<bool> **full_out_core_vc_r;
	
	sc_signal<bool> *reset_r;

	sc_signal< sc_uint<FLIT_LEN> > **data_out_link_r, inval;
	
	sc_signal<bool> ***full_out_link_vc_r;

	sc_signal<double> *total_latency, total_latency_network, avg_latency;

	sc_signal<int>  *suc_count;

	sc_signal<int> *packet_nb;

	sc_signal<int> total_packet_sent, throughput_network;

	sc_signal<bool> gnd,vdd;
	
	sc_signal< sc_uint<FLIT_LEN> > **temp_outval_r;

	sc_signal<bool>	***false_val_r;
	
	sc_signal<int> **bufferStatus, zero;	

	int temp;
	double temp_lat;

	top_module **r;

	network_interface **ni;

	int i, j, count, router, link, vc, local_link;

	void thr_cal_process()
	{	
		temp = 0;
		for(router = 0;router < total_core; router++)
			temp += suc_count[router];
		throughput_network.write(temp);
	}

	void lat_cal_process()
	{	
		temp_lat = 0;
		for(router = 0;router < total_core;router++)
 			temp_lat += total_latency[router];
		total_latency_network.write(temp_lat);
	}

	void calc_packet_sent_process()
	{	
		temp = 0;
		for(router = 0;router < total_core;router++)
			temp += packet_nb[router];
		total_packet_sent.write(temp);
	}

	void calc_avg_lat_process()
	{	
		avg_latency = total_latency_network/(throughput_network*CLK_PERIOD);		//*** in terms of cycles.
	}
	
	void print_lat_thr_cal_process()
	{	
		fp_in_payload_lat_thr.seekp(0);
		
		fp_in_payload_lat_thr << "Avg_Latency = " << avg_latency <<"\nTotal_packets_sent = "<< total_packet_sent <<
		"\nTotal_packets_received wtw = " << throughput_network << endl;
	}

	SC_HAS_PROCESS(top_4_router);	
	top_4_router(sc_module_name nm, int total, char *folder):sc_module(nm)
	{
		total_core = total;
		inval.write("0b001100000000000000000000000000000");
		gnd.write(false);
		vdd.write(true);
		
		char str1[50];
		sprintf(str1,"%snetwork.txt",folder);
		//cout<<"Here in t4r 1"<<endl;
		fp_in_payload_lat_thr.open(str1);

        	current_address_r = new sc_in<sc_uint<ADD_BIT_LEN> >[MAX_ROUTER];
        	reset_r = new sc_signal<bool>[MAX_ROUTER];
        	data_out_link_r = new sc_signal< sc_uint<FLIT_LEN> >* [MAX_ROUTER];
        	full_out_link_vc_r = new sc_signal<bool>**[MAX_ROUTER];
        	data_in_core_r = new sc_signal<sc_uint<FLIT_LEN> >[total_core];
        	data_out_core_r = new sc_signal<sc_uint<FLIT_LEN> >[total_core];
        	full_in_core_vc_r = new sc_in<bool> *[total_core];
        	full_out_core_vc_r = new sc_signal<bool> *[total_core];
        	temp_outval_r = new sc_signal< sc_uint<FLIT_LEN> > *[MAX_ROUTER];
        	false_val_r = new sc_signal<bool> **[MAX_ROUTER];        	
        	
        	for(router = 0; router < total_core; router++)
        	{
            		full_in_core_vc_r[router] = new sc_in<bool>[MAX_VC];
	            	full_out_core_vc_r[router] = new sc_signal<bool>[MAX_VC];
        	}
        	
        	for(router = 0; router < MAX_ROUTER; router++)
        	{
        		int link_count = router_param[router][MAX_LINK + MAX_CORE];
        		
        		data_out_link_r[router] = new sc_signal<sc_uint<FLIT_LEN> >[link_count];
        		full_out_link_vc_r[router] = new sc_signal<bool> *[link_count];
        		temp_outval_r[router] = new sc_signal< sc_uint<FLIT_LEN> > [MAX_LINK];
        		false_val_r[router] = new sc_signal<bool> *[MAX_LINK];        		
        		
        		for( link = 0; link < link_count; link++ )
        			full_out_link_vc_r[router][link] = new sc_signal<bool> [MAX_VC];
        		for( link = 0; link < MAX_LINK; link++ )
        			false_val_r[router][link] = new sc_signal<bool> [MAX_VC];
        	}
        	
        	bufferStatus = new sc_signal<int> *[MAX_ROUTER];
		for(router = 0; router < MAX_ROUTER; router++)
			bufferStatus[router] = new sc_signal<int>[MAX_LINK];
        	
        	total_latency = new sc_signal<double>[total_core];
        	suc_count = new sc_signal<int>[total_core];
        	packet_nb = new sc_signal<int>[total_core];

        	ni = new network_interface *[total_core];
		
		char str[6];
		int core;
		for(core = 0; core < total_core; core++)
		{
			//cout<<"in top_4_router \n";
			sprintf(str,"ni(%0d)",core);
			ni[core]=new network_interface(str);

			ni[core]->packet_in(data_out_core_r[core]);
			
			//*** Find the router to which this core is connected.
			for(router = 0, local_link = 0; router < MAX_ROUTER*MAX_CORE && 
				router_param[router/MAX_CORE][MAX_LINK + (local_link % MAX_CORE) ] != core + 1 ; local_link++, router++);			
			router /= MAX_CORE;
			//cout << "Core: "<<core<<"  Router:  "<<router<<endl;
			
			ni[core]->reset(reset_r[router]);
			ni[core]->clk_core(clk);
			ni[core]->packet_out(data_in_core_r[core]);
			ni[core]->temp_total_latency(total_latency[core]);
			ni[core]->temp_suc_count(suc_count[core]);
			ni[core]->packet_number1(packet_nb[core]);

			for(vc = 0; vc < MAX_VC; vc++)
				ni[core]->full_req[vc](full_out_core_vc_r[core][vc]);
		}
		//cout<<"Here in t4r 2"<<endl;
		//cout<<"Here to check"<<endl;
		r = new top_module* [MAX_ROUTER];
		for(router = 0; router < MAX_ROUTER; router++)
		{
		//cout<<"start: Router number = "<<router<<endl;
	
			sprintf(str,"r(%0d)",router);
			sprintf(str1,"%spower_result/router%0d.scr",folder,router+1);
			//cout<<"link count = "<<router_param[router][MAX_LINK + MAX_CORE]<<" core_count ="<<router_param[router][MAX_LINK + MAX_CORE + 1]<<" buffersize = "<<router_param[router][MAX_LINK + MAX_CORE + 2]<<endl;
            int link_count = router_param[router][MAX_LINK + MAX_CORE];
			int core_count = router_param[router][MAX_LINK + MAX_CORE + 1];
			int buffer_size = router_param[router][MAX_LINK + MAX_CORE + 2];
			
			char str_temp[50];
			//cout<<"Till here in loop 2.1.1"<<endl;
			r[router] = new top_module(str, str1, link_count, core_count, buffer_size, folder, router);
			//cout<<"After init router"<<endl;
			r[router]->clk4x(clk4x);
    			r[router]->ce(ce);
    			r[router]->clk(clk);
    			r[router]->clr(clr);
    			r[router]->reset(reset_r[router]);
    			r[router]->current_address(current_address_r[router]);
    			//cout<<"current_address    "<<current_address_r[router]<< "\trouter    " <<router<<endl;
    			
    			if( routingAlgo == OE_NOP )
	    			for( link = 0; link < MAX_LINK; link++)
					r[router]->bufferStatus[link]( bufferStatus[router][link] );
			else	{
				r[router]->bufferStatus[0]( bufferStatus[router][0] );
				r[router]->outLinkBufferStatus[0][0]( zero );

				//cout<<"end: Router number = "<<router<<endl;
			}
    		//cout<<"Here in t4r 2.1"<<endl;	
			for(local_link = 0; local_link < core_count; local_link++)
			{
				//*** Read core_ID of the core connected to a router from its conn. info.
				int dest_core = router_param[router][MAX_LINK + local_link];

				r[router]->data_in_link[link_count + local_link]( data_in_core_r[dest_core - 1] );
				r[router]->data_out_link[link_count + local_link]( data_out_core_r[dest_core - 1] );

				for(vc = 0; vc < MAX_VC; vc++)	{
					r[router]-> full_in_link_vc[link_count + local_link][vc](full_in_core_vc_r[dest_core - 1][vc]);
					r[router]-> full_out_link_vc[link_count + local_link][vc](full_out_core_vc_r[dest_core - 1][vc]);
				}
			}
			//cout<<"Here in t4r 3"<<endl;
            		//cout <<"\nHost Router:  "<<router+1 << endl;
			for( link = 0; link < link_count; link++ )
			{
				int dest_router = router_param[router][link];

				//cout<<"Host_link:  "<<link+1<<"\tDest_router: "<< dest_router <<"  ";
				if( dest_router > 0)	{
					
					r[router]-> data_out_link[link]( data_out_link_r[router][link] );
					for(vc = 0;vc < MAX_VC;vc++)
						r[router]->full_out_link_vc[link][vc]( full_out_link_vc_r[router][link][vc] );
					
					int dest_link;
					for(dest_link = 0; router_param[dest_router - 1][dest_link] != router + 1 && dest_link < MAX_LINK; dest_link++ );
					//cout << "Dest_link: "<<dest_link+1<<endl;
				
					/* Check if the connection among the routers is unidirectional */
					if( dest_link < MAX_LINK )	{
						r[router]-> data_in_link[link]( data_out_link_r[dest_router-1][dest_link] );
						
						if( routingAlgo == OE_NOP )
							for( int linkNum = 0; linkNum < MAX_LINK; linkNum++ )	{
								int adj_router = router_param[dest_router - 1][linkNum];
								if( adj_router > 0 )	{
									int adjLink;
									for(adjLink = 0; router_param[adj_router - 1][adjLink] != dest_router && adjLink < MAX_LINK; adjLink++ );
									if( adjLink < MAX_LINK )
										r[router]->outLinkBufferStatus[link][linkNum]( bufferStatus[adj_router - 1][adjLink] );
									else	r[router]->outLinkBufferStatus[link][linkNum]( zero );
								}
								else	r[router]->outLinkBufferStatus[link][linkNum]( zero );
							}
						
						for(vc = 0; vc < MAX_VC; vc++)
							r[router]->full_in_link_vc[link][vc]( full_out_link_vc_r[dest_router-1][dest_link][vc] );
					}
					else	{
						r[router]-> data_in_link[link]( inval );
						if( routingAlgo == OE_NOP )
							for( int linkNum = 0; linkNum < MAX_LINK; linkNum++ )
								r[router]->outLinkBufferStatus[link][linkNum]( zero );
												
						for(vc = 0;vc < MAX_VC;vc++)
							r[router]->full_in_link_vc[link][vc]( gnd );
					}
				}
				else	{
					r[router]-> data_in_link[link]( inval );
					if( routingAlgo == OE_NOP )
						for( int linkNum = 0; linkNum < MAX_LINK; linkNum++ )
							r[router]->outLinkBufferStatus[link][linkNum]( zero );
					
					r[router]-> data_out_link[link]( temp_outval_r[router][link] );

					for(vc = 0;vc < MAX_VC;vc++)
					{
						r[router]->full_in_link_vc[link][vc]( gnd );
						r[router]->full_out_link_vc[link][vc]( false_val_r[router][link][vc] );
					}
				}
			}
        	}

		SC_METHOD(thr_cal_process);
		for(router = 0; router < total_core; router++)
			sensitive <<  suc_count[router];

		SC_METHOD(lat_cal_process);
		for(router = 0; router < total_core; router++)
			sensitive << total_latency[router];

		SC_METHOD(calc_packet_sent_process);
		for(router = 0; router < total_core; router++)
			sensitive << packet_nb[router];

		SC_METHOD(calc_avg_lat_process);
		sensitive << total_latency_network << throughput_network;
		
		SC_METHOD(print_lat_thr_cal_process);
		sensitive <<  total_latency_network << throughput_network << total_packet_sent;
	}

	~top_4_router()			//*** Destructor
	{
		for(router = 0; router < total_core; router++)
            		delete ni[router];
        	delete[] ni;
		
		for(router = 0; router < MAX_ROUTER; router++)	
		{
			delete r[router];
			delete[] data_out_link_r[router];
        		delete[] full_out_link_vc_r[router];
        		delete[] temp_outval_r[router];
        		for( link = 0; link < MAX_LINK; link++)
        			delete[] false_val_r[router][link];
        		delete[] false_val_r[router];
		}
		delete[] temp_outval_r;
		delete[] false_val_r;
		delete[] r;
		delete[] data_out_link_r;
		delete[] full_out_link_vc_r;	
        	delete[] data_in_core_r;
        	delete[] data_out_core_r;

        	for(router = 0;router < total_core;router++)	{
            		delete[] full_in_core_vc_r[router];
            		delete[] full_out_core_vc_r[router];
        	}
		for(router = 0; router < MAX_ROUTER; router++)
			delete[] bufferStatus[router];
        	delete[] bufferStatus;
        	
        	delete[] full_in_core_vc_r;
        	delete[] full_out_core_vc_r;
        	delete[] current_address_r;
        	delete[] reset_r;
        	delete[] total_latency;
        	delete[] suc_count;
        	delete[] packet_nb;
	}
};

#endif

