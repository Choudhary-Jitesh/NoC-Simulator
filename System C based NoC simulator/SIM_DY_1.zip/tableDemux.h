#ifndef dem
#define dem

#include "configParam.h"

SC_MODULE(demux_16)
{
	int total_link;
	
	sc_in<bool> ip;
	sc_in<sc_uint<LINK_BIT + VC_BIT> > sel;
	sc_out<bool> *op;

	void demux_16_process()
	{
        	for(int count = 0; count < MAX_VC*(total_link); count++)	//*** Necessary to make other o/ps false.
			op[count].write(false);
		
		int temp = sel.read();
		if(temp < MAX_VC*(total_link) )
	    		op[temp].write( ip.read() );
	    	else cout <<"Error"<<endl;
	}

	SC_HAS_PROCESS(demux_16);	
	demux_16(sc_module_name nm, int total): sc_module(nm), total_link(total)
	{   //cout<<"here in demux\n";
		op = new sc_out<bool>[MAX_VC*(total_link)];
		
		SC_METHOD(demux_16_process);
			sensitive << sel << ip;
	}

	~demux_16()			//*** destructor
	{
		delete[] op;
	}			
};

#endif
