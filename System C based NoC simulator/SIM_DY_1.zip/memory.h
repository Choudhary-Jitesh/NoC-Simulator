#ifndef MEM
#define MEM

#include "configParam.h"

SC_MODULE(memory)
{
	sc_in<bool> reset;
	sc_in_clk rd_clk, wr_clk;		
	sc_in<sc_uint<BUFFER_BIT_LEN> > rd_add, wr_add;
	sc_in<bool> rd_en, wr_en;
	sc_in<sc_uint<FLIT_LEN> > data_in;
	sc_out<sc_uint<FLIT_LEN> > data_out;
	sc_uint<FLIT_LEN> mem[MAX_BUFFER_LEN];
	
	void write_process() 
	{
		if(wr_en.read()==true)
			mem[(int)wr_add.read()] = data_in.read();
	}
	
	void read_process()
	{	
		if(reset.read()==true)		
			data_out.write(INVALID);	//*** This value makes both eop(BIT 30) and bop(BIT 29) HIGH thus making it an invalid data.
		else
		{
			if(rd_en.read()==true)
				data_out.write(mem[(int)rd_add.read()]);
			else
				data_out.write(INVALID);
		}
	}
	
	SC_CTOR(memory)
	{		
		SC_METHOD(write_process);
			sensitive << wr_clk.pos();

		SC_METHOD(read_process);
			sensitive << rd_clk.pos();
	}	
};

#endif
