#ifndef rrr_mod
#define rrr_mod

#include "arbiter.h"				// No. of i/p and o/p ports is MAX_VC each.
#include "tableArbiterDynamic.h"		// No. of i/p and o/p ports is MAX_LINK1 each.
#include "d_ff/dff_synch_reset.h"

SC_MODULE(round_robin_req)
{
	int total_link;
	
	sc_in<bool> reset;
	sc_in_clk rd_clk;
	sc_in<bool> all_vc_not_busy;
	sc_in<bool> **req_;
	sc_out<bool> *g;

	sc_signal<bool> vdd, *t/*[MAX_LINK1]*/, **nreq_, *req_b/*[MAX_LINK1]*/, *req, *gnt, **g_latched, *g_b/*[MAX_LINK1]*/, **g_int;

	DFF_asynch_clr_false **dff_rq;
	arbiter **rr_b;
	arbiter_dynamic *rr_b_dyn;
	dff_synch_reset **dff_synch;

	void assign_process()
	{
		for(int count = 0; count < total_link; count++)
			for(int j = 0; j < MAX_VC; j++)
				nreq_[count][j].write(!req_[count][j].read());
	}

	void assign_req_process()
	{
		for(int count = 0; count < total_link; count++)
			for(int j = 0; j < MAX_VC; j++)
				req[count*MAX_VC + j].write( req_[count][j].read() & (!g_latched[count][j].read()) );
	}

	void assign_req_b_process()
	{
		bool temp;   
		
		// Out of these, only total_link ports will be used. So, make other ports false. 
		for(int count = 0; count < MAX_LINK1; count++)
			req_b[count].write( false );
		     		
        	for(int count = 0; count < total_link; count++)
        	{
            		temp = 0;
            		for(int j = 0; j < MAX_VC; j++)
                		temp |= req[count*MAX_VC+j];
                		
           		req_b[count].write( temp );
        	}        	
	}

	void assign_t_process()
    	{
        	for(int count = 0; count < MAX_LINK1; count++)
            		t[count].write( all_vc_not_busy.read() & req_b[count].read() );
	}

    	void assign_g_process()
    	{
                for(int count = 0; count < total_link; count++)
			for(int j = 0; j < MAX_VC; j++)
                		g[count*MAX_VC + j].write( gnt[count*MAX_VC + j].read() & g_b[count].read() );
    	}

    	SC_HAS_PROCESS(round_robin_req);
	round_robin_req(sc_module_name nm, int total):sc_module(nm), total_link(total)
    	{
    		vdd.write(true);
    		//cout<<"Inside rrq"<<endl;
    		int count, j;
		char str[15];

		t = new sc_signal<bool>[MAX_LINK1];	
		req_b = new sc_signal<bool>[MAX_LINK1];	
		g_b = new sc_signal<bool>[MAX_LINK1];	
		req = new sc_signal<bool>[MAX_VC * (total_link)];
		gnt = new sc_signal<bool>[MAX_VC * (total_link)];
		g = new sc_out<bool>[MAX_VC * (total_link)];
		req_ = new sc_in<bool> *[total_link];
		nreq_ = new sc_signal<bool> *[total_link];
		g_latched = new sc_signal<bool> *[total_link];
		g_int = new sc_signal<bool> *[total_link];

		for(j = 0; j < total_link; j++)
		{
			req_[j] = new sc_in<bool>[MAX_VC];
			nreq_[j] = new sc_signal<bool>[MAX_VC];
			g_latched[j] = new sc_signal<bool>[MAX_VC];
			g_int[j] = new sc_signal<bool>[MAX_VC];	
		}
		
		dff_rq = new DFF_asynch_clr_false *[MAX_VC * (total_link)];
		rr_b = new arbiter *[total_link];
		dff_synch = new dff_synch_reset *[MAX_VC * (total_link)];
		//cout<<"Rchd here in rrq 1"<<endl;
        	for(count = 0; count < total_link; count++)
        	{
        		for(j = 0; j < MAX_VC; j++)
            		{
				sprintf(str,"dff_rq(%0d)", count*MAX_VC + j);
				dff_rq[count*MAX_VC + j] = new DFF_asynch_clr_false(str);

                		dff_rq[count*MAX_VC + j]->D(vdd);
				dff_rq[count*MAX_VC + j]->clk(g_int[count][j]);
				dff_rq[count*MAX_VC + j]->clr(nreq_[count][j]);
				dff_rq[count*MAX_VC + j]->Q(g_latched[count][j]);
			}
		}
		//cout<<"Rchd here in rrq 2"<<endl;

		for(count = 0; count < total_link; count++)
		{
			sprintf(str,"rr_b(%0d)", count);
			//cout<<"before arbiter count = "<<count<<endl;
			rr_b[count] = new arbiter(str);
			//cout<<"after arbiter count"<<endl;
            		rr_b[count]->reset(reset);
            		rr_b[count]->clk(rd_clk);

            		for(j = 0; j < MAX_VC; j++)
            		{
            			//cout<<"inside loop j= "<<j<<endl;
				rr_b[count]->req[j](req[count*MAX_VC+j]);
				//cout<<"after line 1 in loop with j="<<j<<endl;
				rr_b[count]->gnt[j](gnt[count*MAX_VC+j]);
			}
			//cout<<"After loop count = "<<count<<endl;
		}
		
		rr_b_dyn = new arbiter_dynamic("rr_b_dyn");
				//cout<<"Rchd here in rrq 3"<<endl;

        	rr_b_dyn->reset(reset);
        	rr_b_dyn->clk(rd_clk);
        	for(j = 0; j < MAX_LINK1; j++)		
        	{
           		rr_b_dyn->req[j](t[j]);
			rr_b_dyn->gnt[j](g_b[j]);
        	}

		for(count = 0; count < total_link; count++)
		{
			for(j = 0; j < MAX_VC; j++)
            		{
				sprintf(str,"dff_synch(%0d)", count*MAX_VC + j);
				dff_synch[count*MAX_VC + j] = new dff_synch_reset(str);

				dff_synch[count*MAX_VC + j]->d(g[count*MAX_VC+j]);
				dff_synch[count*MAX_VC + j]->clk(rd_clk);
				dff_synch[count*MAX_VC + j]->reset(reset);
				dff_synch[count*MAX_VC + j]->q(g_int[count][j]);
            		}
        	}


       		SC_METHOD(assign_process);
            	for(count = 0; count < total_link; count++)
                	for(j = 0; j < MAX_VC; j++)
                    		sensitive << req_[count][j];

        	SC_METHOD(assign_req_process);
            	sensitive << all_vc_not_busy;
            	for(count = 0; count < total_link; count++)
                	for(j = 0; j < MAX_VC; j++)
                    		sensitive << req_[count][j] << g_latched[count][j];

        	SC_METHOD(assign_req_b_process);
            	for(count = 0; count < total_link; count++)
                	for(j = 0; j < MAX_VC; j++)
                    		sensitive << req[count*MAX_VC+j];

        	SC_METHOD(assign_t_process);
		sensitive << all_vc_not_busy;
		for(count = 0; count < total_link; count++)
                	sensitive << req_b[count];

        	SC_METHOD(assign_g_process);
            	for(count = 0; count < total_link; count++)
            		sensitive << g_b[count];
            	for(count = 0; count < total_link; count++)
                	for(j = 0; j < MAX_VC; j++)
                    		sensitive << gnt[count*MAX_VC+j];
   	}

	~round_robin_req()					//*** destructor
	{
		delete[] t;
		delete[] req_b;
		delete[] g_b;
		for(int count = 0; count < MAX_VC * (total_link); count++)
		{
			delete dff_rq[count];
			delete dff_synch[count];
		}
		delete[] dff_rq;
		delete[] dff_synch;
		
		delete rr_b_dyn;		
		
		delete[] req;
		delete[] g;
		delete[] gnt;
		for(int count = 0; count < total_link; count++)
		{
			delete[] req_[count];
			delete[] nreq_[count];
			delete[] g_int[count];
			delete[] g_latched[count];
			delete rr_b[count];
		}
		delete[] rr_b;
		delete[] req_;
		delete[] nreq_;
		delete[] g_int;
		delete[] g_latched;
	}
};

#endif
