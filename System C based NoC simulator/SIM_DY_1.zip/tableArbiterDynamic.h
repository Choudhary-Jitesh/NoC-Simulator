#ifndef arb_mod_dyn
#define arb_mod_dyn

#include "tablePriorityEncoderDynamic.h"
#include "d_ff/DFF_asynch_clr_false.h"
#include "falling_edge_pulse_generator.h"

SC_MODULE(arbiter_dynamic)
{
	sc_in<bool> *req;//[MAX_LINK1];
	sc_in<bool> reset;
	sc_out<bool> *gnt;//[MAX_LINK1];
	sc_in_clk clk;

	sc_signal<bool> en0_0, *en;//[MAX_LINK1];
	sc_signal<bool> **out;//[MAX_LINK1][MAX_LINK1];
	sc_signal<bool> high, low;
	sc_signal<bool> *gnt_pulse, *clr_en;//[MAX_LINK1], clr_en[MAX_LINK1];
	sc_signal<bool> clr_en0_reset;
	sc_signal<bool> en0_reset;

	priority_encoder_dyn **pe;//[MAX_LINK1];

	DFF_asynch_clr_false **d;//[MAX_LINK1 + 1];

	falling_edge_pulse_generator **pg;//[MAX_LINK1];

	sc_signal<bool> all_gnt_low;

	void arbiter_dynamic_process()
	{
		int count, j;
		bool gnt_temp;

		for(count = 0; count < (MAX_LINK1); count++)
		{
			gnt_temp = 0;

			for(j = 0; j < (MAX_LINK1); j++)
				gnt_temp |= out[j][(count + (MAX_LINK1) - j)%((MAX_LINK1))];

			gnt_temp &= 	( !reset.read() );

			gnt[count].write( gnt_temp );
		}

		gnt_temp = reset;
		for(count = 0; count < (MAX_LINK1); count++)
			gnt_temp |= en[count];
		clr_en0_reset.write( gnt_temp );
		
		for(int loop = 0; loop < MAX_LINK1; loop++)
		{		
			gnt_temp = reset;
			for(j = 0; j < MAX_LINK1; j++)
				if( j != loop )
					gnt_temp |= gnt_pulse[j];
			clr_en[loop].write( gnt_temp );
		}

		en0_0.write(all_gnt_low.read()|en[0].read());
	}

	void all_gnt_low_dynamic_process()	
	{
		bool temp = 0;
		for(int count = 0; count < (MAX_LINK1); count++)
			temp |= en[count];
		all_gnt_low.write(!temp);	
	}

	SC_CTOR(arbiter_dynamic)
	{   //cout<<"here in arbiter\n";
		int count, j;
		req = new sc_in<bool>[MAX_LINK1];
		gnt = new sc_out<bool>[MAX_LINK1];
		en = new sc_signal<bool>[MAX_LINK1];
		out = new sc_signal<bool>* [MAX_LINK1];
		for(count = 0; count < (MAX_LINK1); count++)	
			out[count] = new sc_signal<bool>[MAX_LINK1];
		gnt_pulse = new sc_signal<bool>[MAX_LINK1];
		clr_en = new sc_signal<bool>[MAX_LINK1];
		pe = new priority_encoder_dyn* [MAX_LINK1];
		d = new DFF_asynch_clr_false *[MAX_LINK1 + 1];
		pg = new falling_edge_pulse_generator *[MAX_LINK1];
		
		high.write(1);
		low.write(0);

		char str[6];
		for(count = 0; count < (MAX_LINK1); count++)
		{
			sprintf(str,"pe(%0d)",count);
			pe[count] = new priority_encoder_dyn(str);

			if(count == 0)
				pe[count]->en( en0_0 );
			else
				pe[count]->en( en[count] );

			pe[count]->reset(reset);
			pe[count]->clk(clk);

			for(j = 0; j < (MAX_LINK1); j++)
			{
				pe[count]->out_pe[j]( out[count][j] );
				pe[count]->in[j]( req[(j+count)%(MAX_LINK1)] );
			}
		}

		for(count = 0; count < (MAX_LINK1); count++)
		{
			sprintf(str,"pg(%0d)",count);
			pg[count] = new falling_edge_pulse_generator(str);

			pg[count]->reset(reset);
			pg[count]->clk(clk);
			pg[count]->gnt(gnt[count]);
			pg[count]->q0(gnt_pulse[count]);
		}

		d[0] = new DFF_asynch_clr_false("d(0)");

		d[0]->D(high);
		d[0]->clr(clr_en0_reset);
		d[0]->clk(clk);
		d[0]->Q(en0_reset);

		for(count = 1; count < MAX_LINK1 + 1; count++)
		{
			sprintf(str,"d(%0d)",count);
			d[count] = new DFF_asynch_clr_false(str);

			d[count]->D(gnt[count - 1]);
			d[count]->clr(low);
			d[count]->clk(clk);
			d[count]->Q(en[count - 1]);
		}
		
		SC_METHOD(arbiter_dynamic_process);
			sensitive << reset << all_gnt_low << en0_reset;
			for(count = 0; count < (MAX_LINK1); count++)
			{
				sensitive << en[count] << gnt[count] << gnt_pulse[count];
				for(j = 0; j < (MAX_LINK1); j++)
					sensitive << out[count][j];
			}

		SC_METHOD(all_gnt_low_dynamic_process);
			for(count = 0; count < (MAX_LINK1); count++)
				sensitive << en[count];

	}

	~arbiter_dynamic()		//*** Destructor
	{
		delete[] req;
		delete[] gnt;
		delete[] en;
		delete[] gnt_pulse;
		delete[] clr_en;
		for(int count = 0; count < (MAX_LINK1); count++)	{
			delete pg[count];
			delete pe[count];
			delete d[count];
			delete[] out[count];
		}
		delete[] out;
		delete d[MAX_LINK1];
		delete[] pg;
		delete[] pe;
		delete[] d;
	}
};

#endif
