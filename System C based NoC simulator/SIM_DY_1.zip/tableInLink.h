#ifndef IP_LINK_MOD
#define IP_LINK_MOD

#include "tableInChannel.h"

SC_MODULE(ip_link)
{
	int total_link;
    
	sc_in<bool> reset, rd_clk, wr_clk;
	sc_in<sc_uint<FLIT_LEN> > data_in;
	sc_in<sc_uint<ADD_BIT_LEN> > current_address;
	sc_in<bool> *rd_en;				//*** No. = MAX_VC * (total_link) * MAX_VC;
	sc_in<int> **outLinkBufferStatus;

	sc_out< sc_uint<FLIT_LEN> > data_out_vc[MAX_VC];	
	sc_out<bool> **req_l_vc;			//*** First arg. is for links and second is for VCs.
	sc_out<bool> tailer_vc[MAX_VC];			//*** total_link = NO. of Links + 1
	sc_out<bool> full_vc[MAX_VC];
	sc_out<bool> rok_vc[MAX_VC];
	sc_out<int> localBufferStatus[MAX_VC];

	sc_signal<bool> rd_en_vc[MAX_VC];
	sc_signal<bool> wr_en_vc[MAX_VC];
	sc_signal<bool> empty_vc[MAX_VC];
	sc_signal<bool> sel_vc[MAX_VC], in_val;

	ip_chnl *vc[MAX_VC];

	void ip_link_process()
	{	
		in_val.write(!(data_in.read()[30] & data_in.read()[29])); 	// high represents valid data.
		
		for(int count = 0; count < MAX_VC; count++)
			sel_vc[count].write(false);
		
		int temp = data_in.read().range(28,27);			//*** VC info embedded in each packet during gen. itself.
		sel_vc[temp].write(true);
	}

	void ip_link1_process()
	{	
	    	int count, j;
	    	bool temp;

		for(count = 0; count < MAX_VC; count++)
		{
			wr_en_vc[count].write(sel_vc[count].read() & in_val.read());
			rok_vc[count].write(!empty_vc[count]);

			temp = 0;
			for(j = count*(MAX_VC * (total_link)); j < (count + 1)*(MAX_VC * (total_link)); j++)
				temp |= rd_en[j].read();
			rd_en_vc[count].write( temp );
		}

	}

	SC_HAS_PROCESS(ip_link);
	ip_link(sc_module_name nm, int link, int total, int buffer_size, int router):sc_module(nm), total_link(total)
	{
		int count, j;
//cout<<"here in ip_link\n";
		rd_en = new sc_in<bool>[MAX_VC * (total_link) * MAX_VC];
		req_l_vc = new sc_out<bool> *[total_link];
		for(j = 0; j < total_link; j++)
            		req_l_vc[j] = new sc_out<bool>[MAX_VC];
            	
            	if( routingAlgo == OE_NOP )	{
            		outLinkBufferStatus = new sc_in<int>*[MAX_LINK];
            		for( count = 0; count < MAX_LINK; count++ )
            			outLinkBufferStatus[count] = new sc_in<int> [MAX_LINK];
            	}
            	else	{
            		outLinkBufferStatus = new sc_in<int>*[1];
            		outLinkBufferStatus[0] = new sc_in<int>[1];
            	}

		char str[6];
		for(count = 0; count < MAX_VC; count++)
		{
			sprintf(str,"vc(%0d)",count);
			vc[count] = new ip_chnl(str, link, total_link, buffer_size, router, count);

			vc[count]->reset(reset);
	 		vc[count]->data_in(data_in);
	 		vc[count]->wr_clk(wr_clk);
	 		vc[count]->full_ext(full_vc[count]);
	 		vc[count]->rd_clk(rd_clk);
	 		vc[count]->rd_en(rd_en_vc[count]);
	 		vc[count]->wr_en(wr_en_vc[count]);
	 		vc[count]->data_out(data_out_vc[count]);
	 		vc[count]->empty_synch_rdclk(empty_vc[count]);
	 		vc[count]->current_address(current_address);
			vc[count]->localBufferStatus( localBufferStatus[count] );
			
			if( routingAlgo == OE_NOP )
		 		for(j = 0; j < MAX_LINK; j++)
		 			for( int link = 0; link < MAX_LINK; link++ )
		 				vc[count]->outLinkBufferStatus[j][link]( outLinkBufferStatus[j][link] );
		 	else	vc[count]->outLinkBufferStatus[0][0]( outLinkBufferStatus[0][0] );
	 			
			for(j = 0; j < total_link; j++)
	 			vc[count]->req_l[j](req_l_vc[j][count]);

	 		vc[count]->tailer_org(tailer_vc[count]);
		}

		SC_METHOD(ip_link_process);
			sensitive << data_in;


		SC_METHOD(ip_link1_process);
			sensitive << in_val;
			for(count = 0; count < MAX_VC; count++)
				sensitive << sel_vc[count] << empty_vc[count];
			for(count = 0; count < MAX_VC * (total_link) * MAX_VC; count++)	//*** Put appropriate no. of rd_en signals here.
				sensitive << rd_en[count];

	}

	~ip_link()
	{
		for(int count = 0; count < MAX_VC; count++)
			delete vc[count];

        	for(int j = 0; j < total_link; j++)
            		delete[] req_l_vc[j];
        	delete[] req_l_vc;
        	
        	if( routingAlgo == OE_NOP )
        		for(int count = 0; count < MAX_LINK; count++)
        			delete[] outLinkBufferStatus[count];
        	else	delete[] outLinkBufferStatus[0];
		delete[] outLinkBufferStatus;
		
        	delete[] rd_en;
	}
};

#endif
