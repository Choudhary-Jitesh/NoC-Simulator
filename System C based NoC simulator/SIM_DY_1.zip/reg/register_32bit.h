#ifndef R3
#define R3

#include "systemc"
#include <iostream>

using namespace std;
using namespace sc_core;
using namespace sc_dt;

SC_MODULE (register_32bit) 
{
	sc_in<sc_uint<FLIT_LEN> > din;
	sc_in<bool> ce, clr;
	sc_in_clk clk;

	sc_out<sc_uint<FLIT_LEN> > dout;
	
	void register_32bit_process()
	{	
		if(clr.read()==true)	dout.write("0b01100000000000000000000000000000");	//*** Invalid Data (Both EOP & BOP are HIGH).
		else 			
		{	
			if (ce.read()==true) dout.write(din.read());
		}
	}
	
	SC_CTOR (register_32bit)
	{
		SC_METHOD(register_32bit_process);
		sensitive << clk.pos()<<clr;
	}
};


#endif
