/*
`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////

module register_32bit(din, clk, clr, ce, dout);
    input [31:0] din ;
    input clk ;
    input clr ;
    input ce ;
    output [31:0] dout ;

	 reg [31:0] dout ;
    
	 always @(posedge clk)
	 begin
	 		if(clr)
			dout <= 32'b 01100000000000000000000000000000 ;

			else
			begin
					if (ce)
						dout <= din ;
			end
	 end

endmodule

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
#ifndef reg1b
#define reg1b

#include "systemc.h"

SC_MODULE (register_1bit) 
{
	sc_in<bool> din;
	sc_in<bool> ce, clr;
	sc_in_clk clk;

	sc_out<bool> dout;
	
	void register_1bit_process()
	{
		if(clr.read()==true)	dout.write(0);
		else 			
		{	
			if (ce.read()==true) dout.write(din.read());
		}
	}
	
	SC_CTOR (register_1bit)
	{
		SC_METHOD(register_1bit_process);
		sensitive << clk.pos();
	}
};


#endif
