#ifndef r4b
#define r4b


#include "systemc"
#include <iostream>

using namespace std;
using namespace sc_core;
using namespace sc_dt;

SC_MODULE (register_4bit) 
{
	sc_in<sc_uint<LINK_BIT + VC_BIT> > din;
	sc_in<bool> ce, clr;
	sc_in_clk clk;

	sc_out< sc_uint<LINK_BIT + VC_BIT> > dout;
	
	void register_4bit_process()
	{
		if(clr.read()==true)	dout.write(0);
		else 			
		{	
			if (ce.read()==true) dout.write(din.read());
		}
	}
	
	SC_CTOR (register_4bit)
	{
		SC_METHOD(register_4bit_process);
			sensitive << clk.pos()<<clr;
	}
};


#endif
