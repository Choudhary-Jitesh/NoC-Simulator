/*
`timescale 1ns / 1ps
////////////////////////////////////////////////////////////////////////////////

module register_32bit(din, clk, clr, ce, dout);
    input [31:0] din ;
    input clk ;
    input clr ;
    input ce ;
    output [31:0] dout ;

	 reg [31:0] dout ;
    
	 always @(posedge clk)
	 begin
	 		if(clr)
			dout <= 32'b 01100000000000000000000000000000 ;

			else
			begin
					if (ce)
						dout <= din ;
			end
	 end

endmodule

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
*/
#ifndef REG_DEL_
#define REG_DEL_
#include "systemc.h"

SC_MODULE (register_32bit_delayed) 
{
	sc_in<sc_uint<32> > din;
	sc_in<bool> ce, clr;
	sc_in_clk clk;

	sc_out<sc_uint<32> > dout;
	
	void register_32bit_delayed_process()
	{ 
		while(true)
		{
			wait();
			if(clr.read()==true)	
			{
				wait(1,SC_NS);
				dout.write("0b01100000000000000000000000000000");
			}
			else if (ce.read()==true) 
			{
				wait(1,SC_NS);
				dout.write(din.read());
			}
		}
	}	
		
	SC_CTOR (register_32bit_delayed)
	{
		SC_THREAD(register_32bit_delayed_process);
		sensitive << clk.pos();
	}
};

#endif


