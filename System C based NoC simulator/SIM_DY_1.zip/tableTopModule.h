#ifndef topper_mod
#define topper_mod

#include "tableInLink.h"
#include "tableOutLink.h"
#include "d_ff/dff_asynch_set.h"
#include "./power_Header_file/power_calc.cpp"
#include "./power_Header_file/energy_calc.cpp"


SC_MODULE(top_module)
{
	int total_link, link_count, core_count;

	sc_in<bool> clk4x, ce;
	sc_in<bool> clr;
	sc_in<bool> clk;
	sc_in<sc_uint<ADD_BIT_LEN> > current_address;		//*** It contains ID of the router.
	sc_in<int> **outLinkBufferStatus;
	sc_in<sc_uint<FLIT_LEN> > *data_in_link;
	sc_in<bool> **full_in_link_vc;
	
	sc_out<bool> reset;
	sc_out<sc_uint<FLIT_LEN> > *data_out_link;
	sc_out<bool> **full_out_link_vc;
	sc_out<int> *bufferStatus;

	sc_signal<bool> ***req_link_l_vc;
	sc_signal<bool> **tailer_link_vc;
	sc_signal<bool> **rok_link_vc;
	sc_signal<bool> gnd;
	sc_signal<bool> ****rd_en_link_vc_link_vc;
	sc_signal<int> **localBufferStatus;
	// The two link# should never be equal.
	// It should be equal to the no. of rd_en signals for a link.

	sc_signal<sc_uint<FLIT_LEN> > **data_out_link_vc;
	
	// =================== POWER ======================

   	power_calc_l<bool,sc_uint<FLIT_LEN>,MAX_VC+1>  **pwr_input_ch, **pwr_output_ch;

    	energy_calc_32<bool,sc_uint<FLIT_LEN>,MAX_VC+1>   **engy_32_input_ch, **engy_32_output_ch;

	//=================================================

	sc_signal<bool> L,H;
	sc_signal< bool > **data_in_req_vc, **data_req_vc_from_next_router;

	ip_link **ip_l;

	op_link **op_l;

	dff_asynch_set *dff_aset1;
	
	void detBufferStatusProcess()
	{	
		if( routingAlgo == OE_NOP )	{
			int temp;
			for(int count_1 = 0; count_1 < MAX_LINK; count_1++)	{	// Input Links
				temp = 0;
				for(int count_2 = 0; count_2 < MAX_VC; count_2++)	// VCs of Input Links
					temp += localBufferStatus[count_1][count_2].read();
				bufferStatus[count_1].write( temp );
			}
		}
		
	}
	void assignment_for_power_process()
	{	
		for(int link = 0; link < total_link; link++)
		{
			for(int j = 0; j < MAX_VC; j++)
			{
				data_in_req_vc[link][j] = !full_in_link_vc[link][j];
				data_req_vc_from_next_router[link][j] = !full_out_link_vc[link][j];
			}
		}
	}

	SC_HAS_PROCESS(top_module);

	top_module(sc_module_name nm, char *router_name, int link_num, int core, int buffer_size, char *folder, int router):sc_module(nm)
	{
		int i, j, k, l, link, vc, count;
		//cout<<"here in TOPmodule\n";
		link_count = link_num;
		core_count = core;
		total_link = link_count + core_count;
		
		localBufferStatus = new sc_signal<int> *[total_link];
		for(count = 0; count < total_link; count++)
			localBufferStatus[count] = new sc_signal<int> [MAX_VC];
		
		if( routingAlgo == OE_NOP )	{			
			outLinkBufferStatus = new sc_in<int> *[MAX_LINK];
			for( count = 0; count < MAX_LINK; count++ )
				outLinkBufferStatus[count] = new sc_in<int>[MAX_LINK];
			
			bufferStatus = new sc_out<int> [MAX_LINK];
		}
		else	{
			outLinkBufferStatus = new sc_in<int> *[1];
			outLinkBufferStatus[0] = new sc_in<int>[1];
			
			bufferStatus = new sc_out<int>[1];
		}
		
		pwr_input_ch = new power_calc_l<bool,sc_uint<FLIT_LEN>,MAX_VC+1> *[total_link];
		pwr_output_ch = new power_calc_l<bool,sc_uint<FLIT_LEN>,MAX_VC+1> *[total_link];
		engy_32_input_ch = new energy_calc_32<bool,sc_uint<FLIT_LEN>,MAX_VC+1> *[total_link];
		engy_32_output_ch = new energy_calc_32<bool,sc_uint<FLIT_LEN>,MAX_VC+1> *[core_count];

		data_in_link = new sc_in<sc_uint<FLIT_LEN> >[total_link];
		data_out_link = new sc_out<sc_uint<FLIT_LEN> >[total_link];
		data_out_link_vc = new sc_signal<sc_uint<FLIT_LEN> > *[total_link];
		full_in_link_vc = new sc_in<bool> *[total_link];
		full_out_link_vc = new sc_out<bool> *[total_link];
		tailer_link_vc = new sc_signal<bool> *[total_link];
		rok_link_vc = new sc_signal<bool> *[total_link];
		data_in_req_vc = new sc_signal<bool> *[total_link];
		data_req_vc_from_next_router = new sc_signal<bool> *[total_link];
		req_link_l_vc = new sc_signal<bool> **[total_link];
		rd_en_link_vc_link_vc = new sc_signal<bool> ***[total_link];

		for(i = 0; i < total_link; i++)
		{
		    	full_in_link_vc[i] = new sc_in<bool>[MAX_VC];
            		full_out_link_vc[i] = new sc_out<bool>[MAX_VC];
            		tailer_link_vc[i] = new sc_signal<bool>[MAX_VC];
            		rok_link_vc[i] = new sc_signal<bool>[MAX_VC];
            		data_out_link_vc[i] = new sc_signal<sc_uint<FLIT_LEN> >[MAX_VC];
            		data_in_req_vc[i] = new sc_signal<bool>[MAX_VC];
			data_req_vc_from_next_router[i] = new sc_signal<bool>[MAX_VC];

            		req_link_l_vc[i] = new sc_signal<bool> *[total_link];
            		for(j = 0; j < total_link; j++)
                		req_link_l_vc[i][j] = new sc_signal<bool>[MAX_VC];

            		rd_en_link_vc_link_vc[i] = new sc_signal<bool> **[MAX_VC];
            		for(k = 0; k < MAX_VC; k++)
            		{
                		rd_en_link_vc_link_vc[i][k] = new sc_signal<bool> *[total_link];
                		for(j = 0; j < total_link; j++)
                    			rd_en_link_vc_link_vc[i][k][j] = new sc_signal<bool>[MAX_VC];
            		}
		}

		char str[50];
		L.write(false);
		H.write(true);

        	char router_ser_deser[100];
        	char temp_string[50];
        	char temp[5][30];
        	
        	//cout<<"Finished Initialization"<<endl;
        	/******************************                 POWER MODULES                   **************************/

        	pwr_input_ch[0]= new power_calc_l<bool,sc_uint<FLIT_LEN>,MAX_VC+1> ("in_com_ch1",router_name,"reset","data_in_req_vc1_from_link1","data_in_req_vc2_from_link1","data_in_req_vc3_from_link1","data_in_req_vc4_from_link1","link1_packet");

        	pwr_output_ch[0]= new power_calc_l<bool,sc_uint<FLIT_LEN>,MAX_VC+1> ("out_com_ch1",router_name,"NO","data_out_req_vc1_from_link1","data_out_req_vc2_from_link1","data_out_req_vc3_from_link1","data_out_req_vc4_from_link1","data_out_to_link1");

        	for(i = 1; i < total_link; i++)
        	{
        		sprintf(temp_string,"in_com_ch%d",i+1);
        		for(j = 0; j < MAX_VC; j++)
        			sprintf(temp[j],"data_in_req_vc%d_from_link%d",j+1,i+1);

        		sprintf(temp[MAX_VC],"link%d_packet",i+1);

        		pwr_input_ch[i]= new power_calc_l<bool,sc_uint<FLIT_LEN>,MAX_VC+1> (temp_string,router_name,"NO",temp[0],temp[1],temp[2],temp[3],temp[4]);

        		sprintf(temp_string,"out_com_ch%d",i+1);
        		for(j = 0; j < MAX_VC; j++)
        			sprintf(temp[j],"data_out_req_vc%d_from_link%d",j+1,i+1);

        		sprintf(temp[MAX_VC],"data_out_to_link%d",i+1);

        		pwr_output_ch[i]= new power_calc_l<bool,sc_uint<FLIT_LEN>,MAX_VC+1> (temp_string,router_name,"NO",temp[0],temp[1],temp[2],temp[3],temp[4]);
        	}
        	//cout<<"finished power modules"<<endl;
        	/******************************                 ENERGY MODULES                   **************************/

        	for(i = 0; i < link_count; i++)
        	{
            		sprintf(temp_string,"_in_%d_L_25.scr",i);
            		strcpy(router_ser_deser,nm);
            		strcat(router_ser_deser,temp_string);

            		sprintf(temp_string,"mesh_router_32_en_in_com_ch%d",i+1);
            		sprintf(str,"%spower_result/L_25.txt",folder);
            		engy_32_input_ch[i]=new energy_calc_32<bool,sc_uint<FLIT_LEN>,MAX_VC+1> (temp_string,router_ser_deser,str,"L_25",LINK_ROUTER_TO_ROUTER,folder);

            		//cout << router_ser_deser <<"\t"<< temp_string<<endl;
        	}

        	for(i = link_count; i < total_link; i++)
        	{
            		sprintf(temp_string,"_from_core_in_%d_L_125.scr",i - link_count);
            		strcpy(router_ser_deser,nm);
            		strcat(router_ser_deser,temp_string);

            		sprintf(temp_string,"mesh_router_32_en_in_com_ch%d",i+1);
					sprintf(str,"%spower_result/L_125.txt",folder);
			
            		engy_32_input_ch[i]=new energy_calc_32<bool,sc_uint<FLIT_LEN>,MAX_VC+1> (temp_string,router_ser_deser,str,"L_125",LINK_ROUTER_TO_CORE,folder);

            		//cout << router_ser_deser <<"\t"<< temp_string<<endl;

            		sprintf(temp_string,"_into_core_out_%d_L_125.scr",i - link_count);
            		strcpy(router_ser_deser,nm);
            		strcat(router_ser_deser,temp_string);

            		sprintf(temp_string,"mesh_router_32_en_out_com_ch%d",i+1);            		

            		engy_32_output_ch[i - link_count]=new energy_calc_32<bool,sc_uint<FLIT_LEN>,MAX_VC+1> (temp_string,router_ser_deser,str,"L_125",LINK_ROUTER_TO_CORE,folder);

            		//cout << router_ser_deser <<"\t"<< temp_string<<endl;
        	}
        	//cout<<"End of energy modules"<<endl;
		for(link = 0; link < total_link; link++)
		{
			//======= POWER ========

			pwr_input_ch[link]-> clk(clk);            		/// modified according to the name present in the link
			pwr_input_ch[link]-> in[0](reset);
			pwr_input_ch[link]-> data(data_in_link[link]);	   	/// modified according to the name present in the link

			//====== ENERGY ========

			engy_32_input_ch[link]-> clk(clk);	            	/// modified according to the name present in the link
			engy_32_input_ch[link]-> in[0](reset);
			engy_32_input_ch[link]-> clk4x(clk4x);
			engy_32_input_ch[link]-> ce(ce);
			engy_32_input_ch[link]-> data(data_in_link[link]);     /// modified according to the name present in the link


			//========POWER=========
			pwr_output_ch[link]-> clk(clk);
			pwr_output_ch[link]-> in[0](reset);
			pwr_output_ch[link]-> data(data_out_link[link]);

			for(j = 0; j < MAX_VC; j++)
			{
				pwr_input_ch[link]-> in[j+1](data_in_req_vc[link][j]);
				engy_32_input_ch[link]-> in[j+1](data_in_req_vc[link][j]);
				pwr_output_ch[link]-> in[j+1](data_req_vc_from_next_router[link][j]);
			}
		}

        	for(link = 0; link < core_count; link++)
        	{
            		engy_32_output_ch[link]-> clk(clk);
            		engy_32_output_ch[link]-> in[0](reset);
            		engy_32_output_ch[link]-> clk4x(clk4x);
            		engy_32_output_ch[link]-> ce(ce);

            		for(j = 0; j < MAX_VC; j++)
                		engy_32_output_ch[link]-> in[j+1](data_req_vc_from_next_router[link+link_count][j]);

           		engy_32_output_ch[link]-> data(data_out_link[link+link_count]);
        	}

		dff_aset1 = new dff_asynch_set("dff_aset1");

		dff_aset1->clk(clk);
		dff_aset1->d(clr);
		dff_aset1->set(clr);
		dff_aset1->q(reset);

		/***************************    	ip_link             *************************/
		//cout<<"BEfore ip link"<<endl;
		ip_l = new ip_link* [total_link];

		for(link = 0; link < total_link; link++)
		{
			sprintf(str,"ip_l(%0d)",link);
			ip_l[link] = new ip_link(str, link, total_link, buffer_size, router);

			count = 0;
			ip_l[link]->reset(reset);
			ip_l[link]->rd_clk(clk);
			ip_l[link]->wr_clk(clk);

			ip_l[link]->data_in(data_in_link[link]);
			ip_l[link]->current_address(current_address);

			for(vc = 0; vc < MAX_VC; vc++)
			{
				ip_l[link]->data_out_vc[vc](data_out_link_vc[link][vc]);
				ip_l[link]->full_vc[vc](full_out_link_vc[link][vc]);
				ip_l[link]->tailer_vc[vc](tailer_link_vc[link][vc]);
				ip_l[link]->rok_vc[vc](rok_link_vc[link][vc]);
				ip_l[link]->localBufferStatus[vc](localBufferStatus[link][vc]);
			}
			if(routingAlgo == OE_NOP)
				for( l = 0; l < MAX_LINK; l++)
					for(j = 0; j < MAX_LINK; j++)
						ip_l[link]->outLinkBufferStatus[l][j](outLinkBufferStatus[l][j]);
			else	ip_l[link]->outLinkBufferStatus[0][0]( outLinkBufferStatus[0][0] );
			
			for(l = 0; l < total_link; l++)
				for(vc = 0; vc < MAX_VC; vc++)
					ip_l[link]->req_l_vc[l][vc](req_link_l_vc[link][l][vc]);

			for(vc = 0; vc < MAX_VC; vc++)
				for(l = 0; l < total_link; l++)
					for(j = 0; j < MAX_VC; j++)
						ip_l[link]->rd_en[count++](rd_en_link_vc_link_vc[l][j][link][vc]);
		}

		//cout<<"After ip before op"<<endl;
		/***************************            op_link             *************************/

        	op_l = new op_link* [total_link];

		for(link = 0; link < total_link; link++)
		{
			sprintf(str,"op_l(%0d)",link);
			//cout<<"Link "<<link<<endl;
			op_l[link] = new op_link(str, total_link);		
			//cout<<"after inti link "<<link<<endl;
			count = 0;
			op_l[link]->rd_clk(clk);
			op_l[link]->reset(reset);
			op_l[link]->data_out(data_out_link[link]);

			for(vc = 0; vc < MAX_VC; vc++)
				op_l[link]->full_vc[vc](full_in_link_vc[link][vc]);

			for(l = 0; l < total_link; l++)
				for(vc = 0; vc < MAX_VC; vc++)
				{
					op_l[link]->rok_pr_vc[l][vc](rok_link_vc[l][vc]);
					op_l[link]->tailer_pr_vc[l][vc](tailer_link_vc[l][vc]);
					op_l[link]->req_pr_vc[l][vc](req_link_l_vc[l][link][vc]);
					op_l[link]->data_out_pr_vc[l][vc](data_out_link_vc[l][vc]);
				}
				
			for(vc = 0; vc < MAX_VC; vc++)
				for(l = 0; l < total_link; l++)
					for(j = 0; j < MAX_VC; j++)
						op_l[link]->rd_en_vc_pr_vc[vc][l][j](rd_en_link_vc_link_vc[link][vc][l][j]);
			//cout<<"op link loop: link = "<<link<<endl;
		}
		//cout<<"After op link"<<endl;
		SC_METHOD(detBufferStatusProcess);
		sensitive << reset << clk;
		for(link = 0; link < total_link; link++)
			for(vc = 0; vc < MAX_VC; vc++)
				sensitive << localBufferStatus[link][vc];
		
		SC_METHOD(assignment_for_power_process);
		for(l = 0; l < total_link; l++)
			for(vc = 0; vc < MAX_VC; vc++)
				sensitive << full_in_link_vc[l][vc] << full_out_link_vc[l][vc];
		
	}

	~top_module()			//*** Destructor
	{
		//cout << "Destructing Top Module......"<<endl;
	
		delete dff_aset1;

		for(int link = 0; link < total_link; link++)
		{
			delete ip_l[link];
			delete op_l[link];			
			delete[] full_in_link_vc[link];
			delete[] full_out_link_vc[link];
			delete[] rok_link_vc[link];
			delete[] tailer_link_vc[link];
			delete[] data_out_link_vc[link];
			delete[] data_in_req_vc[link];
			delete[] data_req_vc_from_next_router[link];
			delete[] localBufferStatus[link];
		}		
		delete[] localBufferStatus;
		delete[] ip_l;
		delete[] op_l;
		delete[] full_in_link_vc;
		delete[] full_out_link_vc;
		delete[] rok_link_vc;
		delete[] tailer_link_vc;
		delete[] data_out_link_vc;		
		delete[] data_in_link;
		delete[] data_out_link;
		delete[] data_in_req_vc;
		delete[] data_req_vc_from_next_router;
		
		if( routingAlgo == OE_NOP)
			for(int link = 0; link < MAX_LINK; link++)
				delete[] outLinkBufferStatus[link];
		else	delete[] outLinkBufferStatus[0];
		
		delete[] outLinkBufferStatus;
		delete[] bufferStatus;
	}

};

#endif


