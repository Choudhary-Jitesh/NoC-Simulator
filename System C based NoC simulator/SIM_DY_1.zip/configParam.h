#ifndef DEF_PARAM
#define DEF_PARAM

#include <iostream>
#include <cstdlib>
#include <cstring>
#include <cmath>
#include <fstream>
#include <ctime>
#include <iomanip>
#include <sys/stat.h>
#include <sys/types.h>
#include "systemc"

using namespace std;
using namespace sc_dt;
using namespace sc_core;

#define INF 9999

/* Simulator Parameters */
#define clk_period_for_ser_deser 	1.25				// in ns
#define CLK_PERIOD 			5               		// in ns
#define delay 				1               		// in ns

#define DEF_SIM_TIME 			20000*CLK_PERIOD		// in ns
#define DEF_SAT_TIME			1000*CLK_PERIOD			// in ns

#define DEF_MAX_ROUTER 			40				// Total no. of routers.
//#define DEF_MAX_CORE 			1				// Maximum no. of cores per router.
#define DEF_MAX_CORE 			1				// Maximum no. of cores per router.   changed by Soumya J. for the reconfiguration
#define DEF_MAX_LINK 			4				// Maximum no. of global ports per router.
#define MAX_VC 				4				// No. of virtual channels per link. (FIXED)
#define DEF_R_ALGO			0				// Table-based Routing

#define PKT_SIZE			64				// in flits
#define FLIT_LEN			32				// in bits
#define EOP_BIT				30
#define BOP_BIT				29

#define LINK_BIT 			3				// No. of bits required to represent "MAX_LINK1".
#define VC_BIT				3				// No. of bits required to represent "MAX_VC".
#define BUFFER_BIT_LEN 			3				// FIXED as maximum allowed buffer size is 8.
#define MAX_BUFFER_LEN 			8				// Maximum allowed buffer size is 8 flits.
#define ADD_BIT_LEN			8				// Source and destination addresses are 8-bit long.

#define INVALID				1610612736			// Invalid flit - both EOP and BOP bits are High.

/* Traffic Generation Parameters */
#define HURST_PARAM	    		0.75
#define SHAPE_PARM	    		3-2*HURST_PARAM
#define NET_UTI      			0.3
#define PKT_SIZE_B            		32*64				// 64 valid flits of 32 bits each
#define INTER_ARRIVAL	    		"1111111111111111111111111111111"
#define SWITCH_ACTIVITY      		0.9
#define MAX_DESTINATION      		100                               // Changed by Soumya. J

/* Routing Options */
#define TABLE				0
#define XY					1
#define OE_R				2
#define OE_NOP				3

/* Channel Numbering (Not applicable for table-routing) */
#define EAST 				0
#define WEST 				1
#define NORTH 				2
#define SOUTH 				3
#define LOCAL				4

sc_uint<BUFFER_BIT_LEN> countOrder[MAX_BUFFER_LEN] = {0,1,3,2,6,4,5,7};

int MAX_ROUTER;
int MAX_LINK;
int MAX_CORE;
int MAX_LINK1;					// Maximum no. of ports including local ports per router.
int SIMULATION_TIME;
int SAT_TIME_00;
int routingAlgo;
int ext_table;
float inj_rate;
int traceMode;
char *routerConn = NULL;
char *coreComm = NULL;
char *resultFolder = NULL;
char *rTable = NULL;

#endif
