#ifndef R12
#define R12

#include "configParam.h"

SC_MODULE(asynch_comparator)
{
	sc_in<sc_uint<BUFFER_BIT_LEN> > rd_ptr;
	sc_in<sc_uint<BUFFER_BIT_LEN> > wr_ptr;
	sc_in<bool> rd_dir;
	sc_in<bool> wr_dir;
	
	sc_out<bool> full_ext;
	sc_out<bool> full_int;
	sc_out<bool> empty;
	sc_out<int> bufferStatus;		// Contains no. of empty slots in the buffer.
	
	short buffer;
	
	void asynch_comparator_process()	//*** For a maximum FIFO deph of 8.
	{
		if(rd_ptr == wr_ptr)
		{
			if(rd_dir != wr_dir)
			{
				full_int.write(true);
				full_ext.write(true);
				empty.write(false);
				
				bufferStatus.write( 0 );
			}
			else
			{
				full_int.write(false);
				full_ext.write(false);
				empty.write(true);
				
				bufferStatus.write( buffer );
			}
		}
		else
		{
			int rdIndex, wrIndex, diff;
			
			//*** Find the "indices" of rd_ptr & wr_ptr in the array.
			for(rdIndex = 0; rdIndex < buffer && countOrder[rdIndex] != rd_ptr; rdIndex++);
			for(wrIndex = 0; wrIndex < buffer && countOrder[wrIndex] != wr_ptr; wrIndex++);
			
			/* "diff" always contain the no. of empty slots in buffer */
			if(rdIndex > wrIndex)	diff = rdIndex - wrIndex;
			else			diff = buffer - (wrIndex - rdIndex);			
			bufferStatus.write( diff );
			
			full_ext.write(true);
			full_int.write(false);
			empty.write(false);
			
			if( diff >= (buffer/2) )
				full_ext.write(false);
		}			
	}
	
	SC_HAS_PROCESS(asynch_comparator);	
	asynch_comparator(sc_module_name nm, int buffer_size):sc_module(nm), buffer(buffer_size)	
	{
		SC_METHOD(asynch_comparator_process);
			sensitive << rd_ptr << wr_ptr << rd_dir << wr_dir << empty << full_int << full_ext;
	}
	
};
	
#endif
