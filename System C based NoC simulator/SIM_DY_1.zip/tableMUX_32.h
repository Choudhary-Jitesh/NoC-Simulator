#ifndef MUX_32_BIT_mod
#define MUX_32_BIT_mod

#include "configParam.h"

SC_MODULE(mux_32_bit)
{	
	sc_in<sc_uint<32> > *t;
	sc_in<sc_uint<LINK_BIT + VC_BIT> > sel;
	sc_out<sc_uint<32> > m_out;

	void mux_32_bit_process() 
	{ 
		m_out.write( t[sel.read()].read() );
	}

	SC_HAS_PROCESS(mux_32_bit);	
	mux_32_bit(sc_module_name nm, int total_link):sc_module(nm)
	{	//cout<<"here in mux 32bit\n";
		t = new sc_in<sc_uint<32> >[MAX_VC*(total_link)];

		SC_METHOD(mux_32_bit_process);
		sensitive << sel;
		for(int i = 0; i < MAX_VC*(total_link); i++)
			sensitive << t[i];
	}

	~mux_32_bit()	{	delete[] t;	}			//*** destructor
};

#endif
