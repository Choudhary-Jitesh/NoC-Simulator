#ifndef TEST_BENCH
#define TEST_BENCH

#include "configParam.h"

SC_MODULE(top_4_router_testbench)
{
	sc_out<bool> clr;
	sc_out<sc_uint<ADD_BIT_LEN> > *current_address_r;
	sc_out<bool> **full_in_core_vc_r;

    	int total_core;

	void top_4_router_testbench_process()
	{
		cout<<"CONTROL IS IN TESTBENCH.\n";
		
		int router, vc;

		clr.write(true);

		for(router = 0; router < MAX_ROUTER; router++)
			current_address_r[router].write(router);

        	for(router = 0; router < total_core; router++)
			for(vc = 0; vc < MAX_VC; vc++)
				full_in_core_vc_r[router][vc].write(false);

		wait(10,SC_NS);

		clr.write(false);

		wait(10,SC_NS);
	}

	SC_HAS_PROCESS(top_4_router_testbench);
	
	top_4_router_testbench(sc_module_name nm, int total):sc_module(nm),total_core(total)
	{
	    	full_in_core_vc_r = new sc_out<bool> *[total_core];
	    	current_address_r = new sc_out<sc_uint<ADD_BIT_LEN> >[MAX_ROUTER];
	    
	    	for(int i = 0; i < total_core; i++)
            		full_in_core_vc_r[i] = new sc_out<bool>[MAX_VC];

		SC_THREAD(top_4_router_testbench_process);
	}

	~top_4_router_testbench()
	{
	    	delete[] current_address_r;
	    	for(int i = 0; i < total_core; i++)
            		delete[] full_in_core_vc_r[i];
        	delete[] full_in_core_vc_r;
	}
};

#endif
