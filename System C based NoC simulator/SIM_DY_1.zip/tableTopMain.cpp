#include "tableTopRouter.h"
#include "tableTestBench.h"
#include "traffic_generator/trafficMain.h"

int sc_main( int argc, char *argv[] )
{
	srand( time(NULL) );
	srand48( time(NULL) );
	
	// Suppress warnings.
	sc_report_handler::set_actions("/IEEE_Std_1666/deprecated", SC_DO_NOTHING);
	
	initializeParam(argc, argv);					// Read command-line arguments.

	read_input( routerConn );					// Read from the user input file.	
	
	char str2[10], str3[100], str4[50];	
	
    	int total_core = 0;					// Count total no. of cores.
       	for(int router = 0;router < MAX_ROUTER; router++)
		total_core += router_param[router][MAX_LINK + MAX_CORE + 1];
	
	cout << "Cores\t\t: " << total_core << endl << endl;
	
	if( coreComm != NULL || inj_rate != 0 )	{					// Generate traffic.
		
		sprintf(str3,"%s", resultFolder);
		if( mkdir( str3, S_IRWXU | S_IRWXG | S_IRWXO ) != 0 )
			cout << "ERROR: Result folder either exists already or not created" << endl;
		
		sprintf(str3,"%sinput", resultFolder);
		if( mkdir( str3, S_IRWXU | S_IRWXG | S_IRWXO ) != 0 )
			cout << "ERROR: Input folder either exists already or not created" << endl;
		
		traffic_main( total_core );
	}
	/* Create the required folders */	
	sprintf( str3,"%score_data",resultFolder);	
	if( mkdir( str3, S_IRWXU | S_IRWXG | S_IRWXO ) != 0 )
		cout << "ERROR: Folder core_data either exists already or not created" << endl;
	
	if( traceMode == 1 )	{
		sprintf( str3,"%strace",resultFolder);	
		if( mkdir( str3, S_IRWXU | S_IRWXG | S_IRWXO ) != 0 )
			cout << "ERROR: Folder trace either exists already or not created" << endl;
	}
		
	sprintf( str3,"%spower_result",resultFolder);	
	if( mkdir( str3, S_IRWXU | S_IRWXG | S_IRWXO ) != 0 )
		cout << "ERROR: Folder power_result either exists already or not created" << endl;
	
	sprintf( str3,"%spower_result/serializer_power",resultFolder);	
	if( mkdir( str3, S_IRWXU | S_IRWXG | S_IRWXO ) != 0 )
		cout << "ERROR: Folder serializer_power either exists already or not created" << endl;
	
	ofstream out;	
	sprintf(str3,"%sInput_conn.txt",resultFolder);			// Write the router connections in the file.
	out.open(str3);
	
int ii;
	for(int count = 0; count < MAX_ROUTER; count++)	
	{
		//cout<<"check1"<<endl;
		for(ii = 0; ii < MAX_LINK + MAX_CORE + 5; ii++)
			//cout<<"router"<<endl;
			out <<router_param[count][ii]<<"\t";
		   // cout << "router_param" << router_param[count][ii] << endl;
		out << endl; 
	}
	out.close();
	//cout<<"check2"<<endl;
	if( routingAlgo == TABLE )	{	
		if( ext_table == 0 )	{
			ifstream infile;				// Read from the external file.
			infile.open(rTable);
		
			int val, count = 0;
			while(infile)	{			
				infile >> val;
			
				routing_table[count/(MAX_ROUTER*MAX_CORE)][count % (MAX_ROUTER*MAX_CORE) ] = val - 1;
			
				count++;
				if (count == MAX_ROUTER*MAX_ROUTER*MAX_CORE)
					break;
			}
			infile.close();
		}
		else	
        cout<<"creating routing table"<<endl;
		for(int count = 0; count < MAX_ROUTER; count++)	// Create routing table for each of the routers using Dijkstra's Algo.
			dijkstra(count);
		cout<<"here in main1\n";
		sprintf(str3,"%sRouting_table.txt",resultFolder);
		out.open(str3);
		for(int count = 0; count < MAX_ROUTER; count++)	{
			out << "Routing Table for router #"<<count+1<<endl;
			for(int i = 0; i < MAX_ROUTER*MAX_CORE; i++)
				out <<"\tDest_Core:	"<<i+1<<"\tLink:     "<< routing_table[count][i]+1<<endl;
			out << endl; 
		}
		out.close();
	}
	//cout<<"After routing table"<<endl;
	sc_signal<bool> clr;

	sc_clock clk("clock",CLK_PERIOD,SC_NS,0.5);

	sc_signal< sc_uint<8> > current_address_r[MAX_ROUTER];

	sc_signal<bool> **full_in_core_vc_r;
	
	full_in_core_vc_r = new sc_signal<bool> *[total_core];
	//cout<<"After routing table1"<<endl;
	for(int router = 0; router < total_core; router++)
        	full_in_core_vc_r[router] = new sc_signal<bool>[MAX_VC];
	//cout<<"After routing table2"<<endl;
	sc_clock clk_for_ser_deser("clk_for_ser_deser",clk_period_for_ser_deser,SC_NS,0.5);
	//cout<<"after sc_clock"<<endl;
	sc_signal<bool> ce ;
    	ce = true;

	int router,vc;
	//cout<<"before t4r total core = "<<total_core<<endl;
	top_4_router t4r("t4r", total_core, resultFolder);
	//cout<<"Control rchd till here 1"<<endl;
	t4r.ce(ce);
	t4r.clk4x(clk_for_ser_deser);
	t4r.clr(clr);
	t4r.clk(clk);

	for(router = 0; router < MAX_ROUTER; router++)
		t4r.current_address_r[router](current_address_r[router]);

    	for(router = 0; router < total_core; router++)
		for(vc = 0; vc < 4; vc++)
			t4r.full_in_core_vc_r[router][vc](full_in_core_vc_r[router][vc]);
	
	top_4_router_testbench t4rt("t4rt", total_core);
	//cout<<"Control rchd till here 2"<<endl;
	t4rt.clr(clr);

	for(router = 0; router < MAX_ROUTER; router++)
		t4rt.current_address_r[router](current_address_r[router]);

	for(router = 0; router < total_core; router++)
        	for(vc = 0; vc < MAX_VC; vc++)
			t4rt.full_in_core_vc_r[router][vc](full_in_core_vc_r[router][vc]); 
	
	cout << "\nCONTROL IS IN MAIN" << endl;
	
	for(router = 0; router < total_core; router++)
    	{
		sprintf(str3, "%sinput/node%0d_64flit.txt",resultFolder,router);
		t4r.ni[router]->fp_out_payload_00.open(str3);

		sprintf(str4, "%score_data/core_%0d_input.txt",resultFolder,router+1);
		t4r.ni[router]->fp_in_payload_00.open(str4);
    	}

	for(router = 0; router < total_core; router++)
	{
		sprintf(str2, "ni(%0d)",router);
		sprintf(t4r.ni[router]->name,str2);
	}

	sprintf(str3, "%serror_t4r.txt",resultFolder);
		fpe = fopen(str3,"w");
	
	sprintf(str3, "%sc_rd.txt",resultFolder);
    	fp_scs = fopen(str3,"w");
    	
    sprintf(str3, "%sEND_TRANSFER.txt",resultFolder);
    	fpEND = fopen(str3,"w");

	sprintf(str3, "%sresult.txt",resultFolder);
	FILE *fp_results = fopen(str3,"w");

	sprintf(str3, "%spath.txt",resultFolder);
	FILE *path1 = fopen(str3,"w");

	int l, m, i, total_pkt_rcvd = 0, total_pkt_rcvd_wtw = 0, total_pkt_sent = 0;
	long max_packet_rec_time = 0;
	float throughput = 0;
	
        cout <<"@"<<sc_time_stamp()<< "\tSimulation Begins....."<<endl;
	
	sc_start(SIMULATION_TIME, SC_NS);
	
	cout <<"@"<<sc_time_stamp()<< "\tSimulation Finishes....."<<endl;
	
	fprintf(fp_results,"\n\t\tVirtual Channel Simulator - MPLab\nSimulation Time\t: %-6d Cycles\nSaturation Time\t: %-6d Cycles\nRouters\t\t: %0d \
		\nCores\t\t: %0d\nMax Links\t: %0d\nConn. File\t: %s",(SIMULATION_TIME/CLK_PERIOD), (SAT_TIME_00/CLK_PERIOD), MAX_ROUTER, total_core, \
		MAX_LINK1, routerConn);
	
	if( coreComm != NULL )
		fprintf(fp_results,"\nTraffic\t\t: %s",coreComm);
	else if( inj_rate != 0)	
		fprintf(fp_results,"\nTraffic\t\t: SYNTHETIC\nInjection Rate\t: %-3.3f Pkts/Cycle/IP", inj_rate);
	else	fprintf(fp_results,"\nTraffic\t\t: SUPPLIED");
	
	if( routingAlgo == XY )
		fprintf(fp_results,"\nRouting Op\t: XY\n");
	else if( routingAlgo == TABLE )	{
		fprintf(fp_results,"\nRouting Op\t: TABLE");
		if( ext_table == 0 )
			fprintf(fp_results,"\nRouting File\t: %s\n",rTable );
		else
			fprintf(fp_results,"\nRouting File\t: NOT SUPPLIED\n" );
	}
	else if( routingAlgo == OE_R )
		fprintf(fp_results,"\nRouting Op\t: OE-Random\n");
	else 	fprintf(fp_results,"\nRouting Op\t: OE-NoP\n");	

	for(router = 0; router < total_core; router++)
	{	
        	l = (*t4r.ni[router]).l ;
		m = (*t4r.ni[router]).m ;
		i = (*t4r.ni[router]).i ;
		
		total_pkt_sent += l;
		total_pkt_rcvd += m;
		total_pkt_rcvd_wtw += i;
		 
		if( ((*t4r.ni[router]).packet_rec_time) > max_packet_rec_time )
			max_packet_rec_time = (*t4r.ni[router]).packet_rec_time;
		fprintf(fp_results,"\nCore #%d: Packets sent: %d , Packets received: %d ,  Packets_received within time window: %d",router+1,l,m,i);
        }

	FILE *fp[3];   					// modified from 4 to 3 b'coz there is no L_5
	
	sprintf(str3, "%spower_result/Energy.txt",resultFolder,router);
        fp[0]=fopen(str3,"w");
        
        sprintf(str3, "%spower_result/L_125.txt",resultFolder,router);
        fp[1]=fopen(str3,"w");
        
        sprintf(str3, "%spower_result/L_25.txt",resultFolder,router);
        fp[2]=fopen(str3,"w");


	for(router = 0; router < MAX_ROUTER; router++)
		for( int jj =0 ; jj < router_param[router][MAX_LINK + MAX_CORE] +  router_param[router][MAX_LINK + MAX_CORE + 1]; jj++)
		{
			delete t4r.r[router]->pwr_input_ch[jj];
                 	delete t4r.r[router]->pwr_output_ch[jj];
                 	delete t4r.r[router]->engy_32_input_ch[jj];
                 }

	for(router = 0; router < MAX_ROUTER; router++)
		for( int jj =0 ; jj < router_param[router][MAX_LINK + MAX_CORE + 1]; jj++)
			delete t4r.r[router]->engy_32_output_ch[jj];

	sprintf(str3, "./find_total_energy.oo %spower_result/Energy.txt",resultFolder);
    	system(str3);
    	
	sprintf(str3, "./find_total_energy.oo %spower_result/L_125.txt",resultFolder);
    	system(str3);
    	
    sprintf(str3, "./find_total_energy.oo %spower_result/L_25.txt",resultFolder);
    	system(str3);
    	
   	fclose(fp[0]);
   	fclose(fp[1]);
   	fclose(fp[2]);
   
    	for(int mm=0;mm < MAX_ROUTER; mm++)
    		for(int nn=0; nn < MAX_ROUTER ; nn++)
    			{    if (path[mm][nn][0] != -1){
    				 fprintf(path1,"source :   %d\t destination  :  %d\n",mm+1,nn+1);
    				 // source[mm]=source[mm]+1;
    				 // destination[nn]=destination[nn]+1;
    				 //cout<<source[mm]<<destination[nn]<<endl;
    				}

    				for(int kk=0;kk<path_links+1; kk++)
    				{  int jj= path[mm][nn][kk];
    					if(jj != -1 ){
    					fprintf(path1,"\t current router  :  %d\n",jj+1);
    					//cout<<"mm   nn    "<<mm<<"\t"<<nn<<endl;
    				    // if(jj!=mm && jj != nn)
    				    // intermidiate[jj]=intermidiate[jj]+1;
    				   // cout<<destination[nn]<<endl;	
    			}
    				}
				}

		for (int ii=0;ii<MAX_ROUTER;ii++){
		fprintf(path1,"Router %d as source :   %d\t destination  :  %d\t intermidiate :  %d\n",ii+1,src_router[ii],dst_router[ii],intermediate_router[ii]);}

    	for(int mm=0;mm < MAX_ROUTER; mm++)
    		for(int nn=0; nn < MAX_LINK1 ; nn++)
    				{   
    				 if (link_count[mm][nn] != -1){
    				 	if (nn==4)
    				 		fprintf(path1,"Router  %d link  %d count :  %d\n",mm+1,nn,link_count[mm][nn]+1+src_router[mm]);
    					else
    						fprintf(path1,"Router  %d link  %d count :  %d\n",mm+1,nn,link_count[mm][nn]+1);
    				 // source[mm]=source[mm]+1;
    				 // destination[nn]=destination[nn]+1;
    				 //cout<<source[mm]<<destination[nn]<<endl;
    				}

    				
    			}
    			
				




    	throughput = ( CLK_PERIOD* (float)(t4r.throughput_network)*PKT_SIZE) /(total_core * (max_packet_rec_time - SAT_TIME_00));
    	
    	double avg_latency = t4r.avg_latency;

	fprintf(fp_results,"\n\nTotal Pkts Sent\t\t: %0d\nTotal Pkts Rcvd\t\t: %0d\nTotal Pkts Rcvd WTW\t: %0d\nAverage Latency\t\t: %0f\nThroughput\t\t: %0f\nMax Pkt Rcv Time\t: %ld",total_pkt_sent,total_pkt_rcvd, total_pkt_rcvd_wtw, avg_latency, throughput, max_packet_rec_time);
	
	int tps = t4r.total_packet_sent;
	int tpr_wtw = t4r.throughput_network;		
	
	cout <<"\nTotal Pkt Sent\t\t: " << tps <<"\nTotal Pkts Rcvd\t\t: "<<total_pkt_rcvd<<"\nTotal Pkt Rcvd WTW\t: "<< tpr_wtw << endl;

	for(router = 0; router < total_core; router++)
        	delete[] full_in_core_vc_r[router];
        	
   	delete[] full_in_core_vc_r;
   	
   	fclose(fpe);
   	fclose(fp_scs);
   	fclose(fpEND);
   	fclose(path1);
   	
	return 0;

}
