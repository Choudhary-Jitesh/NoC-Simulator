#ifndef fepg
#define fepg

#include "d_ff/DFF_asynch_clr_false.h"

SC_MODULE (falling_edge_pulse_generator)
{
	sc_in<bool> reset,gnt;
	sc_in_clk clk;
	sc_out<bool>q0;
	
	sc_signal<bool>q1;
	sc_signal<bool> high;
	sc_signal<bool>not_gnt;
	sc_signal<bool>d0_reset;
	
	DFF_asynch_clr_false d00;
	DFF_asynch_clr_false d11;
	
	void falling_edge_pulse_generator_process()
	{
		d0_reset.write(reset.read()|q1.read());
		not_gnt.write(!gnt.read());
	}
	
	SC_CTOR (falling_edge_pulse_generator):d00("d00"),d11("d11")
	{
		high.write(true);
		d00.D(high);
		d00.clr(d0_reset);
		d00.clk(not_gnt);
		d00.Q(q0);
		
		d11.D(q0);
		d11.clr(reset);
		d11.clk(clk);
		d11.Q(q1);
		
		SC_METHOD(falling_edge_pulse_generator_process);
		sensitive<<reset.pos()<<clk.pos()<<gnt.neg()<< q1;
	}

};


#endif
