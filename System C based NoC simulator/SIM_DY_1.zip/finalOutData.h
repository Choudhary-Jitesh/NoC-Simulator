#ifndef fopx_mod
#define fopx_mod

#include "configParam.h"

SC_MODULE(final_op_data)
{
	sc_in<sc_uint<FLIT_LEN> > data_in;
	sc_in<sc_uint<2> > vc_id;
	sc_in<bool> gnt_or;
	sc_out<sc_uint<FLIT_LEN> > data_out;
	sc_bv<FLIT_LEN> temp;

  	void final_op_data_process()
	{	
		temp[31]=(bool)data_in.read()[31];
		temp[30]=(bool)(data_in.read()[30] | (!gnt_or.read()));		//*** gnt_or = 0 makes output data invalid.
		temp[29]=(bool)(data_in.read()[29] | (!gnt_or.read()));
	
		temp[28]=(bool)vc_id.read()[1];
		temp[27]=(bool)vc_id.read()[0];	
	
	
		for(int index = 26; index >= 0; index--)
			temp[index] = (bool)( data_in.read()[index] & gnt_or.read() );
	
		data_out.write(temp);
	}

  	SC_CTOR(final_op_data) 
  	{    //cout<<"here in Final op data\n";
    		
    		SC_METHOD(final_op_data_process);
      		sensitive << data_in << gnt_or << vc_id;
      	}

	~final_op_data()	{}		//*** destructor
};

#endif
