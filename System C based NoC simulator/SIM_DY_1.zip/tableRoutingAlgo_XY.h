#ifndef RTM
#define RTM

#include "tableRoutingInfo.h"

SC_MODULE(routing)
{
	int total_link;

	sc_in<bool> reset;
	sc_in<sc_uint<FLIT_LEN> > header_in;
	sc_in<sc_uint<ADD_BIT_LEN> > current_address;		//*** Current router ID (Not Address).
	sc_out<bool> *req_link;
	sc_out<sc_uint<32> > header_out;

	sc_signal<sc_uint<ADD_BIT_LEN> > dest_core, source_core;
	sc_signal<bool> eop, bop;

	void assignment_process()
	{
		eop.write(header_in.read()[30]);
		bop.write(header_in.read()[29]);

		//current_router = current_address.read();		//*** Changed.

		dest_core = header_in.read().range(7,0);
		//source_core = header_in.read().range(15,8);
	}

	void routing_process()
	{
		int link_no;

        	if(reset.read()==true)
		     link_no = INF;
		else
		{
			if( !eop.read() & bop.read() )		// header
			{
				int router = current_address.read();				
				int core = dest_core.read();
				
				int dest_router, local_link;
				//*** Find the router to which this core is connected.
				for(dest_router = 0, local_link = 0; dest_router < MAX_ROUTER*MAX_CORE && 
					router_param[dest_router/MAX_CORE][MAX_LINK + (local_link % MAX_CORE) ] != core+1; local_link++, dest_router++);
			
				dest_router /= MAX_CORE;
				
				int dest_rn = router_param[dest_router][ MAX_LINK + MAX_CORE + 3];
				int dest_cn = router_param[dest_router][ MAX_LINK + MAX_CORE + 4];
	
				int curr_rn = router_param[router][ MAX_LINK + MAX_CORE + 3];
				int curr_cn = router_param[router][ MAX_LINK + MAX_CORE + 4];
				
				//link_no = routing_table[router][core];
				if(dest_cn > curr_cn)
					link_no = 0;
				else if(dest_cn < curr_cn)
					link_no = 1;
				else	{
					if(dest_rn > curr_rn)
						link_no = 3;
					else if(dest_rn < curr_rn)
						link_no = 2;
					else
						link_no = 4;
				}
				
				//cout<<"@ "<<sc_time_stamp()<<"\tRATop:\t"<<current_address<<"\t"<<header_in<<"\t"<<link_no<<endl;				
			}
			else					// if not  a header
				link_no = INF;
	 	}
	 	for(int i = 0; i < total_link;i++)
			req_link[i].write(false);

		if(link_no < total_link)
			req_link[link_no].write(true);
		
		header_out.write( header_in.read() );
	}

	SC_HAS_PROCESS(routing);
	routing(sc_module_name nm, int total): sc_module(nm), total_link(total)
	{
	    	req_link = new sc_out<bool>[total_link];
	    	
		SC_METHOD(assignment_process);
			sensitive << reset << header_in;

		SC_METHOD(routing_process);
			sensitive << eop << dest_core;

	}
	
	~routing()
	{
		delete[] req_link;
	}

};

#endif
