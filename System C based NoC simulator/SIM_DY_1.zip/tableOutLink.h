#ifndef oplx_mod
#define oplx_mod

#include "tableRoundRobinReq.h"	
#include "tableEncoder.h"		
#include "tableAllotVC.h"		
#include "tableDemux.h"			
#include "tableMUX_1.h"		
#include "d_ff/dff.h"
#include "tableMUX_32.h"		
#include "finalOutData.h"		
#include "and_with_delay.h"

SC_MODULE(op_link)
{
	sc_in<bool> reset;
	sc_in<bool> full_vc[MAX_VC];
	sc_in<bool> **req_pr_vc;
	sc_in<bool> **tailer_pr_vc;
	sc_in<bool> **rok_pr_vc;
	sc_in<sc_uint<32> > **data_out_pr_vc;
	sc_out<sc_uint<32> > data_out;
	sc_out<bool> **rd_en_vc_pr_vc[MAX_VC];
	sc_in_clk rd_clk;

    	sc_signal<bool> full_qvc[MAX_VC];
	sc_signal<bool> gnt_vc[MAX_VC];
	sc_signal<bool> gnt_or, b[MAX_VC];
	sc_signal<bool> mux_rok_out_vc[MAX_VC];
	sc_signal<sc_uint<(LINK_BIT + VC_BIT)> > sel_vc, e[MAX_VC];	//*** No. of bits changed.			
	sc_signal<sc_uint<(LINK_BIT + VC_BIT)> > encoded_addr;		//*** No. of bits changed.
	sc_signal<bool>  ready_vc[MAX_VC];
	sc_signal<bool> all_vc_not_busy;
	sc_signal<bool>  *g;
	
	sc_signal<bool> ready_svc[MAX_VC];
	sc_signal<bool> read_enable[MAX_VC];
	sc_signal<sc_uint<2> > vc_id_diff;

	sc_signal<sc_uint<32> > mux_data_out;
	sc_signal<bool > gnt_or_o;


	mux_sel *m_l[MAX_VC];

	demux_16 *dmux_opl[MAX_VC];

    	and_with_delay  *a_w_d_vc[MAX_VC];

	round_robin_req *rrq1;

	allot_vc *alt_vc;

	encoder *enc1;

	arbiter *rr_gnt;

	mux_32_bit *mux_o;

	final_op_data *fo_d;
	
	void op_link1_process2()
	{
		bool temp = 1;
		
		for(int count = 0; count < MAX_VC; count++)
			temp &= b[count];
		all_vc_not_busy.write( !temp );

		for(int count = 0; count < MAX_VC; count++)
			ready_vc[count].write(  mux_rok_out_vc[count].read() & b[count].read() &  !full_qvc[count].read() );
	}

	void op_link1_process3()
	{

		sc_bv<LINK_BIT + VC_BIT> temp = 0;		
		
		for(int count = 0; count < LINK_BIT+VC_BIT; count++)
			for(int i = 0; i < MAX_VC; i++)
				temp[count] |= ( gnt_vc[i] & (bool)e[i].read()[count] );	
					
		sel_vc.write(temp);
	}	

	void read_enable_process()
    	{
		for(int count = 0; count < MAX_VC; count++)
           		read_enable[count].write(!full_vc[count].read() & gnt_vc[count].read());
	}

	void data_out_vc_id_set()
    	{
    		sc_bv<2> t_vc_id = 0;
    		
        	t_vc_id[0] = gnt_vc[1].read() | gnt_vc[3].read();
        	t_vc_id[1] = gnt_vc[2].read() | gnt_vc[3].read();
        	vc_id_diff.write( t_vc_id );
        	
        	gnt_or_o.write(gnt_vc[0].read() | gnt_vc[1].read() | gnt_vc[2].read() | gnt_vc[3].read());
    	}

	SC_HAS_PROCESS(op_link);
	op_link(sc_module_name nm, int total_link):sc_module(nm)
	{
		int count, i, j;
		//cout<<"Inside op link"<<endl;
		rrq1 = new round_robin_req("rrq1",total_link);
		//cout<<"After r robin"<<endl;
		enc1 = new encoder("enc1", total_link);
			//cout<<"in op link total link = "<<total_link<<endl;
		alt_vc = new allot_vc("alt_vc", total_link);
		mux_o = new mux_32_bit("mux_o", total_link);
		rr_gnt = new arbiter("rr_gnt");
        	fo_d = new final_op_data("fo_d");
        	//cout<<"In oplink midway init"<<endl;
		req_pr_vc = new sc_in<bool> *[total_link];
		tailer_pr_vc = new sc_in<bool> *[total_link];
		rok_pr_vc = new sc_in<bool> *[total_link];
		data_out_pr_vc = new sc_in<sc_uint<32> > *[total_link];
		g = new sc_signal<bool> [MAX_VC*(total_link)];
		//cout<<"IN oplink after initialzing"<<endl;
		for(j = 0; j < total_link; j++)
		{
			req_pr_vc[j] = new sc_in<bool>[MAX_VC];
			tailer_pr_vc[j] = new sc_in<bool>[MAX_VC];
			rok_pr_vc[j] = new sc_in<bool>[MAX_VC];
			data_out_pr_vc[j] = new sc_in<sc_uint<32> >[MAX_VC];
		}

		for(i = 0; i < MAX_VC; i++)
		{
			rd_en_vc_pr_vc[i] = new sc_out<bool> *[total_link];
			for(j = 0; j < total_link; j++)
				rd_en_vc_pr_vc[i][j] = new sc_out<bool> [MAX_VC];
		}

		rrq1->reset(reset);
		rrq1->rd_clk(rd_clk);
		rrq1->all_vc_not_busy(all_vc_not_busy);
		for(count = 0; count < ( total_link); count++)
			for(j = 0; j < MAX_VC; j++)
			{
				rrq1->req_[count][j]( req_pr_vc[count][j] );
				rrq1->g[count*MAX_VC + j]( g[count*MAX_VC + j] );
			}

		enc1->encoded_addr(encoded_addr);
		for(count = 0; count < total_link; count++)
			for(j = 0; j < MAX_VC; j++)
				enc1->g[count*MAX_VC+j]( g[count*MAX_VC + j] );


		alt_vc->reset(reset);
		alt_vc->rd_clk(rd_clk);
		alt_vc->encoded_addr(encoded_addr);
		alt_vc->gnt_or(gnt_or);
        	for(count = 0; count < MAX_VC; count++)
		{			
			alt_vc->e[count]( e[count] );		//*** New Here
			alt_vc->b[count]( b[count] );
			for(j = 0; j < total_link; j++)
			{
				alt_vc->g[count + j*MAX_VC]( g[count + j*MAX_VC] );
				alt_vc->tailer[count + j*MAX_VC](req_pr_vc[j][count]);	//*** Indices reversed.
			}
		}

		char str[20];

		for(count = 0; count < MAX_VC; count++)
		{
			sprintf(str,"m_l(%0d)", count);
			m_l[count] = new mux_sel(str, total_link);

			m_l[count]->sel(e[count]);
			m_l[count]->m_out(mux_rok_out_vc[count]);
			for(i = 0; i < (total_link); i++)
				for(j = 0; j < MAX_VC; j++)
					m_l[count]->t[i*MAX_VC+j](rok_pr_vc[i][j]);
		}

		rr_gnt->reset(reset);
		rr_gnt->clk(rd_clk);
		for(count = 0; count < MAX_VC; count++)
		{
			rr_gnt->req[count](ready_vc[count]);
			rr_gnt->gnt[count](gnt_vc[count]);
		}

		for(count = 0; count < MAX_VC; count++)
		{
			sprintf(str,"dmux_opl(%0d)", count);
			dmux_opl[count] = new demux_16(str, total_link);

			dmux_opl[count]->ip(read_enable[count]);
			dmux_opl[count]->sel(e[count]);
			for(i = 0; i < (total_link); i++)
				for(j = 0; j < MAX_VC; j++)
					dmux_opl[count]->op[i*MAX_VC+j](rd_en_vc_pr_vc[count][i][j]);
		}

		for(count = 0; count < MAX_VC; count++)
		{
			sprintf(str,"a_w_d_vc(%0d)", count);
			a_w_d_vc[count] = new and_with_delay(str);

			a_w_d_vc[count]->clk(rd_clk);
			a_w_d_vc[count]->i( full_vc[count] );
            		a_w_d_vc[count]->o( full_qvc[count] );
		}

		mux_o->sel(sel_vc);
        	mux_o->m_out(mux_data_out);
		for(count = 0; count < (total_link); count++)
			for(j = 0; j < MAX_VC; j++)
				mux_o->t[count*MAX_VC+j](data_out_pr_vc[count][j]);

		fo_d->data_in(mux_data_out);
        	fo_d->gnt_or(gnt_or_o);
        	fo_d->vc_id(vc_id_diff);
        	fo_d->data_out(data_out);		

		SC_METHOD(op_link1_process2);
		for(count = 0; count < MAX_VC; count++)
			sensitive << e[count] << mux_rok_out_vc[count] << full_qvc[count] << b[count];

		SC_METHOD(op_link1_process3);
		for(count = 0; count < MAX_VC; count++)
			sensitive << gnt_vc[count] << e[count];

		SC_METHOD(read_enable_process);
			for(count = 0; count < MAX_VC; count++)
				sensitive << full_vc[count] << gnt_vc[count];

		SC_METHOD(data_out_vc_id_set);
			for(count = 0; count < MAX_VC; count++)
				sensitive << gnt_vc[count];

	}

	~op_link()					//*** destructor
	{
		delete rrq1;
		delete enc1;
		delete rr_gnt;
		delete alt_vc;
		delete mux_o;
		delete fo_d;
		
		for(int count = 0; count < MAX_VC; count++)
		{
			delete m_l[count];
			delete dmux_opl[count];
			delete a_w_d_vc[count];
		}
	}

};

#endif
