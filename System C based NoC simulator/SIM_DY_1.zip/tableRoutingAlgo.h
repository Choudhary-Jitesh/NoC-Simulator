#ifndef RAM
#define RAM

#include "tableRoutingInfo.h"
#include "randomOE_Sel.h"
int ***path;
int path_links,p_row,p_col;
int *src_router,*dst_router,*intermediate_router;
int **link_count;
   
//FILE *path;
SC_MODULE(routing)
{
	int total_link, currentLink, c_vc;
	//FILE *path;
	sc_in<bool> reset;
	sc_in<sc_uint<FLIT_LEN> > header_in;
	sc_in<sc_uint<ADD_BIT_LEN> > current_address;		//*** Current router ID (Not Address).
	sc_in<int> **outBufferStatus;
	 
	 char str3[20];
	 

	
	sc_out<bool> *req_link;
	
	sc_signal<bool> eop, bop;
	
	void assignment_process()
	{	
		eop.write(header_in.read()[30]);
		bop.write(header_in.read()[29]);
	}
	
	void routing_algo_mesh_process()
4	
		int count, index;
		 
		if(reset.read()==true)
			index = MAX_LINK1 + 2;
		else	
		{
			if( (!eop.read()) & bop.read() )	// Header
			{
				int router = current_address.read();				
				int destCore = header_in.read().range(7,0);
				int sourceCore = header_in.read().range(15,8);
				//cout<<"\nsource core :  "<<sourceCore<<"\t dst  : "<<destCore<<"\t current : "<<router<<endl;

				int dest_router, src1_router, local_link;
				for(src1_router = 0, local_link = 0; src1_router < MAX_ROUTER*MAX_CORE && 
						router_param[src1_router/MAX_CORE][MAX_LINK + (local_link % MAX_CORE) ] != sourceCore+1; local_link++, src1_router++);			
					src1_router /= MAX_CORE;
				
					/* Find the router to which "destCore" is connected */
					for(dest_router = 0, local_link = 0; dest_router < MAX_ROUTER*MAX_CORE && 
						router_param[dest_router/MAX_CORE][MAX_LINK + (local_link % MAX_CORE) ] != destCore+1; local_link++, dest_router++);			
					dest_router /= MAX_CORE;

			//	cout<< "dest_router   "<<dest_router<<"\tsrc1_router"<<src1_router<<endl;

				 	 if (router == src1_router)
				 	 src_router[src1_router]=src_router[src1_router]+1;
				 	 if (router == dest_router)
    				 dst_router[dest_router]=dst_router[dest_router]+1;
    				 if (router != src1_router && router != dest_router)
    				 intermediate_router[router]=intermediate_router[router]+1;

				int i=0;
				//cout<<"path[sourceCore][destCore][i]   "<<path[sourceCore][destCore][i]<<"path_links   "<<path_links<<endl;
				for (i=0;path[sourceCore][destCore][i]!= -1 && path[sourceCore][destCore][i]!= dest_router && path[sourceCore][destCore][i]!= router && i < path_links+1; i++);
					path[sourceCore][destCore][i]=router;
					//cout<<"i value is "<<i<<endl;
				//fprintf(path,"source :  %d\t dst  :  %d\t current :   %d\n",sourceCore,destCore,router);
				
				if( routingAlgo == TABLE )
					index = routing_table[router][destCore];
					
				else	{
					
					int dest_rn = router_param[dest_router][ MAX_LINK + MAX_CORE + 3];
					int dest_cn = router_param[dest_router][ MAX_LINK + MAX_CORE + 4];
	
					int curr_rn = router_param[router][ MAX_LINK + MAX_CORE + 3];
					int curr_cn = router_param[router][ MAX_LINK + MAX_CORE + 4];

					

					if( dest_cn == curr_cn && dest_rn == curr_rn )
						{index = LOCAL;	
							link_count [router][index]=link_count [router][index]+1;
						//cout<<"src1_router = "<<src1_router<<"\tdest_router "<<dest_router<<"\tcurrent  "<<router<<endl;	
						}			
					else if( routingAlgo == XY )	{										
						int m=floor((sqrt(MAX_ROUTER))/2);
						//cout<<"src1_router = "<<src1_router<<"\tdest_router "<<dest_router<<"\tcurrent  "<<router<<endl;
						int a=0;
						if(dest_cn>curr_cn)
						{
							// a=dest_cn-curr_cn;
							// if(a<m)
							// 	{index=WEST;}
							// else
								{index=EAST;}
								link_count [router][index]=link_count [router][index]+1;	
							//cout<<"dest_cn  curr_cn :  "<<dest_cn<<"    "<<curr_cn<<"\tdest_rn  curr_rn :  "<<dest_rn<<"    "<<curr_rn<<endl;

							//cout<<"index  "<<index<<"\t a value  "<<a<<endl;
						}
						else if(dest_cn<curr_cn)
						{
							// a=curr_cn-dest_cn;
							// if(a>m)
							// 	{index=EAST;}
							// else
								{index=WEST;}
								link_count [router][index]=link_count [router][index]+1;
							//cout<<"dest_cn  curr_cn :  "<<dest_cn<<"    "<<curr_cn<<"\tdest_rn  curr_rn :  "<<dest_rn<<"    "<<curr_rn<<endl;

							//cout<<"index  "<<index<<"\t a value  "<<a<<endl;
						}
						else if(dest_rn>curr_rn)
						{
							// a=dest_rn-curr_rn;
							// if(a<m)
							// 	{index=NORTH;}
							// else
								{index=SOUTH;}
								link_count [router][index]=link_count [router][index]+1;
							//cout<<"dest_cn  curr_cn :  "<<dest_cn<<"    "<<curr_cn<<"\tdest_rn  curr_rn :  "<<dest_rn<<"    "<<curr_rn<<endl;


							//cout<<"index  "<<index<<"\t a value  "<<a<<endl;
						}
						else if(dest_rn<curr_rn)
						{
							// a=curr_rn-dest_rn;
							// if(a>m)
							// 	{index=SOUTH;}															
							// 	else
								{index=NORTH;}	
								link_count [router][index]=link_count [router][index]+1;
							//cout<<"dest_cn  curr_cn :  "<<dest_cn<<"    "<<curr_cn<<"\tdest_rn  curr_rn :  "<<dest_rn<<"    "<<curr_rn<<endl;

							//cout<<"index  "<<index<<"\t a value  "<<a<<endl;

						}
					}
					else if( routingAlgo == OE_R || routingAlgo == OE_NOP )	{
						
						bool *linkAvail = new bool[MAX_LINK];
						for( count = 0; count < MAX_LINK; count++ )
							linkAvail[count] = false;
							
						random_OE_Sel( linkAvail, router, dest_router, sourceCore );
						
						if( routingAlgo == OE_R )	{
							/* Random Selection Function */
							int val = rand()%MAX_LINK;
							for( count = 0; count < MAX_LINK; count++ )	{
								index = (count + val)%MAX_LINK;
								if( linkAvail[index] && index != currentLink )
									break;
							}
						}
						else	{/* NoP Selection Function */
							int countAvailLink = 0;	// If only one link is available, then running sel. fn is useless.
							for( count = 0; count < MAX_LINK; count++ )
								if( linkAvail[count] && count != currentLink )	{								
									countAvailLink++;
									index = count;
								}
							//cout << countAvailLink << endl;
							if( countAvailLink > 1 )	{
								
								int *availBuffer = new int[MAX_LINK];
								int max = 0;
								int val = rand()%MAX_LINK;
								for( int linkNum = 0; linkNum < MAX_LINK; linkNum++ )	{
									count = (linkNum + val)%MAX_LINK;
									availBuffer[count] = 0;
									if( linkAvail[count] && count != currentLink )		{
										int adjRouter = router_param[router][count] - 1;
										int adjLink;
										for( adjLink = 0; router_param[adjRouter][adjLink] != router+1 && adjLink < MAX_LINK; adjLink++ );
										
										bool *adjLinkAvail = new bool[MAX_LINK];
										for( int link = 0; link < MAX_LINK; link++ )
											adjLinkAvail[link] = false;
											
										random_OE_Sel( adjLinkAvail, adjRouter, dest_router, sourceCore );
										
										//cout<<"@ "<<sc_time_stamp()<<"\tOB:\t"<< adjRouter <<"\t";
										for( int link = 0; link < MAX_LINK; link++ )
											if( adjLinkAvail[link] && link != adjLink )	{
												availBuffer[count] += outBufferStatus[count][link];
												//cout << link << "\t" << outBufferStatus[count][link] << "\t";
											}
										//cout << endl;		
										delete[] adjLinkAvail;
									}
									if( availBuffer[count] > max )	{
										max = availBuffer[count];
										index = count;
									}
								}
								delete[] availBuffer;
							}
						}
						delete[] linkAvail;
					}
					//cout<<"@ "<<sc_time_stamp()<<"\tRA:\t"<< router <<"\t"<<currentLink<<"\t"<<c_vc<<"\t"<< curr_rn << curr_cn<<"\t"<<sourceCore<<"\t"<<dest_router<<"\t"<<dest_rn<<dest_cn<<"\t"<<index<<endl;
				}				
			}
			else					// if not  a header
				index = MAX_LINK1 + 2;
		}
		
		for(count = 0; count < total_link; count++)
			req_link[count].write(false);
			
		if(index < total_link)
			req_link[index].write(true);
	}
	
	SC_HAS_PROCESS(routing);
	routing(sc_module_name nm, int link, int total, int vc): sc_module(nm), currentLink(link), total_link(total), c_vc(vc)
	{	
		req_link = new sc_out<bool>[total_link];
		p_row = router_param[MAX_ROUTER - 1][ MAX_LINK + MAX_CORE + 3];
		p_col = router_param[MAX_ROUTER - 1][ MAX_LINK + MAX_CORE + 4];
		path_links = p_row + p_col;
		//cout<<"p_row    "<<p_row<<"\tp_col    "<<p_col<<"\tpath_links   "<<path_links<<endl;
		path = (int***) malloc(MAX_ROUTER * sizeof(int **));
		for(int mm=0;mm < MAX_ROUTER; mm++){
			path [mm]= (int**) malloc(MAX_ROUTER *  sizeof(int *));
    		
    			for(int kk=0;kk< MAX_ROUTER; kk++)
    				{  
    					path [mm][kk]= (int*) malloc(MAX_ROUTER * sizeof(int));

    					for (int jj=0;jj<path_links+1;jj++)
    					path [mm][kk][jj]=-1;	
    				}
    				
    			}
		link_count = (int**) malloc(MAX_ROUTER * sizeof(int *));
		
    			for(int kk=0;kk< MAX_ROUTER; kk++)
    				{  
    					link_count[kk]= (int*) malloc(MAX_LINK1 * sizeof(int));
    					//cout<<"here\n";
    					for (int jj=0;jj<MAX_LINK1;jj++)
    					link_count [kk][jj]=-1;	
    				}
    				
    			
	// for (int i=0; i< MAX_ROUTER; i++)
 //   	{
   		src_router=(int*) malloc(MAX_ROUTER * sizeof(int));
   		dst_router=(int*) malloc(MAX_ROUTER * sizeof(int));
   		intermediate_router=(int*) malloc(MAX_ROUTER * sizeof(int));
   	// }
		//sprintf(str3, "%spath.txt",resultFolder);
		//path = fopen(str3,"w");
		if( routingAlgo == OE_NOP )	{
            		outBufferStatus = new sc_in<int>*[MAX_LINK];
            		for( int count = 0; count < MAX_LINK; count++ )
            			outBufferStatus[count] = new sc_in<int> [MAX_LINK];
            	}
            	else	{
            		outBufferStatus = new sc_in<int>*[1];
            		outBufferStatus[0] = new sc_in<int>[1];
            	}
            	
		SC_METHOD(assignment_process);
			sensitive << reset << header_in;
	 		 
		SC_METHOD(routing_algo_mesh_process);
			sensitive << eop;
			//fclose(path);
	}
	
	~routing()
	{
		delete[] req_link;
		if( routingAlgo == OE_NOP )
        		for(int count = 0; count < MAX_LINK; count++)
        			delete[] outBufferStatus[count];
        	else	delete[] outBufferStatus[0];
		delete[] outBufferStatus;
		
	}
};

#endif

