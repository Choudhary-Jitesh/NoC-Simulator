#include "define.cpp"
#include "iostream.h"
int main(){
	for ( int i =0 ;i < 8 ; i++ ){
	  for ( int j =0 ; j< 8 ; j++ ){
	      cout << tab_2mm  [i] [j ] << "\t";
	      }
	      cout << endl ;
	}
	return 0;
}
