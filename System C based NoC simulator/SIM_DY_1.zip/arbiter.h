#ifndef arb_mod
#define arb_mod

#include "priorityEncoder.h"			//*** Use modified PE - two unit delay.
#include "d_ff/DFF_asynch_clr_false.h"
#include "falling_edge_pulse_generator.h"

SC_MODULE (arbiter)
{
	sc_in<bool> req[4];
	sc_in<bool> reset;
	sc_out<bool> gnt[4];
	sc_in_clk clk;

	sc_signal<bool> en0_0, en[4];
	sc_signal<bool> out[4][4];
	sc_signal<bool> high,low;
	sc_signal<bool> gnt_pulse[4];
	sc_signal<bool> clr_en0_reset;
	sc_signal<bool> en0_reset;
	sc_signal<bool> clr_en[4];

	priority_encoder *pe[4];

	DFF_asynch_clr_false *d[5];

	falling_edge_pulse_generator *pg[4];

	sc_signal<bool> all_gnt_low;

	void arbiter_process()
	{
		int count, j;
		bool gnt_temp;

		for(count = 0; count < 4; count++)
		{
			gnt_temp = 0;

			for(j = 0; j < 4; j++)
				gnt_temp |= 	out[j][(count + 4 - j)%4];

			gnt_temp &= 	( !reset.read() );

			gnt[count].write( gnt_temp );
		}

		gnt_temp = reset;
		for(count = 0; count < 4; count++)
			gnt_temp |= en[count];
		clr_en0_reset.write( gnt_temp );

		en0_0.write(all_gnt_low.read()|en[0].read());

		for(int loop = 0; loop < 4; loop++)
		{		
			gnt_temp = reset;
			for(j = 0; j < 4; j++)
				if( j != loop )
					gnt_temp |= gnt_pulse[j];
			clr_en[loop].write( gnt_temp );
		}
		/*for(int loop = 1; loop < 5; loop++)
		{					
			count = loop%4;
			int index = (count+3)%4;
			gnt_temp = reset;
			for(j = 0; j < 4; j++)
				if( j != index )
					gnt_temp |= gnt_pulse[j];
			clr_en[count].write( gnt_temp );
		}*/

	}

	void all_gnt_low_process()	{	all_gnt_low.write(!(en[0].read() | en[1].read() | en[2].read() | en[3].read() ));	}

	SC_CTOR(arbiter)
	{
		int count, j;

		SC_METHOD(arbiter_process);
			sensitive << reset << all_gnt_low << en0_reset;
			for(count = 0; count < 4; count++)
			{
				sensitive << en[count] << gnt[count] << gnt_pulse[count];
				for(j = 0; j < 4; j++)
					sensitive << out[count][j];
			}

		SC_METHOD(all_gnt_low_process);
			for(count = 0; count < 4; count++)
				sensitive << en[count];

		high.write(1);
		low.write(0);

		char str[6];
		for(count = 0; count < 4; count++)
		{
			sprintf(str,"pe(%0d)",count);
			pe[count] = new priority_encoder(str);

			if(count == 0)
				pe[count]->en( en0_0 );
			else
				pe[count]->en( en[count] );

			pe[count]->reset(reset);
			pe[count]->clk(clk);

			for(j = 0; j < 4; j++)
			{
				pe[count]->out[j]( out[count][j] );
				pe[count]->in[j]( req[(j+count)%4] );
			}
		}

		for(count = 0; count < 4; count++)
		{
			sprintf(str,"pg(%0d)",count);
			pg[count] = new falling_edge_pulse_generator(str);

			pg[count]->reset(reset);
			pg[count]->clk(clk);
			pg[count]->gnt(gnt[count]);
			pg[count]->q0(gnt_pulse[count]);
		}

		d[0] = new DFF_asynch_clr_false("d(0)");

		d[0]->D(high);
		d[0]->clr(clr_en0_reset);
		d[0]->clk(clk);
		d[0]->Q(en0_reset);

		for(count = 1; count < 5; count++)
		{
			sprintf(str,"d(%0d)",count);
			d[count] = new DFF_asynch_clr_false(str);

			d[count]->D(gnt[count-1]);
			d[count]->clr(low);
			d[count]->clk(clk);
			d[count]->Q(en[count-1]);
		}

	}

	~arbiter()							//*** destructor
	{
		for(int count = 0; count < 4; count++)
		{
			delete pe[count];
			delete pg[count];
		}

		for(int count = 0; count < 5; count++)
			delete d[count];
	}

};

#endif
