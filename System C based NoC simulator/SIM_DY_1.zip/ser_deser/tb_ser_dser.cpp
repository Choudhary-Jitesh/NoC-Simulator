#include "systemc.h"

#include "deserializer_h.cpp"
#include "serializer_h.cpp"

class stimulus : public sc_module {
        public :
        sc_out < bool >  ce , reset ;
        sc_out < sc_uint<32> > ser_in ;

        SC_HAS_PROCESS ( stimulus ) ;
        virtual void log_stimulus(void);

        stimulus ( sc_module_name nm ) {
                SC_THREAD(log_stimulus);
        }        
};

void stimulus :: log_stimulus ( void ) {
        reset = 1;
        //wait(.5,SC_NS);
        //ce = 0 ;
        //reset = 0;
        //wait(5,SC_NS);
        while ( 1 ) {
                //wait(5,SC_NS);
                reset = 0 ;
                ce = 1 ;
                
                ser_in = "0b00000001000001000000100000000010";
                //cout << ser_in << endl;
                wait(5,SC_NS);
                ser_in = "0b00000001000001000011100000000010";
                //cout <<"i"<< ser_in << endl;
                  wait(5,SC_NS);
                ser_in = "0b00000001000001000100100000000010";
                wait(5,SC_NS);
        }
}

class DUT : public sc_module {
        public :
        sc_in < bool > clk4x ;
        sc_signal < sc_uint<8> >  ser_out;
        sc_signal < bool > ce , reset ;
        sc_signal < sc_uint<32> > ser_in , deser_out;
        sc_signal < sc_uint<2> > cntr_out;
        serializer sl;
        deserializer dl;
        stimulus tb;
        SC_HAS_PROCESS ( DUT );
        DUT ( sc_module_name nm ): sc_module(nm) , sl("sl") ,dl("dl"), tb("tb"){
                
                tb.ce(ce); tb.reset(reset); tb.ser_in(ser_in);  
            
                sl.clk4x(clk4x); sl.ce(ce); sl.reset(reset); 
                sl.ser_in(ser_in); 
                sl.ser_out(ser_out); sl.cntr_out(cntr_out);

                dl.clk4x(clk4x) ;dl.reset(reset); dl.sel(cntr_out);
                dl.deser_in(ser_out) ;
                dl.deser_out(deser_out) ;
        }
};

int sc_main(int argc, char *argv[]){
        //sc_clock clk1("clk1",5,SC_NS);
        sc_clock clk2("clk2",1.25,SC_NS);
        DUT dt("dt");
        dt.clk4x(clk2);
        
        sc_trace_file *tf;
        tf = sc_create_vcd_trace_file("trace");
       // cout << dt.ser_in << endl;
        sc_trace(tf, dt.deser_out,"deser_out");
        sc_trace(tf, dt.dl.reg1_out,"reg1_out");
        sc_trace(tf, dt.dl.reg2_out,"reg2_out");
        sc_trace(tf, dt.dl.reg3_out,"reg3_out");
        sc_trace(tf, dt.cntr_out,"cntr_out");
        sc_trace(tf, dt.ser_in,"ser_in");
        sc_trace(tf, dt.ser_out,"ser_out");
        sc_trace(tf, clk2,"clk2");
        
        sc_start(100, SC_NS);
        return 0;
}
