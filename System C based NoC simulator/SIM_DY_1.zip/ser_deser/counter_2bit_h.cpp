/*
        PURPOSE : THIS FILE CONTAINS 2-BITS BINARY COUNTER MODULE.
        LAST UPDATE DATE : 27-MAR-2010 
*/

#ifndef _BIN_CNTR_H
#define _BIN_CNTR_H

#include "systemc.h"

class counter_2bit : public sc_module {
        public :
                sc_in<bool> clk , ce , reset ;
                sc_out<sc_uint<2> > q ;
        SC_HAS_PROCESS ( counter_2bit );
        
        virtual void log_q ( void );
        counter_2bit ( sc_module_name nm ) : sc_module ( nm ) {
                
             SC_METHOD ( log_q );
                sensitive << clk.pos() ;
        }
        ~counter_2bit( )  { }
};

void counter_2bit :: log_q ( void ) {
        
        if ( reset ) q = "00" ;
        else if ( ce ){
          q = q.read() + 1 ;
          if( q.read() > 3 ) q = "00";
        }
}

#endif
