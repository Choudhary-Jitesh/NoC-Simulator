
#ifndef _DESER_H
#define _DESER_H
#include "systemc.h"
#include "reg_8bit_h.cpp"
#include "../d_ff/DFF_clr.h"
//#include "../separate_16bit_h.cpp"

class deserializer : public sc_module {
        public :
                sc_in < bool > clk4x ,reset;
                sc_in < sc_uint<2> > sel ;
                sc_in < sc_uint<8> > deser_in ;
                sc_signal<sc_uint<8> > reg1_out , reg2_out , reg3_out ;
                //sc_out < sc_uint<32> > deser_out ;
                sc_signal < sc_uint<32> > deser_out ;
        private :
                reg_8bits reg1 , reg2 , reg3 ;
                //DFF_clr d1 ;
                //separate_16bit sp;
                sc_signal<sc_uint<32> > temp_deser_out ;
                sc_signal<bool> ce_00 , ce_01 , ce_10 , ce_11 ,temp_ce_00;
                
        public :
                SC_HAS_PROCESS ( deserializer ) ;
                virtual void log_ce(void);
                virtual void log_temp_deser_out(void);
                virtual void log_deser_out(void);
                virtual void log_temp_ce_00(void);
                deserializer ( sc_module_name nm ) : sc_module(nm),reg1("reg1"),reg2("reg2"),reg3("reg3") {
                                                
                        reg1.din(deser_in); reg1.clk(clk4x); reg1.clr(reset); reg1.ce(ce_01); reg1.dout(reg1_out);
                        reg2.din(deser_in); reg2.clk(clk4x); reg2.clr(reset); reg2.ce(ce_10); reg2.dout(reg2_out);
                        reg3.din(deser_in); reg3.clk(clk4x); reg3.clr(reset); reg3.ce(ce_11); reg3.dout(reg3_out);

                        //d1.d(ce_11); d1.clk(clk4x); d1.clr(reset); d1.q(ce_00);

                        SC_METHOD(log_ce);
                                sensitive << sel;
                        SC_METHOD(log_temp_deser_out);
                                sensitive  << clk4x.pos();
                        SC_METHOD(log_deser_out);
                                sensitive << ce_00;
                        SC_METHOD(log_temp_ce_00);
                                sensitive << ce_00 << clk4x.pos();
                }
};
void deserializer :: log_ce ( void ) {
	ce_00 = (!(bool)sel.read()[1] & (bool)sel.read()[0] );
        ce_01 = (!(bool)sel.read()[1] & (bool)sel.read()[0] );        
        ce_10 = ((bool)sel.read()[1] &  !(bool)sel.read()[0] );        
        ce_11 = ( (bool)sel.read()[1] & (bool)sel.read()[0] );
        
        /*ce_01 = (!(bool)sel.read()[1] & (bool)sel.read()[0] );
        ce_10 = ((bool)sel.read()[1]  & !(bool)sel.read()[0] );
        ce_11 = ((bool)sel.read()[1]  & (bool)sel.read()[0] );*/
        //cout << ce_01 << ce_10 << ce_01 << endl;
}

void deserializer :: log_temp_deser_out ( void ) {
        temp_deser_out.write((deser_in.read(),reg3_out.read(),reg2_out.read(),reg1_out.read()));
        //cout  << ser_out << endl;
}
void deserializer :: log_deser_out ( void ) {
        if ( ce_00 == SC_LOGIC_1 )
                deser_out.write ( temp_deser_out.read() );
        
}
void deserializer :: log_temp_ce_00 ( void ) {
        //temp_ce_00.write ( !clk4x.read() & ce_00.read() );
}
#endif
