/*
        This module will separate  8 bits from 32 bits input.
*/
#ifndef _SEPARATE_8BIT_H
#define _SEPARATE_8BIT_H
#include "systemc.h"

class separate_8bit:sc_module{
        private:
        
        public:
                sc_in<sc_uint<32> > in;
                sc_out<sc_uint<8> > out0, out1, out2, out3 ;
                SC_HAS_PROCESS(separate_8bit);
                virtual void logic(void);
                separate_8bit(sc_module_name nm):sc_module(nm){
                        SC_METHOD(logic);
                                sensitive << in;
                }
};

void separate_8bit::logic(void){
        out0.write(in.read().range(7,0));
        out1.write(in.read().range(15,8));
        out2.write(in.read().range(23,16));
        out3.write(in.read().range(31,24));
       
}
#endif
