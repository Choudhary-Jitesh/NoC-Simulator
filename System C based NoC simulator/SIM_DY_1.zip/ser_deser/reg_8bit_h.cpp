
#ifndef _REG_8BITS_H
#define _REG_8BITS_H

#include "systemc.h"
class reg_8bits : public sc_module {
        public :
                sc_in < sc_uint<8> > din ;
                sc_in < bool > clk , ce , clr ;
                sc_out < sc_uint<8> > dout ;

                SC_HAS_PROCESS ( reg_8bits );
                virtual void log_dout(void)  ;
                reg_8bits ( sc_module_name nm ) : sc_module ( nm ) {
                        
                        SC_METHOD ( log_dout );
                                sensitive << clk.pos() ;
                }
                ~reg_8bits ( ) { }
};
void reg_8bits :: log_dout ( void ) {
        if ( clr ) dout.write ("01100000");
        else if ( ce )
                   dout.write ( din.read() );
}
#endif
