/*
        PURPOSE : THIS FILE CONTAINS SERIALIZER MODULE.
        LAST UPDATE DATE : 27-MAR-2010 
*/

#ifndef _SER_H
#define _SER_H

#include "systemc.h"
#include "counter_2bit_h.cpp"
#include "mux_for_ser_h.cpp"
#include "separate_8bit_h.cpp"

class serializer : public sc_module {
        private :
                counter_2bit cntr;
                mux_ser<sc_uint<8> ,sc_uint<2>, 4> m1 ;
                //sc_signal <sc_uint<2> > q ;
                sc_signal <sc_uint<8> > i0 , i1 , i2 , i3 ;
                separate_8bit sp8;
        public :
                sc_in<bool> clk4x , ce , reset ;
                sc_in<sc_uint<32> > ser_in ;
                sc_out<sc_uint<8> > ser_out ;
                sc_out<sc_uint<2> > cntr_out ;

        SC_HAS_PROCESS ( serializer ) ;
        
        serializer ( sc_module_name nm ) : sc_module ( nm ) , cntr("cntr") , m1("m1") ,sp8("sp8") {
               // i0 = ser_in.read().range(15,0) ;
               // i1 = ser_in.read().range(31,16) ;
               // i2 = ser_in.read().range(47,32) ;
               // i3 = ser_in.read().range(63,48) ;
                sp8.in(ser_in); sp8.out0(i0);sp8.out1(i1);sp8.out2(i2);sp8.out3(i3);

                cntr.clk ( clk4x ) ; cntr.ce ( ce ) ; cntr.reset ( reset ) ; cntr.q ( cntr_out ) ;
                
                m1.sel (cntr_out); m1.i [ 0 ] ( i3 ); m1.i [ 1 ] ( i0 ); m1.i [ 2 ] ( i1 ); m1.i [ 3 ] ( i2 );
                m1.out ( ser_out );
        }
        ~serializer (){ }
};

#endif
