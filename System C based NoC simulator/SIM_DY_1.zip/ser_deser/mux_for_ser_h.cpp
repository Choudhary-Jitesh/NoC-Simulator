#include "systemc.h"

#ifndef _MUXSER_H
#define _MUXSER_H
template <typename type,typename typ1,int in_port>
class mux_ser:public sc_module {
        public:
                int j;
                sc_in< type > i[in_port];
                //sc_in< int > sel;
                sc_in< typ1 > sel;
                sc_out< type > out;
                
                virtual void log_mux(void);
                SC_HAS_PROCESS(mux_ser);
                mux_ser(sc_module_name nm):sc_module(nm){
                       // cout << sel ;
                        SC_METHOD(log_mux);                                
                                sensitive << sel ;
                            for(j=0;j<in_port;j++)
                                sensitive << i[j] ;
                }
                ~mux_ser(){ }
};

template <typename type,typename typ1,int in_port>
void mux_ser<type,typ1,in_port>::log_mux(void) try{  
          //cout << sel <<endl; 
          //if(sel>=(typ1)(in_port)) throw "MUX:: SELECT > PORT "; 
          
          out.write(i[sel.read()].read());             
                              
                          
}
catch (char *e) {
   cout << e << endl;
}
#endif
