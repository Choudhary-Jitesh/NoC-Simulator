#include "systemc.h"
int sc_main(int argc, char *argv[]){
sc_clock clk1("clk1",5,SC_NS);
sc_clock clk2("clk2",1.25,SC_NS);
 sc_trace_file *tf;
        tf = sc_create_vcd_trace_file("trace");
        
        sc_trace(tf, clk1,"clk1");
        sc_trace(tf, clk2,"clk2");
        sc_start(100, SC_NS);
}
