#ifndef R8
#define R8

#include "jk_ff/jk_ff.h"
#include "jk_ff/jk_ff_true.h"

SC_MODULE(gray_mod8)
{
	sc_in<bool> reset,en;
	sc_in_clk clk;
	sc_out<sc_uint<BUFFER_BIT_LEN> > gray_out;
	sc_out<bool> dir;

	sc_signal<bool> x;
	sc_signal<bool> j0,k0,j1,k1,j2,k2;
	sc_signal<bool> q0,q1,q2;
	sc_signal<bool> q0_bar,q1_bar,q2_bar;
	sc_bv<BUFFER_BIT_LEN> temp;
	
	jk_ff *jk0;
	jk_ff *jk1;
	jk_ff *jk2;
	jk_ff_true *jk3;
	
	sc_signal<bool> high, low, clr;
	sc_signal<bool> notx;
	sc_signal<bool> q3_bar;
	
	short buffer;
		
	void gray_mod8_process()
	{	/* Following Logic implements MOD N counter where N <= 8 */
		
		
		j0.write( q1_bar.read() );
		k0.write( q1.read() );

		j1.write( q0.read());
		k1.write( q2.read() & q1.read() );

		j2.write( q0_bar.read() & q1.read()) ;		
		k2.write( q1.read() & q0.read() );

		temp[0]=q0.read();		// Index '0' is the rightmost bit and the least significant one too.
		temp[1]=q1.read();
		temp[2]=q2.read();					
		gray_out.write(temp);
		
		notx.write(!x.read());
		
		unsigned short countOrder[8] = {0,1,3,2,6,4,5,7};
		
		if(temp == countOrder[buffer - 1])
		{
			x.write(true);
			clr.write(true);		
		}
		else 
		{
			x.write(false);	
			clr.write(false);
		}
	}	

	SC_HAS_PROCESS(gray_mod8);
	
	gray_mod8(sc_module_name nm, int buffer_size):sc_module(nm)	
	{
		buffer = buffer_size;
		//cout << "Buffer_gray:   "<<buffer<<endl;
					
		jk0 = new jk_ff("jk0");			
		jk0->j(j0);
		jk0->k(k0);
		jk0->reset(reset);
		jk0->clr(clr);
		jk0->en(en);
		jk0->clk(clk);
		jk0->q(q0);
		jk0->qbar(q0_bar);
		
		jk1 = new jk_ff("jk1");		
		jk1->j(j1);
		jk1->k(k1);
		jk1->reset(reset);
		jk1->clr(clr);
		jk1->en(en); 
		jk1->clk(clk);
		jk1->q(q1);
		jk1->qbar(q1_bar);
		
		jk2 = new jk_ff("jk2");		
		jk2->j(j2);
		jk2->k(k2); 
		jk2->reset(reset); 
		jk2->clr(clr);
		jk2->en(en);
		jk2->clk(clk);
		jk2->q(q2);
		jk2->qbar(q2_bar);

		high.write(true);
		low.write(false);
		
		jk3 = new jk_ff_true("jk3");		
		jk3->j(high);			// o/p i.e 'dir' toggles after one complete cycle of counting.
		jk3->k(high);
		jk3->reset(reset);
		jk3->clr(low);
		jk3->en(high);			// always enabled.
		jk3->clk(notx);
		jk3->q(dir);
		jk3->qbar(q3_bar);
					
		
			
		SC_METHOD(gray_mod8_process);
			sensitive << clk.pos() << q0 << q1 << q2 << q0_bar << q1_bar << q2_bar << x << en;			
	}
	
	~gray_mod8()
	{
		delete jk0;
		delete jk1;
		delete jk2;
		delete jk3;
	}
};

#endif
