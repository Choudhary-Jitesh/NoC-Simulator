#ifndef DEL_ELE
#define DEL_ELE

#include "systemc"
#include <iostream>

using namespace std;
using namespace sc_core;
using namespace sc_dt;

SC_MODULE(delay_element) 
{
	sc_in<sc_uint<32> > din;
	sc_in<bool> ce;

	sc_out<sc_uint<32> > dout;
	
	void delay_element_process()
	{
		while(true)			//*** Infinite loop.
		{
			wait();			//*** 	Static sensitivity i.e wait() suspends the execution indefinitely, until any of the signals in its 								sensitivity list triggers it.
			
			if (ce.read()==true) 
			{
				wait(1,SC_NS);		//*** 1 nanosecond delay.
				dout.write(din.read());
			}

		}
	}	
		
	SC_CTOR(delay_element)
	{
		SC_THREAD(delay_element_process);
			sensitive << din;
	}
};

#endif


