#ifndef RTM
#define RTM

#include "tableRoutingInfo.h"

SC_MODULE(routing)
{
	int total_link;

	sc_in<bool> reset;
	sc_in<sc_uint<FLIT_LEN> > header_in;
	sc_in<sc_uint<ADD_BIT_LEN> > current_address;		//*** Current router ID (Not Address).
	sc_out<bool> *req_link;
	sc_out<sc_uint<32> > header_out;

	sc_signal<sc_uint<ADD_BIT_LEN> > current_router;
	sc_signal<sc_uint<ADD_BIT_LEN> > dest_core, source_core;
	sc_signal<bool> gnd,vdd;
	sc_signal<bool> eop, bop;

	void assignment_process()
	{
		eop.write(header_in.read()[30]);
		bop.write(header_in.read()[29]);

		current_router = current_address.read();		//*** Changed.

		dest_core = header_in.read().range(7,0);
		source_core = header_in.read().range(15,8);
	}

	void routing_process()
	{
		int link_no;

        	if(reset.read()==true)
		     link_no = INF;
		else
		{
			if( !eop.read() & bop.read() )		// header
			{
				int router = current_router.read();
				int core = dest_core.read();
				
				link_no = routing_table[router][core];
				
				//cout<<"@ "<<sc_time_stamp()<<"\tRATop:\t"<<current_address<<"\t"<<header_in<<"\t"<<link_no<<endl;				
			}
			else					// if not  a header
				link_no = INF;
	 	}
	 	for(int i = 0; i < total_link;i++)
			req_link[i].write(gnd);

		if(link_no < total_link)
			req_link[link_no].write(vdd);
		
		header_out.write( header_in.read() );
	}

	SC_HAS_PROCESS(routing);
	routing(sc_module_name nm, int total): sc_module(nm), total_link(total)
	{
	    	req_link = new sc_out<bool>[total_link];
	    	
		vdd.write(true);
		gnd.write(false);
		
		SC_METHOD(assignment_process);
			sensitive << current_address << header_in;

		SC_METHOD(routing_process);
			sensitive << reset << eop << bop << current_router << dest_core << header_in;

	}
	
	~routing()
	{
		delete[] req_link;
	}

};

#endif
