#ifndef RAM
#define RAM

#include "tableRoutingInfo.h"

SC_MODULE(routing)
{
	int total_link, currentLink;

	sc_in<bool> reset;
	sc_in<sc_uint<FLIT_LEN> > header_in;
	sc_in<sc_uint<ADD_BIT_LEN> > current_address;		//*** Current router ID (Not Address).
	sc_out<bool> *req_link;
	sc_out<sc_uint<32> > header_out;

	sc_signal<sc_uint<ADD_BIT_LEN> > dest_core, src_core;
	sc_signal<bool> eop, bop;
	
	void assignment_process()
	{
		eop.write(header_in.read()[30]);
		bop.write(header_in.read()[29]);

		dest_core = header_in.read().range(7,0);		
		src_core = header_in.read().range(15,8);
	}
	void routing_algo_mesh_process()
	{
		int count, index;
		 
		if(reset.read()==true)
			index = MAX_LINK1 + 2;
		else
		{
			if((!eop.read()) && bop.read()==true)	// Header
			{
				int router = current_address.read();				
				int core = dest_core.read();
				
				int dest_router, local_link;
				//*** Find the router to which this core is connected.
				for(dest_router = 0, local_link = 0; dest_router < MAX_ROUTER*MAX_CORE && 
					router_param[dest_router/MAX_CORE][MAX_LINK + (local_link % MAX_CORE) ] != core+1; local_link++, dest_router++);
			
				dest_router /= MAX_CORE;
				
				int dest_rn = router_param[dest_router][ MAX_LINK + MAX_CORE + 3];
				int dest_cn = router_param[dest_router][ MAX_LINK + MAX_CORE + 4];
	
				int curr_rn = router_param[router][ MAX_LINK + MAX_CORE + 3];
				int curr_cn = router_param[router][ MAX_LINK + MAX_CORE + 4];
				
				int e0 = dest_cn - curr_cn;
				int e1 = dest_rn - curr_rn;				
							
				if(e0 == 0 && e1 == 0)		// Destination Reached.
					index = LOCAL;
				else 	{
					bool *linkAvail = new bool[MAX_LINK];
					for( count = 0; count < MAX_LINK; count++ )
						linkAvail[count] = false;
					if( e0 == 0 )	{	// Destination in the same column.
						if(e1 > 0)
							//index = SOUTH;
							linkAvail[SOUTH] = true;
						else	//index = NORTH;
							linkAvail[NORTH] = true;
					}
					else if( e0 > 0 )	{	// Eastbound Message
						if(e1 == 0)
							//index = EAST;
							linkAvail[EAST] = true;
						else {
							core = src_core.read();
							for(dest_router = 0, local_link = 0; dest_router < MAX_ROUTER*MAX_CORE && 
								router_param[dest_router/MAX_CORE][MAX_LINK + (local_link % MAX_CORE) ] != core+1; local_link++, dest_router++);
			
							dest_router /= MAX_CORE;
							int src_cn = router_param[dest_router][ MAX_LINK + MAX_CORE + 4];
							
							if( curr_cn%2 == 1 || curr_cn == src_cn )	{
								if( e1 > 0 )
									//index = SOUTH;
									linkAvail[SOUTH] = true;
								else	//index = NORTH;
									linkAvail[NORTH] = true;
							}
							if( dest_cn%2 == 1 || e0 != 1)
								//index = EAST;
								linkAvail[EAST] = true;
						}
					}
					else	{			// Westbound Message
						if( curr_cn%2 == 0 )	{
							if( e1 > 0 )
								//index = SOUTH;
								linkAvail[SOUTH] = true;
							else //if( e1 < 0 )	//index = NORTH;
								linkAvail[NORTH] = true;
						}
						//index = WEST;
						linkAvail[WEST] = true;
					}
					//srand(time(NULL));
					int val = rand()%MAX_LINK;
					for( count = 0; count < MAX_LINK; count++ )	{
						index = (count + val)%MAX_LINK;
						if( linkAvail[index] && index != currentLink )
							break;
					}
					delete[] linkAvail;
				}
				//cout<<"@ "<<sc_time_stamp()<<"\tRA:\t"<< router<<"\t"<< curr_rn<< curr_cn<<"\t"<<src_core.read()<<"\t"<<dest_router<<"\t"<<dest_rn<<dest_cn<<"\t"<<index<<endl;
			}
			else					// if not  a header
				index = MAX_LINK1 + 2;
		}
		
		for(count = 0; count < MAX_LINK1; count++)
			req_link[count].write(false);
			
		if(index < MAX_LINK1)
			req_link[index].write(true);
			
		header_out.write( header_in.read() );
	}
	
	SC_HAS_PROCESS(routing);
	routing(sc_module_name nm, int link, int total): sc_module(nm), currentLink(link), total_link(total)
	{	
		req_link = new sc_out<bool>[total_link];
		SC_METHOD(assignment_process);
			sensitive << reset << header_in;
	 		 
		SC_METHOD(routing_algo_mesh_process);
			sensitive << eop;
	}
	
	~routing()
	{
		delete[] req_link;
	}
};

#endif

