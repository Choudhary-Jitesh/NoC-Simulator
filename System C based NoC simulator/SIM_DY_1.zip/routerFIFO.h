#ifndef R2
#define R2

#include "memory.h"
#include "asynchComparator.h"
#include "grayCounter.h"

SC_MODULE(router_fifo)
{
	sc_in<bool> reset;	
	sc_in<bool> rd_en;
	sc_in<bool> wr_en;	
	sc_in_clk rd_clk;
	sc_in_clk wr_clk;
	sc_in<sc_uint<FLIT_LEN> > data_in;
	
	sc_out<sc_uint<FLIT_LEN> > data_out;
	sc_out<bool> full_ext, empty;
	sc_out<int> bufferStatus;
		
	sc_out<bool> wr_dir,rd_dir;
	sc_out<sc_uint<BUFFER_BIT_LEN> > wr_add, rd_add;
	sc_out<bool> wen_int, full_int, ren_int;

	gray_mod8 *wr_counter;
	gray_mod8 *rd_counter;
	memory *m1;
	asynch_comparator *comp1;

	void internal_read_write_process()
	{
		wen_int.write( wr_en.read() & (!full_int.read()) );
		ren_int.write( rd_en.read() & (!empty.read()) ) ;
	}

	SC_HAS_PROCESS(router_fifo);
	router_fifo(sc_module_name nm, int buffer_size):sc_module(nm)
	{	//cout<<"here in FIFO\n";
		wr_counter = new gray_mod8("wr_counter", buffer_size);
		rd_counter = new gray_mod8("rd_counter", buffer_size);
		m1 = new memory("m1");
		comp1 = new asynch_comparator("comp1", buffer_size);
		
		wr_counter->clk(wr_clk);
		wr_counter->reset(reset);
		wr_counter->en(wen_int);
		wr_counter->gray_out(wr_add); 
		wr_counter->dir(wr_dir);		
	
		rd_counter->clk(rd_clk);
		rd_counter->reset(reset);
		rd_counter->en(ren_int);
		rd_counter->gray_out(rd_add);
		rd_counter->dir(rd_dir);
	
		m1->reset(reset);
		m1->rd_clk(rd_clk);
		m1->rd_add(rd_add);
		m1->wr_clk(wr_clk);
		m1->wr_add(wr_add);
		m1->data_in(data_in);
		m1->wr_en(wen_int);
		m1->rd_en(ren_int);
		m1->data_out(data_out);
		
		comp1->rd_ptr(rd_add);
		comp1->wr_ptr(wr_add);
		comp1->rd_dir(rd_dir);
		comp1->wr_dir(wr_dir);
		comp1->full_ext(full_ext);
		comp1->full_int(full_int);
		comp1->empty(empty);
		comp1->bufferStatus(bufferStatus);
	
		SC_METHOD(internal_read_write_process);
			sensitive << wr_en << rd_en << full_int << empty << wen_int << ren_int;
	}
	
	~router_fifo()
	{		
		delete wr_counter;
		delete rd_counter;
		delete m1;
		delete comp1;
	}

};

#endif
