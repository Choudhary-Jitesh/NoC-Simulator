#ifndef __OE_R_SEL
#define __OE_R_SEL

#include "initParam.h"

void random_OE_Sel( bool *linkAvail, int router, int dest_router, int src_core )	{

	int dest_rn = router_param[dest_router][ MAX_LINK + MAX_CORE + 3];
	int dest_cn = router_param[dest_router][ MAX_LINK + MAX_CORE + 4];

	int curr_rn = router_param[router][ MAX_LINK + MAX_CORE + 3];
	int curr_cn = router_param[router][ MAX_LINK + MAX_CORE + 4];
	
	int e0 = dest_cn - curr_cn;
	int e1 = dest_rn - curr_rn;
					
	/* Destination not reached */
	if(e0 != 0 || e1 != 0)		{		
		if( e0 == 0 )		{		// Destination in the same column.
			if(e1 > 0)	linkAvail[SOUTH] = true;
			else		linkAvail[NORTH] = true;
		}
		else if( e0 > 0 )	{		// Eastbound Message
			if(e1 == 0)	linkAvail[EAST] = true;		// Same Row.
			else 	{
				/* Find the router to which "core" is connected */
				int srcRouter, local_link;
				for(srcRouter = 0, local_link = 0; srcRouter < MAX_ROUTER*MAX_CORE && 
					router_param[srcRouter/MAX_CORE][MAX_LINK + (local_link % MAX_CORE) ] != src_core+1; local_link++, srcRouter++);			
				srcRouter /= MAX_CORE;
				int src_cn = router_param[srcRouter][ MAX_LINK + MAX_CORE + 4];
		
				if( curr_cn%2 == 1 || curr_cn == src_cn )	{
					if( e1 > 0 )	linkAvail[SOUTH] = true;
					else		linkAvail[NORTH] = true;
				}
				if( dest_cn%2 == 1 || e0 != 1)
					linkAvail[EAST] = true;
			}
		}
		else	{			// Westbound Message
			if( curr_cn%2 == 0 )	{
				if( e1 > 0 )	linkAvail[SOUTH] = true;
				else if( curr_rn != 0 ) 		linkAvail[NORTH] = true;
			}
			linkAvail[WEST] = true;
		}
	}
}

#endif
