#ifndef RUI
#define RUI

#include "initParam.h"
	
int **router_param;		// Every row stores config. info (dest. router and link) for all links of corres. router.
int **routing_table;	// Routing Table for every router. Its size is (no. of routers * no. of cores).

void read_input(char *filename)
{
	ifstream user;
	
	const int N = 50;
	char line[N];
	
	user.open(filename);			
	int count = 0;
	
	// Routing table size will be (no. of routers * no. of cores).
	// No. of cores = No. of router * No. of local ports.
	routing_table = (int **) malloc( MAX_ROUTER* sizeof(int *) );
	for(int router_num = 0; router_num < MAX_ROUTER; router_num++)
		routing_table[router_num] = (int *)malloc(MAX_ROUTER*MAX_CORE*sizeof(int));
		
	
	// Every row stores config. info (dest. router/core and link) for all links of corres. router.
	// By default, router name is core name. But if there are more than one core 
	// connected to each router, then connections should be explicitly mentioned.
	
	router_param = (int **) malloc( MAX_ROUTER* sizeof(int *) );
	for(int router_num = 0; router_num < MAX_ROUTER; router_num++)
		router_param[router_num] = (int *)calloc( (MAX_LINK + MAX_CORE + 5),sizeof(int) );
		
	for(int row = 0; row < MAX_ROUTER; row++)
		for(int col = 0; col < MAX_ROUTER*MAX_CORE; col++)
			routing_table[row][col] = INF;
		
		
	count = 0;	
	user >> line;						// Dummy read.
	
	int source_router, dest_router, link, link_count, core_count, flag = 0;
	
	while(user && count <= MAX_ROUTER)	
	{
			if( strcmp(line, "router") == 0)	
			{
				if(flag != 0)
				{
					cout << "ERROR: Incorrect input configuration file format - "<<filename<<endl;
					exit(1);
				}
				flag = 1;
				
				if(count > 0)
				{					
					router_param[count - 1][MAX_LINK + MAX_CORE] = link_count;
					router_param[count - 1][MAX_LINK + MAX_CORE + 1] = core_count;					
				}
				
				link_count = 0;
				core_count = 0;
				count++;
				user >> line;			// source router.
				source_router = atoi(line);
				//cout<<"source router = "<<source_router<<endl;
			}
			else if( strcmp(line, "r") == 0)
			{
				link_count++;
				user >> line;			// Dest. router.
				dest_router = atoi(line);
				router_param[count - 1][link_count - 1] = dest_router;				
			}
			
			else if( strcmp(line, "core") == 0)
			{	
				user >> line;			// core no.
				int core = atoi(line);
				
				if(core > 0)	{		// If there is a core connected to it.
					core_count++;				
					router_param[count - 1][ MAX_LINK + core_count - 1] = core;
				}
			}
			else if( strcmp(line, "buffer") == 0 )
			{
				flag = 0;
				user >> line;
				int buffer = atoi(line);
				
				router_param[count - 1][ MAX_LINK + MAX_CORE + 2] = buffer;
			}
			else if( strcmp(line, "0") == 0)
				link_count++;
			else if( strcmp(line, "a") == 0)
			{
				user >> line;
				char ch = line[2];
				int row, col;
				if( isdigit(ch) )
					row = ch - 48;
				else if( isalpha(ch) )
					row = ch - 87;
				ch = line[3];
				if( isdigit(ch) )
					col = ch - 48;
				else if( isalpha(ch) )
					col = ch - 87;
				
				if( row >= 16 || col >= 16 || row < 0 || col < 0)	{
					cout << "ERROR: Invalid Address" << endl;
					exit(0);
				}
				//cout << line << "\t" << row << "\t" << col << endl;
				router_param[count - 1][ MAX_LINK + MAX_CORE + 3] = row;
				router_param[count - 1][ MAX_LINK + MAX_CORE + 4] = col;
			}
			else
			{
				cout<<"ERROR:  Incorrect format in input connection file - "<<filename<<endl;
				exit(1);
			}
			
			user >> line;
			//cout << count << endl;
	}
	//cout << count << endl;					
	router_param[count - 1][MAX_LINK + MAX_CORE] = link_count;
	router_param[count - 1][MAX_LINK + MAX_CORE + 1] = core_count;
	
}

#endif
