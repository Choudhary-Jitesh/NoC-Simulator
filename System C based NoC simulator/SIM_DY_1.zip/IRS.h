#ifndef R7
#define R7

#include "d_ff/DFF_asynch_clr.h"
#include "d_ff/dff_enable.h"

SC_MODULE (IRS) 
{
	sc_in<bool> reset, empty, rd_en, tailer_org;
	sc_in<bool> header, tailer;
	sc_out<bool> rd_en_out, data_sel;

        sc_signal<bool > data_sel1,rd_en_d,ds_clear,header_d,low,dt_e,data_sel2;
	
	sc_in_clk rd_clk;
	sc_signal<bool> en1, en2, en4, en5, en6;
	sc_signal<bool> high,  w1, w2, w3,dw3;
	sc_signal<bool>clr1,clr2,clr3,clr4,clr5;
	
	DFF_asynch_clr d1;
	DFF_asynch_clr d2;
	DFF_asynch_clr d3;
	DFF_asynch_clr dff_data3;	
	DFF_asynch_clr dff_data4;

        dff_enable dff_dt;

	void IRS1_process()
	{	
		clr1.write(reset.read()|en5.read());
		clr2.write(reset.read()|en6.read());
		clr3.write(reset.read() | w2.read() | w3.read());
		clr4.write(!data_sel.read());
		clr5.write(reset.read()|tailer.read());

		en1.write(!(empty.read()));
		en2.write((rd_en.read()));
		
                dt_e.write(rd_en.read() | tailer.read());
                //cout <<"IRS1:\t"<<rd_en<<"  "<<rd_en_out<<"  "<<en4<<"  "<<en1<<"  "<<en2<<"  "<<data_sel<<endl;
	}


	void IRS2_process()
	{
		if(en4.read()==false)
			rd_en_out.write(en1.read());
		else	rd_en_out.write(en2.read());

                rd_en_d.write(rd_en.read() & (!tailer.read()));
                
               // cout <<"IRS2:\t"<<rd_en<<"  "<<rd_en_out<<"  "<<en4<<"  "<<en1<<"  "<<en2<<"  "<<data_sel<<endl;
	}


		
	SC_CTOR (IRS):d1("d1"),d2("d2"),d3("d3"),dff_data3("dff_data3"),dff_data4("dff_data4"),dff_dt("dff_dt")
	{	
		high.write(true);
                low.write(true);
                
		d1.D(high);
		d1.clk(header);
		d1.Q(en4);
		d1.clr(clr1);
		
		d2.D(en4);
		d2.clk(tailer_org);
		d2.Q(en5);
		d2.clr(clr2);
		
		d3.D(en5);
		d3.clk(rd_clk);
		d3.Q(en6);
		d3.clr(reset);
	
				
		dff_data3.D(high);
		dff_data3.clk(rd_en);
		dff_data3.Q(data_sel);
		dff_data3.clr(clr3);	
	
		dff_data4.D(data_sel);
		dff_data4.clk(rd_clk);
		dff_data4.Q(w2);
		dff_data4.clr(reset);
		
                dff_dt.d(rd_en_d);
                dff_dt.clk(rd_clk);
                dff_dt.ce(dt_e);
                dff_dt.q(w3);              

		SC_METHOD(IRS1_process);
			sensitive<<rd_clk.pos()<<reset<<rd_en<<en5<<en6<<w2<<w3<<tailer<<empty<<data_sel2;
	
		SC_METHOD(IRS2_process);
			sensitive<<rd_clk.pos()<<en4<<en1<<en2<<rd_en<<tailer;
	}	
};

#endif
