#ifndef ms
#define ms

#include "configParam.h"

SC_MODULE(mux_sel)
{
	sc_in<bool> *t;
	sc_in<sc_uint<LINK_BIT + VC_BIT> > sel;
	sc_out<bool> m_out;
	
	int total_link;
	
	void mux_sel_process()
	{
		m_out.write( t[sel.read()].read() );
	}

	SC_HAS_PROCESS(mux_sel);	
	mux_sel(sc_module_name nm, int total):sc_module(nm), total_link(total)
	{ //cout<<"here in mux sel\n";
		t = new sc_in<bool>[MAX_VC*(total_link)];

		SC_METHOD(mux_sel_process);
		sensitive << sel;
		for(int i = 0; i < MAX_VC*(total_link); i++)
			sensitive << t[i];
	}

	~mux_sel()	{	delete[] t;	}			//*** destructor
};

#endif
