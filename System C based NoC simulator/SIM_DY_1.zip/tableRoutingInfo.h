#ifndef RT
#define RT

#include "tableReadUserInput.h"

class node
{
	public:
		short weight;
		short router;		// router_ID of a router at any position in p-queue.
		short link;
};

void sort(node *, int);

int dijkstra(int source)
{
  cout<<"source"<<source<<endl;
	node *array = new node[ MAX_ROUTER ];   // p-queue.

	int link_count = router_param[source][MAX_LINK + MAX_CORE];
    	int core_count = router_param[source][MAX_LINK + MAX_CORE + 1];
    	
        for( int router_num = 0; router_num < core_count; router_num++ )
        {
            int core = router_param[source][MAX_LINK + router_num];
            
            routing_table[source][core - 1] = link_count + router_num;
        }

    	// Initializations.......

	for(int router_num = 0; router_num < MAX_ROUTER; router_num++)
	{
		array[router_num].weight = INF;
		array[router_num].link = INF;
		array[router_num].router = router_num;
	}

	array[source].weight = 0;
	
	//cout<<"Source Router:	"<<source+1<<endl;

	for(int length = MAX_ROUTER; length > 0; length--)
	{
		sort(array,length);

		int vertex = array[length - 1].router;			// Temporary Source Vertex at the end of p-queue.
		
		//cout <<"\n Vertex:	"<<vertex+1<<endl;
		
		link_count = router_param[vertex][MAX_LINK + MAX_CORE];
		//cout<<"link_count:"<<link_count<<endl;
		for(int i = 0; i < link_count; i++)
		{
			//cout<<"i value:"<<i<<endl;
			int router = router_param[vertex][i] - 1;
				
			//cout << "Router:   "<<router+1<<"\t";
			// Find the location 'j' of "router" in p-queue.
			int j;
			for(j = 0; array[j].router != router && j < MAX_ROUTER; j++);

			// "router" is in location 'j'.
			// "vertex" is in location 'length - 1'
			if( array[j].weight > array[length - 1].weight + 1 )			// Relaxation of edge.
			{
				array[j].weight = array[length - 1].weight + 1;
					
				if(vertex == source)
					array[j].link = i;
                            	else
                            		array[j].link = array[length - 1].link;
    		                            	
                    		// "vertex" as well as "source" will pass the packets
                   		// meant for "all cores connected to router" on "link i".
                    		core_count = router_param[router][MAX_LINK + MAX_CORE + 1];
                    			
                   		//cout<<"Link:   "<<i+1<<endl;
				//cout<<"Core_Count:	"<<core_count<<endl;
                    			
                   		for( int router_num = 0; router_num < core_count; router_num++ )
                        	{
                            		int core = router_param[router][MAX_LINK + router_num] - 1;
                            			
                            		routing_table[source][core] = array[j].link;
    		                }
                	}
		}

	}

	delete[] array;

	return 0;
}

void sort(node *array, int len)		//*** Insertion Sort (Descending Order)
{
	int count, j;
	node temp;
	for(count = 1; count < len; count++)
	{
		for(j = count; array[j].weight > array[j - 1].weight && j > 0; j--)
		{
			temp = array[j];
			array[j] = array[j - 1];
			array[j - 1] = temp;
		}
	}
}

#endif
