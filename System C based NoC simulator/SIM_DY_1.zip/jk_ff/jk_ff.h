#ifndef JK_FF
#define JK_FF

#include "../configParam.h"

SC_MODULE(jk_ff)
{
	sc_in<bool> j,k,reset,en, clr;
	sc_out<bool> q,qbar;
	sc_in_clk clk;
	
	bool temp_q,temp_qbar;
	
	void jk_ff_process()
	{
		if( reset.read() )
		{
			q.write(false); qbar.write(true);
			temp_q=false; temp_qbar=true;
		}
		else
		{
			if(en.read() == true)
			{
				if( clr.read() )
				{
					q.write(false); qbar.write(true);
					temp_q=false; temp_qbar=true;
				}	
				else if((j.read()==false)&&(k.read()==false))
				{
					q.write(temp_q);qbar.write(temp_qbar);
				}
				else if((j.read()==false)&&(k.read()==true))
				{
					q.write(false);temp_q=false;
					qbar.write(true);temp_qbar=true;
				}
				else if((j.read()==true)&&(k.read()==false))
				{
					q.write(true);temp_q=1;
					qbar.write(false);temp_qbar=0;
				}
				else
				{
					temp_q = !temp_q;
					q.write(temp_q);
					temp_qbar = !temp_qbar;
					qbar.write(temp_qbar);
				}
			}
		}
	}	
	SC_CTOR(jk_ff)
	{
		temp_q = false;
		temp_qbar = true;
		SC_METHOD(jk_ff_process);
			sensitive << clk.pos();
	}
};

#endif	

