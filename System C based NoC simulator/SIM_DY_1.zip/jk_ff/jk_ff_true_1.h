#ifndef JK_FF_TRUE
#define JK_FF_TRUE

#include "../configParam.h"

SC_MODULE(jk_ff_true)
{
	sc_in<bool> j,k,reset,en, clr;
	sc_out<bool> q,qbar;
	sc_in_clk clk;
	
	bool temp_q,temp_qbar;
	
	void jk_ff_true_process()
		{
			if(reset.read())
			{
				q.write(true); qbar.write(false);
				temp_q=true; temp_qbar=false;
			}
			else
			{
				if(en.read()==true)
				{
					if( clr.read() )
					{
						q.write(false); qbar.write(true);
						temp_q=false; temp_qbar=true;
					} 
					else if((j.read()==false)&&(k.read()==false))
					{
						q.write(temp_q);qbar.write(temp_qbar);
					}
					else if((j.read()==false)&&(k.read()==true))
					{
						q.write(false);temp_q=false;
						qbar.write(true);temp_qbar=true;
					}
					else if((j.read()==true)&&(k.read()==false))
					{
						q.write(true);temp_q=true;
						qbar.write(false);temp_qbar=false;
					}
					else
					{
						temp_q = !temp_q;
						q.write(temp_q);
						temp_qbar = !temp_qbar;
						qbar.write(temp_qbar);
					}
				}
			}
		}
	
	SC_CTOR(jk_ff_true)
		{
			SC_METHOD(jk_ff_true_process);
			sensitive << clk.pos();
		}
};	

#endif
