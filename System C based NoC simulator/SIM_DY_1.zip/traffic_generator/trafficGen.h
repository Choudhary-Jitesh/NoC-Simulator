#ifndef __TR_GEN
#define __TR_GEN

#include "../initParam.h"

/* This uses( modifies ) S. Kundu's Algorithm for AS-traffic generation */
class poo_traffic
{
		float alpha_on, alpha_off;
		char dstn_nd[MAX_DESTINATION][10];
	
	public:
		void set_parameter( int no_of_dest, char const  dstn_nd[MAX_DESTINATION][10]);
		void generate_packet(int no_of_dstn, float rate[MAX_DESTINATION], int node, int total_core);
	    	float pareto(float mode, float shape);
	    	void DecToBin(int dec, char *str);
	    	void switching_activity(char *str, char packet_formation[][31]);
		//void generateAntPkt(ofstream &, int, int, int);	
};

//==============================================================================

long round_d(float val)
{
	long val1 = val;
	return ( ((float)(val - val1))> 0.5?(val1 + 1):val1 );
}

void poo_traffic::set_parameter( int no_of_dest, char const  t_dstn_nd[MAX_DESTINATION][10])
{
	if( coreComm != NULL)
		for ( int i=0; i < no_of_dest; i ++ )
			strcpy(dstn_nd[i], t_dstn_nd[i]);

	alpha_on = SHAPE_PARM;
	alpha_off = ((1-NET_UTI)*alpha_on)/((1-NET_UTI)*alpha_on-NET_UTI*(alpha_on-1));
}

void poo_traffic::generate_packet(int no_of_dstn, float rate[MAX_DESTINATION], int node, int total_core)
{
	char file_name[50];
	long current_time;
	int ii, kk;
	float next_burstlen, next_idle_time, t_next_burstlen;
	char packet_formation[63][31], str[32];	
	int i, j, k;					// loop variables
	int packet_count = 0;				// count for the total numbers of packet for each source
	
	ofstream fp;
	sprintf(file_name,"%sinput/node%0d_64flit.txt",resultFolder,node);
	fp.open(file_name);
	
	float total_rate = 0;
	if( inj_rate == 0 )		// AS_Traffic
		for( i = 0 ; i < no_of_dstn ; i ++ )
			total_rate += rate[i];
	else {				// Synthetic Traffic.
		total_rate = (inj_rate*PKT_SIZE_B)/(CLK_PERIOD*pow(10,-9));		// in bits per second.
		no_of_dstn = 1;
	}
	
	int packet_time = round( PKT_SIZE_B*pow(10,9)/ total_rate );	// in ns	
	//int antNum = PERIOD/packet_time;		// No. of data packets generated for each ant packet.
	
	//cout << total_rate << "\tP_TIME : " << packet_time << endl;
	//cout<<no_of_dstn<<"\t"<<fp.good()<<endl;
	
	if( fp.good() && no_of_dstn > 0 ) 
	{
		current_time = 0;
		
		/* Initial Ant Packet Generation */
		/*while(current_time < SET_TIME)	{			
			generateAntPkt(fp, rand()%no_of_dstn, node, current_time);
			current_time += PERIOD;
		}*/		
				
		while( current_time < SIMULATION_TIME )
		{
			int vc27 = 2.0 * (rand() / (RAND_MAX + 1.0));	// Generation of VC_ID not required.
			int vc28 = 2.0 * (rand() / (RAND_MAX + 1.0));	

			next_burstlen = pareto(1.0, alpha_on);
			next_idle_time = pareto(packet_time, alpha_off);
			
			for (k = 0 ; k < no_of_dstn ; k ++ )
			{
				// Every node is given slot in proportion to its BW.
				if( coreComm != NULL )
		        		t_next_burstlen = next_burstlen*(rate[k]/total_rate);
		        	else	t_next_burstlen = next_burstlen;
		        	
		        	if ( t_next_burstlen < 1 ) 	t_next_burstlen = 1;

				for (i = 0; i < t_next_burstlen && current_time < SIMULATION_TIME; i ++ )
				{	
					/* Data Packet Header Flit */	
					int dest;
					
					if( inj_rate == 0 )	{
						dest = atoi(dstn_nd[k]+1);	// First Character is 'C'(e.g. C16). So, address is incremented by 1.
						dest -= 1;			// First core will be core 0 and so on.
					}
					else dest = rand()%total_core;
					
					DecToBin(dest, str);			//*** write destination address.
					for(int loop1 = 0; loop1 < 8; loop1++)
						fp << str[loop1];

					DecToBin(node, str);			//*** Write Source address.
					for(int loop1 = 0; loop1 < 8; loop1++)
						fp << str[loop1];

					for(int loop1 = 16; loop1 < 27; loop1++)
        					fp << '0';
        				
        				fp << vc27 << vc28 << "10";		// End of Data Pkt Header Flit
					
					DecToBin( current_time/CLK_PERIOD, str);
					
					// Other data packet info - timestamp, data, trailer and invalid flit
					switching_activity(str, packet_formation);
					
					for (ii = 0; ii < 63; ii++)
    					{
						packet_formation[ii][27] = (vc27 + 48);
    						packet_formation[ii][28] = (vc28 + 48);
    					}
					
					
					for(ii = 0; ii < 63; ii++)
				    		for(kk = 0; kk < 31; kk++)
							fp << packet_formation[ii][kk];
    					   
				    	// Write the invalid flit
					fp << INTER_ARRIVAL << endl;

					current_time += packet_time;
					packet_count++;
					//if( ( packet_count % antNum ) == 0 )
					//	generateAntPkt(fp, k, node, current_time);					

				} // i is the count indicating total numbers of packet sent to kth destination

				//packet_count += i;
			}
			//cout << endl;
			current_time += (long int) next_idle_time ;
		}// Adds idle time for all destinations

	}
	else
		cout << "Error:: No Destination or File ~Open ! " << endl;

	fp.close();
}

/*void poo_traffic::generateAntPkt(ofstream & fp, int k, int node, int time)	{
	
	char str[32];
	
	/* Header Flit */
/*	int dest = atoi(dstn_nd[k]+1);			// First Character is 'C'(e.g. C16). So, address is incremented by 1.
	dest -= 1;					// First core will be core '0' and so on.
	DecToBin(dest, str);				// write destination address.
	for(int loop1 = 0; loop1 < 8; loop1++)
		fp << str[loop1];
	
	DecToBin(node, str);				// Write Source address.
	for(int loop1 = 0; loop1 < 8; loop1++)
		fp << str[loop1];
	
	for(int loop1 = 16; loop1 < 25; loop1++)
        	fp << '0';
        
	fp << "10";					// Forward Ant.
	
	int vc27 = (int) (2.0 * (rand() / (RAND_MAX + 1.0)));
	int vc28 = (int) (2.0 * (rand() / (RAND_MAX + 1.0)));
	
	fp << vc27 << vc28 << "10";
	
	/* Timer Flit */
/*	DecToBin( time/CLK_PERIOD, str);
	for(int count1 = 0; count1 < 27; count1++)
		fp << str[count1];
	fp << vc27 << vc28 << "00";
		
	/* Body Flits */		
/*	for(int count = 0; count < 61; count++)	{
		for(int count1 = 0; count1 < 27; count1++)
			fp << "0";
		fp << vc27 << vc28 << "00";
	}
	
	/* Tailer Flit */
/*	for( int count = 0; count < 27; count++ )
		fp << "0";
	fp << vc27 << vc28 << "01";
	
	/* Inter - arrival flit */				
/*	fp << INTER_ARRIVAL;
	fp << endl;
}
*/

float poo_traffic::pareto(float mode, float shape)
{
	float u = drand48();
	float p = mode * round_d((1.0/pow(u, 1.0/shape)));
	return p;
}

void poo_traffic::DecToBin(int dec, char *str)	// Converts a decimal no. in its equivalent string of binary characters.
{
	int i, r ;
	for( i = 0 ;i < 31 ; i++ ) str[i] = '0';
	i = 0;
	while ( dec > 0) 
	{
		r = dec % 2;
		str[i] = r + 48;
		dec = dec / 2;
		i ++ ;
	}
	if ( i > 28 ){ cout << "Error: In Time\n"; exit(0);}
}

void poo_traffic::switching_activity(char *str, char packet_formation[][31])
{
    int kk = 0, ii;
    char lookup[63];
    int switching = (int) SWITCH_ACTIVITY*63;


    for(ii = 0; ii < 27; ii++)				//*** Timing flit
    	packet_formation[0][ii] = str[ii];

 
    for(ii = 0; ii < 63; ii++)
    {
	packet_formation[ii][BOP_BIT]='0';
    	packet_formation[ii][EOP_BIT]='0';		
    }
	packet_formation[62][EOP_BIT]='1';

    for(kk = 0; kk < 27; kk++)
    {
            for(ii=1;ii<63;ii++)			//*** Lookup Initialized.
            	lookup[ii]='0';
            

            for(ii=0;ii<switching;)
            {
                int rr = rand()%63;
                if(lookup[rr]=='0')			//*** Randomly make some lookup to be 1.
                {
            	    lookup[rr]='1';
            	    ii++;
            	}
            }

	    for(ii = 1; ii < 63; ii++)
	    {
	    	if(lookup[ii]=='0')
	    		packet_formation[ii][kk] = packet_formation[ii-1][kk];
	    	
	    	else	
	    	{
	    		if(packet_formation[ii-1][kk]=='1')
	    	        packet_formation[ii][kk]='0';
	    		else
	    			packet_formation[ii][kk]='1';
	    	}
	    }
    }

}

#endif
