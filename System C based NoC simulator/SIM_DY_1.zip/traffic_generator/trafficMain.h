#ifndef __TR_MAIN
#define __TR_MAIN

#include "trafficGen.h"

void traffic_main( int total_core )
{
	float rate[MAX_DESTINATION], total_rate;
	char source[50], dstn[MAX_DESTINATION][10], rate_ascii[25];
	int no_of_source, no_of_dstn;
    	//cout<<"here in traffic_main\n";
    	poo_traffic poo;
    	
    	if( coreComm != NULL)	{
	    	ifstream fp;    	
		fp.open(coreComm, ios::in);        
		fp >> no_of_source;
		/* Read input corres. to each source */
	    	for (int j = 0; j< no_of_source ; j++)
	    	{
		        fp >> source;
		        fp >> no_of_dstn;                
		        total_rate = 0.0;
		        /* Store the BW corres. to each destination */
		        for (int i = 0; i < no_of_dstn; i++)
		        {
		                fp >> rate_ascii;
		                rate[i]  = atof(rate_ascii);
		                rate[i] /= 2.0; 			// For bidirectional bandwidth
		                
				total_rate = total_rate + rate[i];
		        }
		        /* Store the destinations */                
		        for (int i = 0; i < no_of_dstn; i++)
		                fp >> dstn[i];
		        
			poo.set_parameter(no_of_dstn, dstn);        	
			poo.generate_packet(no_of_dstn, rate, j, total_core);        
		}        
        	fp.close ();
        }
        else	{
        	for (int j = 0; j < total_core ; j++)	{
        		poo.set_parameter(1, NULL);
			poo.generate_packet(1, NULL, j, total_core);        
        	}
        }
}

#endif
