#ifndef __TR_MAIN
#define __TR_MAIN

#include "trafficGen.h"

float max_val = 0;

void traffic_main()
{
	float rate[MAX_DESTINATION], total_rate, max_rate = 0;
	char source[50], dstn[MAX_DESTINATION][10], rate_ascii[25];
	int no_of_source;
	int no_of_dstn;
	int i,j,k = 0;	
	
	int packet_time = round( CLK_PERIOD * (1.0/inj_rate) );
	//cout << "INJ_R: " << inj_rate << "PKT_T: " << packet_time << endl;
	
    	ifstream fp;
    	fp.open(coreComm, ios::in); 

    	fp >> no_of_source;

    	poo_traffic poo;
	
	for (j = 0; j< no_of_source ; j++)
    	{
                fp >> source;
                fp >> no_of_dstn;
                
                total_rate = 0.0;
                for (i = 0; i < no_of_dstn; i++)
                {
                        fp >> rate_ascii;
                        rate[i]  = atof(rate_ascii);
                        rate[i] /= 2.0; 			//for bidirectional bandwidth
                        
	        	total_rate = total_rate + rate[i];
                }
                //cout<<total_rate<<endl;
                
                if(total_rate > max_rate)
                	max_rate = total_rate;
                
                for (i = 0; i < no_of_dstn; i++)
                        fp >> dstn[i];
        }
        //cout << endl<<max_rate <<endl;
        max_rate *= ( (AVG_ON_TIME * (SHAPE_PARM - 1))/(float)(PKT_SIZE_B*SHAPE_PARM) );
        
        max_val = poo.pareto(max_rate, (float)SHAPE_PARM);
        
        //cout<<endl<<"MAX_VAL:  "<<max_val<<"\t"<<max_rate<<endl;
        
        fp.close ();
        fp.open(coreComm, ios::in);
        
        fp >> no_of_source;
                
    	for (j = 0; j< no_of_source ; j++)
    	{
                fp >> source;
                fp >> no_of_dstn;
                
                total_rate = 0.0;
                for (i = 0; i < no_of_dstn; i++)
                {
                        fp >> rate_ascii;
                        rate[i]  = atof(rate_ascii);
                        rate[i] /= 2.0; 			//for bidirectional bandwidth
                        
	        	total_rate = total_rate + rate[i];
                }
                
                for (i = 0; i < no_of_dstn; i++)
                        fp >> dstn[i];
                
                //cout << "\nEnd of current source"<<endl;                
                
        	poo.set_parameter(no_of_dstn,total_rate,source,dstn);
        	
	        poo.generate_packet(no_of_dstn,rate,j, packet_time);        
        }
        
        fp.close ();
}

#endif
