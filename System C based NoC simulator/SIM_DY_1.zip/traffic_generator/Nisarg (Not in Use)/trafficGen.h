#ifndef __TR_GEN
#define __TR_GEN

#include "../initParam.h"

extern float max_val;

class poo_traffic
{
		float alpha_on, alpha_off, avg_off_time, interval, burst_len, on_scale, off_scale;
		char source_node[10], dstn_nd[MAX_DESTINATION][10];
	
	public:
		void set_parameter( int no_of_dest, float rate , char const *src_nd, char const  dstn_nd[MAX_DESTINATION][10]);
		void generate_packet(int no_of_dstn, float rate[MAX_DESTINATION],int node, int);
	    	float pareto(float mode, float shape);
	    	void DecToBin(int dec, char *str);
	    	void switching_activity(char *str, char packet_formation[][31]);
};

//==============================================================================

long round_d(float val)
{
	long val1 = val;
	return ( ((float)(val - val1))> 0.5?(val1 + 1):val1 );
}

void poo_traffic::set_parameter( int no_of_dest, float rate , char const  *src_nd, char const  t_dstn_nd[MAX_DESTINATION][10])
{

	strcpy( source_node, src_nd );
	for ( int i=0; i < no_of_dest; i ++ )
		strcpy(dstn_nd[i],t_dstn_nd[i]);

	alpha_on = SHAPE_PARM;

	interval = ((float)PKT_SIZE_B) / rate;

	burst_len = ( AVG_ON_TIME ) / interval ; 			// interms of packet;

	on_scale = (burst_len * (alpha_on - 1))/ alpha_on; 		// interms of packet
	off_scale = (AVG_OFF_TIME * (alpha_on - 1))/ alpha_on;   	// interms of time
}

void poo_traffic::generate_packet(int no_of_dstn, float rate[MAX_DESTINATION], int node, int packet_time)
{
	char file_name[50];
	long current_time;
	int ii,kk;
	float next_burstlen, next_idle_time, t_next_burstlen;
	char packet_formation[63][31], str[32];	
	int i,j,k;			//loop variables
	int packet_count = 0;		//count for the total numbers of packet for each source 
	
	float temp;
		
	sprintf(file_name,"%sinput/node%0d_64flit.txt",resultFolder,node);
	//cout << endl<<file_name << endl;
	
	ofstream fp;
	fp.open(file_name);
	
	float pkt[MAX_DESTINATION] = {0.0};		//*** Stores the no. of packets for every destination core for a source core.
	float total_pkt = 0;

	for( i = 0 ; i < no_of_dstn ; i ++ )
	{
		pkt[i] = rate[i]/PKT_SIZE_B;
		total_pkt += pkt[i];
	}
	
	if( fp.good() && no_of_dstn > 0) 
	{
		current_time = 0;
				
		while( current_time < SIMULATION_TIME )
		{
			int vc27 = 2.0 * (rand() / (RAND_MAX + 1.0));
			int vc28 = 2.0 * (rand() / (RAND_MAX + 1.0));	

			next_burstlen = pareto(on_scale, alpha_on);
			next_idle_time = off_scale * (next_burstlen / on_scale);
			
			temp = (SIMULATION_TIME - current_time)/packet_time;
			 
			//cout <<on_scale<<"\t"<<next_burstlen <<"\t"<< next_idle_time<<"\t";
			
			//*** Reduce the value of next_burst_len between 0 to temp (max possible packets)
			next_burstlen /= max_val;
			
			if(next_burstlen > 1)	next_burstlen = 1;
			
			next_burstlen *= temp;
			
			//cout << temp<< "\t"<<next_burstlen <<"\t";
			
			for (k = 0 ; k < no_of_dstn ; k ++ )
			{

		        	t_next_burstlen = next_burstlen*(pkt[k]/total_pkt);
		        	
		        	//cout <<t_next_burstlen<<"\t";

				if ( t_next_burstlen < 1 ) t_next_burstlen = 1;

				for (i = 0; (i < t_next_burstlen) && ( current_time < SIMULATION_TIME ); i ++ )
				{
		
					int dest = atoi(dstn_nd[k]+1);		// First Character is 'C'(e.g. C16). So, address is incremented by 1.
					dest -= 1;				// First core will be core 0 and so on.
					DecToBin(dest, str);				//*** write destination address.
					for(int loop1 = 0; loop1 < 8; loop1++)
						fp << str[loop1];

					DecToBin(node, str);				//*** Write Source address.
					for(int loop1 = 0; loop1 < 8; loop1++)
						fp << str[loop1];

					for(int loop1 = 16; loop1 < 27; loop1++)
        				fp << '0';
        				
        				fp << vc27;
        				fp << vc28;
					
        				fp << '1';	//*** BOP_BIT
        				fp << '0';	//*** EOP_BIT
					
					DecToBin( current_time/CLK_PERIOD, str);
					
					//Other packet info - timestamp, data, trailer and invalid flit
					switching_activity(str, packet_formation);
					
					for (ii = 0; ii < 63; ii++)
    					{
						packet_formation[ii][27] = (vc27 + 48);
    						packet_formation[ii][28] = (vc28 + 48);
    					}
					
					
					for(ii = 0; ii < 63; ii++)
				    		for(kk = 0; kk < 31; kk++)
							fp << packet_formation[ii][kk];
    					   
				    	//write the invalid flit
					fp << INTER_ARRIVAL << endl;

					current_time += packet_time;

				}//i is the count indicating total numbers of packet sent to kth destination

				packet_count += i;
			}
			//cout << endl;
			current_time += (long int) next_idle_time ;

	    }//Adds idle time all destination

	}
	else
		cout << "Error:: No Destination or File ~Open ! " << endl;

	fp.close();

}


float poo_traffic::pareto(float mode, float shape)
{
	float u = drand48();
	float p = mode * round_d((1.0/pow(u, 1.0/shape)));
	return p;
}

void poo_traffic::DecToBin(int dec, char *str)	// Converts a decimal no. in its equivalent string of binary characters.
{
	int i, r ;
	for( i = 0 ;i < 31 ; i++ ) str[i] = '0';
	i = 0;
	while ( dec > 0) 
	{
		r = dec % 2;
		str[i] = r + 48;
		dec = dec / 2;
		i ++ ;
	}
	if ( i > 28 ){ cout << "Error: In Time\n"; exit(0);}
}

void poo_traffic::switching_activity(char *str, char packet_formation[][31])
{
    int kk = 0, ii;
    char lookup[63];
    int switching = (int) SWITCH_ACTIVITY*63;


    for(ii = 0; ii < 27; ii++)				//*** Timing flit
    	packet_formation[0][ii] = str[ii];

 
    for(ii = 0; ii < 63; ii++)
    {
	packet_formation[ii][BOP_BIT]='0';
    	packet_formation[ii][EOP_BIT]='0';		
    }
	packet_formation[62][EOP_BIT]='1';

    for(kk = 0; kk < 27; kk++)
    {
            for(ii=1;ii<63;ii++)			//*** Lookup Initialized.
            	lookup[ii]='0';
            

            for(ii=0;ii<switching;)
            {
                int rr = rand()%63;
                if(lookup[rr]=='0')			//*** Randomly make some lookup to be 1.
                {
            	    lookup[rr]='1';
            	    ii++;
            	}
            }

	    for(ii = 1; ii < 63; ii++)
	    {
	    	if(lookup[ii]=='0')
	    		packet_formation[ii][kk] = packet_formation[ii-1][kk];
	    	
	    	else	
	    	{
	    		if(packet_formation[ii-1][kk]=='1')
	    	        packet_formation[ii][kk]='0';
	    		else
	    			packet_formation[ii][kk]='1';
	    	}
	    }
    }

}

#endif
