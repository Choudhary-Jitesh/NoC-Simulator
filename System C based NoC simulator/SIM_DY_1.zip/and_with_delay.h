#ifndef AND_WITH_DELAY_MOD
#define AND_WITH_DELAY_MOD

#include "d_ff/dff.h"

SC_MODULE(and_with_delay)
{
	sc_in<bool> i;
	sc_out<bool> o;
	sc_in_clk clk;

	sc_signal<bool> id;

	dff *dff_d;

	void cl()
	{
		o.write(i.read() & id.read());
 	}

	SC_CTOR(and_with_delay)
	{
	    SC_METHOD(cl);
		sensitive << i << id;

		dff_d = new dff("dff_d");
		dff_d->i(i);
		dff_d->o(id);
		dff_d->clk(clk);

	}

	~and_with_delay()           //*** destructor.
	{
	    delete dff_d;
	}
};



#endif
