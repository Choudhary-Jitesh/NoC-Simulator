#ifndef penc_mod_dyn
#define penc_mod_dyn

//#include "configParam.h"
#include "initParam.h"

SC_MODULE (priority_encoder_dyn)	
{	
	sc_in<bool> reset, en;
	sc_in_clk clk;
	sc_in<bool> *in;//[MAX_LINK1];
	sc_out<bool> *out_pe;//[MAX_LINK1];

	sc_signal<bool> *r;//[MAX_LINK1];
	
	void priority_encoder_process1_dyn()		
    	{	
		for(int count = 0; count < MAX_LINK1; count++)
       	 		r[count].write(in[count].read() );
	}


	void priority_encoder_process2_dyn()		
	{	
		bool temp;
		for(int count = 0; count < MAX_LINK1; count++)	
		{
			temp = en.read();
			for(int j = 0; j < count; j++)
				temp &= ( !r[j] );
			temp &= r[count];
			out_pe[count].write( temp );
		}
	}
	
	SC_CTOR(priority_encoder_dyn)
    	{ //cout<<"here in priority_encoder_dyn\n";
    		in = new sc_in<bool> [MAX_LINK1];
    		out_pe = new sc_out<bool> [MAX_LINK1];
    		r = new sc_signal<bool> [MAX_LINK1];
    	
		SC_METHOD(priority_encoder_process1_dyn);
        	sensitive << en;
		for(int count = 0; count < (MAX_LINK1); count++)
			sensitive << in[count] << out_pe[count];

		SC_METHOD(priority_encoder_process2_dyn);
        	sensitive << en << clk.pos() << reset;
		for(int count = 0; count < (MAX_LINK1); count++)
			sensitive << r[count];
	}
	
	~priority_encoder_dyn()		{			//***  destructor
		delete[] in;
		delete[] out_pe;
		delete[] r;
	}
};
	
#endif
