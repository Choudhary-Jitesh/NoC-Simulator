#ifndef penc_mod
#define penc_mod

#include "configParam.h"

SC_MODULE (priority_encoder)	
{	
	sc_in<bool> reset, en;
	sc_in_clk clk;
	sc_out<bool> out[MAX_VC];
	sc_in<bool> in[MAX_VC];

	sc_signal<bool> r[MAX_VC];

	int count, j;
	
	void priority_encoder_process1()		
    	{	
		for(count = 0; count < MAX_VC; count++)
       	 		r[count].write(in[count].read() );
	}


	void priority_encoder_process2()		
	{	
		bool temp;
		for(count = 0; count < MAX_VC; count++)	
		{
			temp = en.read();
			for(j = 0; j < count; j++)
				temp &= ( !r[j] );
			temp &= r[count];
			out[count].write( temp );
		}
	}

	SC_CTOR(priority_encoder)
    	{ //cout<<"here priority enc\n";
		SC_METHOD(priority_encoder_process1);
        	sensitive << en;
		for(count = 0; count < MAX_VC; count++)
			sensitive << in[count] << out[count];

		SC_METHOD(priority_encoder_process2);
        	sensitive << en << clk.pos() << reset;
		for(count = 0; count < MAX_VC; count++)
			sensitive << r[count];
	}
	
	~priority_encoder(){}					//***  destructor
};
	
#endif
