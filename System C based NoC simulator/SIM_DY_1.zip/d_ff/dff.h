#ifndef DFF_STORE
#define DFF_STORE

#include "../configParam.h"

SC_MODULE(dff)
{
	sc_in<bool> i;
	sc_out<bool> o;
   	sc_in_clk  clk;


	void store()
	{	
		o.write(i.read());		//*** one clock(delta-cycle) delay.
	}

	SC_CTOR(dff)
	{
		SC_METHOD(store);
			sensitive << clk.pos();
	}

	~dff()	{}	//*** destructor.
};

#endif
