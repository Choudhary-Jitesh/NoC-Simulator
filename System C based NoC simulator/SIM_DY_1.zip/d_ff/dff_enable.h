#ifndef DFF_ENABLE
#define DFF_ENABLE

#include "../configParam.h"

SC_MODULE(dff_enable)
  {

    sc_in<bool> d,ce;
    sc_in_clk clk;
     
    sc_out<bool> q;
    
    void enter_on_enable()
      {
         if(ce.read()==true)
            q.write(d.read());
      }
      
    SC_CTOR(dff_enable)
     {
       SC_METHOD(enter_on_enable);
       	sensitive << clk.pos();

     }

  };


#endif
