
#ifndef R9
#define R9

#include "../configParam.h"

SC_MODULE (dff_synch_set) 
{
	sc_in<bool> d;
	sc_in<bool> set;
	sc_in_clk clk;
	sc_out<bool> q;

	void dff_synch_set_process() {

		if (set.read()==true)
			q.write(true);
		else
			q.write(d.read());
	}

	SC_CTOR(dff_synch_set)
	{
		SC_METHOD(dff_synch_set_process);
		sensitive << clk.pos();
	}
};


#endif
