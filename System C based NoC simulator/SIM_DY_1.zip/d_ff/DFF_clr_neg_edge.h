#ifndef DFF_NEG
#define DFF_NEG

#include "systemc.h"

SC_MODULE (DFF_clr_neg_edge) 
{
	sc_in<bool> d;
	sc_in<bool> clr;
	sc_in_clk clk;
	sc_out<bool> q;
	
	//sc_signal<bool> temp;
	
	void DFF_clr_neg_edge_process()
	{
		if (clr.read()==true)
			q.write(false);
		else 
			q.write(d.read());
	}

	SC_CTOR(DFF_clr_neg_edge)
	{
		SC_METHOD(DFF_clr_neg_edge_process);
		sensitive<<clk.neg();
	}
};

#endif
