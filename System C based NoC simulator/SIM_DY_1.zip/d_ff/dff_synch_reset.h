#ifndef dsr
#define dsr

#include "systemc"
#include <iostream>

using namespace std;
using namespace sc_core;
using namespace sc_dt;


SC_MODULE (dff_synch_reset) 
{
	sc_in<bool> d;
	sc_in<bool> reset;
	sc_in_clk clk;
	sc_out<bool> q;

	void dff_synch_reset_process() 
	{
		if (reset.read()==true)
		{
			q.write(false);
		}
		else 
		{
			q.write(d.read());
		}
	}

	SC_CTOR(dff_synch_reset)
	{
		SC_METHOD(dff_synch_reset_process);
		sensitive << clk.pos();
	}

};

#endif
