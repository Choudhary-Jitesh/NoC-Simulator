#ifndef DFF_ASYNC_SET
#define DFF_ASYNC_SET

#include "../configParam.h"

SC_MODULE(dff_asynch_set) 
{
	sc_in<bool> d;
	sc_in<bool> set;
	sc_in_clk clk;
	sc_out<bool> q;

	void dff_asynch_set_process() 
	{

		if (set.read()==true)
			q.write(true);
		else
			q.write(d.read());
	}
	
	SC_CTOR(dff_asynch_set)
	{
		SC_METHOD(dff_asynch_set_process);
		sensitive << clk.pos() << set.pos();
	}

};

#endif
