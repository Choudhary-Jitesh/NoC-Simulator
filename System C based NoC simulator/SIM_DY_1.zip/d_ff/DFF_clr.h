#ifndef DFF_1
#define DFF_1

#include "systemc.h"

SC_MODULE (DFF_clr) 
{
	sc_in<bool> d;
	sc_in<bool> clr;
	sc_in_clk clk;
	sc_out<bool> q;
	
	//sc_signal<bool> temp;
	
	void DFF_clr_process()
	{
		if (clr.read()==true)
			q.write(false);
		else 
			q.write(d.read());
	}

	SC_CTOR(DFF_clr)
	{
		SC_METHOD(DFF_clr_process);
		sensitive<<clk.pos();
	}
};

#endif
