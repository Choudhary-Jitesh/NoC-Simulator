#ifndef DFF_
#define DFF_

#include "../configParam.h"

SC_MODULE (DFF_asynch_clr) 
{
	sc_in<bool> D;
	sc_in<bool> clr;
	sc_in_clk clk;
	sc_out<bool> Q;
	
	void DFF_asynch_clr_process()
	{
		if(clr.read()==true)	Q.write(false);
		else 			Q.write(D.read());
	}
	
	SC_CTOR (DFF_asynch_clr)
	{
		SC_METHOD(DFF_asynch_clr_process);
		sensitive<<clk.pos()<<clr.pos();
	}
};

#endif
