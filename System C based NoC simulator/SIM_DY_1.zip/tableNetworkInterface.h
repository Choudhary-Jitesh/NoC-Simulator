#ifndef Network_macros
#define Network_macros

#include "reg/register_32bit.h"
#include "delay_element.h"
#include "initParam.h"

#define display_count  \
fp_in_payload_00 <<  " source_router  " << source[vc_id_v] << "  , destination_router  " << dest[vc_id_v] << " confirm count " << in_flit_count[vc_id_v] << endl;            \


FILE *fpe,*fp_scs,*fpEND;

/*int bin_to_dec(char *str,int length)
{
       int val = 0;
       for(int loop = 0; loop < length; loop++)
           if(str[loop] == '1')
                val += (int)pow(2.0,loop);

        return val;
}*/

//NOTE: The flits coming out from the output text file are 31bit, so adding 1 more gt_be bit=0 (for the time being) in it
//also each packet has 65 flits including the last invalid flit.

//network_interfacei_jk = Network Interface acting as core i for the leaf router with row number j & column number k

SC_MODULE(network_interface)
{
	sc_signal<bool> data_valid;
	sc_out<sc_uint<32> > packet_out;
	sc_signal<sc_uint<32> > traffic;

	// i = no. of packet received within time window,
	// l = no. of total packet sent, 
	// m = no. of total packet received.
	sc_signal<int> i, l, m;
	sc_signal<long int> packet_rec_time;
	sc_signal<double> total_latency;
	
	sc_signal<int> suc_count;
	sc_out <int> temp_suc_count;
	sc_out<double> temp_total_latency;

	sc_in<sc_uint<32> > packet_in;
	sc_in<bool> full_req[MAX_VC];
	sc_in<bool> reset;
	sc_in_clk clk_core;

	sc_signal<bool> high;
	sc_signal<sc_uint<32> > data1;
	sc_signal<sc_uint<32> > header;
	sc_signal<sc_uint<32> > packet_start_timing;
	sc_signal<bool> get_new_packet;

	sc_signal<int> out_flit_count;


	char packet[2016];	//65 flits each of size 31 bits and a null character at the end
	char traffic_out[33];	//32 bit traffic
	char reverse_traffic_out[35],chnl_adj[35]; //traffic_out has to be flipped and 0b is added in front for those statements where traffic_out is used as a name
	char tailer[35];
	//note: packet[0]:LSB, traffic_out[0]:LSB, reverse_traffic_out[0,1,2]:0,b,MSB
	char a_traffic_out[33],a_reverse_traffic_out[35];

	bool output_header_flag;
	bool input_header_flag[4];
	int starting_flit;

    	int vc_id_v;

    	int generated_time;

	int j,k;
	//bool eop,bop,gt_be;
	int pointer;
	sc_signal<int> packet_number;
	sc_out <int> packet_number1;

        int s_count;

        int dest[4], source[4];

        char flit_count[6];
        
        int si, di;

	int in_flit_count[4];

	sc_uint<32> packet_in_timer;
	sc_uint<32> start, msb1;
	sc_uint<64> waiting_time;
	//int vc_id;
	
	long int latency;
        char name[10];
        
        register_32bit reg1;
	delay_element del_elem;

        ifstream fp_out_payload_00;
        ofstream fp_in_payload_00;	
	
	void read_packet_out_process()
	{	//cout<<"in NI pkt read\n";
		// reading a packet(65 flits each of 31 bit) from the core txt file
		if(get_new_packet.read() == true && fp_out_payload_00.getline(packet,2016))
		{
			pointer = 0;			// pointer points to the first flit of the packet retrieved
			packet_number = packet_number+1;
		}
		packet_number1 = packet_number;
	}

	void network_interface_packet_out_process()
	{	//cout<<"in NI pkt out\n";
        	while(1)
        	{
            		wait();                                 //wait for the next clock cycle
            		
            		bool full_req_all = 0;
            		for(int count = 0; count < MAX_VC; count++)
            			full_req_all |= full_req[count];
            			
            		if(reset.read()==true)
            		{	
               			traffic.write("0b01100000000000000000000000000000");		// Invalid Data.
                		get_new_packet.write(1);
            		}
            		
            		else if( ( !full_req_all ) && ( pointer <= 1984 ))
            		{	// At 1984 the last flit i.e the 65th invalid flit of the packet is pointed.
                		// Retrieving a flit from a packet
                		for( k=0; k < 31; k++)
                    			traffic_out[k] = packet[pointer+k];
                    			
                		traffic_out[31]='0';	// putting gt_be = 0
                		traffic_out[32]='\0';

				// Flipping the bits MSB<->LSB for the statements where traffic_out is used as a name
                		for(j=0;j<32;j++)
                		{
                    			reverse_traffic_out[j+2] = traffic_out[31-j];
                    			chnl_adj[j+2] = traffic_out[31-j];
                		}
                		reverse_traffic_out[34] = '\0';
                		chnl_adj[34] = '\0';
                		
                		pointer += 31;	// pointer points to next flit.

                		if(pointer == 2015)		//the last element
                		{
                    			get_new_packet.write(1);
                    			//vc_id += 1;	
                    		}
                                else
                    			get_new_packet.write(0);

                		reverse_traffic_out[0]= '0';
                		reverse_traffic_out[1]= 'b';
                		//reverse_traffic_out[5]= vc_id[1] + 48;
                		//reverse_traffic_out[6]= vc_id[0] + 48;

                		chnl_adj[0]='0';
                		chnl_adj[1]='b';
                		chnl_adj[5]='0';		//*** Setting VC info to zero for calculation of timing.
                		chnl_adj[6]='0';

                		bool gt_be = traffic_out[31]-'0';
                		bool eop = traffic_out[30]-'0';
                		bool bop = traffic_out[29]-'0';
                		
                		if((eop == 0) && (bop == 1))				//*** Header flit
                		{
                    			s_count = 1;
                    			sc_uint<8> str;
                    			for(int loop = 0; loop < 8; loop++)
                        			str[loop] = traffic_out[loop] - '0';
                    			di = str;

                    			for(int loop = 0; loop < 8; loop++)
                        			str[loop] = traffic_out[loop+8] -'0';
                    			si = str;
                		}

                		else if((eop==0) && (bop==0))
                    			s_count++;

                		else if((eop==1) && (bop==0))
                		{
                    			s_count++;
                    			if(s_count!=64)
                        			fprintf(fpe,"CORE: ERROR: Time = %f , NI : %s , S : %d , D: %d , No_of_flits_sent = %d \n",sc_simulation_time(),name,si,di,s_count);
                		}
                		
                		if(eop==0 && bop==1)		// header flit
                		{
                			//traffic_out has to be flipped for these kind of statements where traffic_out is used as a name.
                    			header.write(reverse_traffic_out);
                    			output_header_flag = 1;
                    			starting_flit = 0;
                    			l.write(l.read()+1);
                		}
                		else if(output_header_flag==1 && eop==0 && bop==0)	//timing flit
                		{
                    			output_header_flag = 0;
					//extracting the time info from the timer flit
                    			if(gt_be==1)//just a provision right now for future
                    			{
                        			sc_uint<32> start0 = chnl_adj;
                        			sc_uint<32> start1 = msb1;
                        			start = start0 - start1;
                    			}
                    			else
                    			{
                        			start = chnl_adj;
                        			start *= CLK_PERIOD;
                    			}
                    			
                   			packet_start_timing.write(reverse_traffic_out);
                    			if(sc_simulation_time() < start)
                    			{
                        			waiting_time = start - sc_simulation_time();
                        			traffic.write("0b01100000000000000000000000000000");
                        			wait(waiting_time,SC_NS);
                    			}
                		}

                		else if((sc_simulation_time() >= start)==true && (eop & bop)==false)
                		{	
                    			if(starting_flit == 0)
                    			{	
                        			wait(CLK_PERIOD,SC_NS);		//should be equal to the clock period
                        			wait(delay,SC_NS); 		//should be equal to the delay
                        			traffic.write(header.read());
                        			generated_time = start;

                        			if(generated_time > SIMULATION_TIME)
                            				fprintf(fpEND," core %s ends at %f , s = %d ,r = %d \n",name,(float)generated_time, si, di);

                        			fprintf(fpe,"s = %d r = %d,packet generated at ni %f  ,send to router at %f \n",si,di,((float)generated_time),sc_simulation_time());
                        			fflush(fpe);
                        			out_flit_count.write(1);
                        			
                        			wait(CLK_PERIOD,SC_NS);		//should be equal to the clock period
                        			traffic.write(packet_start_timing.read());
                        			out_flit_count.write(2);
                        			starting_flit = 1;
                        			
                    			}

                    			wait(CLK_PERIOD,SC_NS);			//should be equal to the clock period

                    			traffic.write(reverse_traffic_out);
                    			out_flit_count.write(out_flit_count.read() + 1);
                    		
                		}
                		else
                		{	
                			wait(CLK_PERIOD,SC_NS);	//should be equal to the clock period
                    			traffic.write("0b01100000000000000000000000000000");
                    			
                		}
            		}
            		else
            		{	
               	 		wait(CLK_PERIOD,SC_NS); //should be equal to the clock period
                		traffic.write("0b01100000000000000000000000000000");
                		
            		}
		}	// end while
	} 	// network_interface_packet_out_process ends

	void data_valid_process()
	{	//cout<<"in NI data valid\n";
		data_valid.write(!(packet_out.read()[30] & packet_out.read()[29]));
	}

	void network_interface_packet_in_process()
	{	
		if(fp_in_payload_00.good()==true && reset.read()==false)
		{
			vc_id_v = 2*packet_in.read()[28] + packet_in.read()[27];

			if(packet_in.read()[30] == false && packet_in.read()[29] == true)	//Header flit
			{                		
                		dest[vc_id_v] = packet_in.read().range(7,0);
                		source[vc_id_v]= packet_in.read().range(15,8);

                		fp_in_payload_00 << " header " << endl;

				input_header_flag[vc_id_v]=1;
				in_flit_count[vc_id_v] = 1;
				
				display_count
			}

			else if(input_header_flag[vc_id_v]==1 && packet_in.read()[30]==false && packet_in.read()[29]==false)//timer flit
			{
				input_header_flag[vc_id_v] = 0;
				packet_in_timer = packet_in.read().range(26,0);		//*** changed here. Previous range was 0 - 20.
				packet_in_timer[27]=0;
				packet_in_timer[28]=0;
				packet_in_timer = packet_in_timer*CLK_PERIOD;
				in_flit_count[vc_id_v] = 2;
				//m.write(m.read()+1);

                		display_count
			}

			else if(input_header_flag[vc_id_v] == 0 && packet_in.read()[30]==false && packet_in.read()[29]==false)//body flit
			{
				in_flit_count[vc_id_v] = in_flit_count[vc_id_v] + 1;
				
                		display_count
			}


			else if(packet_in.read()[30]==true && packet_in.read()[29]==false /*&& (sc_simulation_time()>SAT_TIME_00)*/ )	//tailer
			{	
				m.write(m.read()+1);
				//cout<<"in NI pkt in\n";
				if( sc_simulation_time() > SAT_TIME_00 )	{
						
					//i.write(i.read()+1); 
					packet_rec_time.write((long int)sc_simulation_time());
                			in_flit_count[vc_id_v] = in_flit_count[vc_id_v] + 1;
                		
                			display_count

					fp_in_payload_00 << "Packet " << (i.read()+1)   << ":\n Source core = " << source[vc_id_v] << endl;
					fp_in_payload_00 << "Starting Time = "<< packet_in_timer << endl;
					fp_in_payload_00 << "Arrival Time = "<< sc_simulation_time() << endl;

					if(packet_in_timer <= sc_simulation_time())
					{
						latency = (long int)sc_simulation_time() - packet_in_timer;
						fp_in_payload_00 << "Latency for packet " <<  (i.read()+1)  << " = "<< latency << endl;

						total_latency.write(total_latency.read()+(double)latency);
						fp_in_payload_00 << "Total Latency for "<< (i.read()+1)  << " number of packet = "<<(total_latency.read()+(double)latency) << endl;
						fp_in_payload_00 << "Average Latency for "<< (i.read()+1)  << " number of packet = "<< ((total_latency.read()+(double)latency)/(i.read()+1)) << "\n" <<endl;
					}
					else
                			{
                    				fprintf(fpe,"ERROR!!! time %f ,s : %d , d: %d , confirm receiver : %s , vc_id :%d START TIME GREATER THAN FINISH TIME \n",sc_simulation_time(),source[vc_id_v],dest[vc_id_v],name , vc_id_v);
				    		fflush(fpe);
                			}

					fp_in_payload_00 << "Input flit count = "<< in_flit_count[vc_id_v] << endl;

					if(in_flit_count[vc_id_v] != PKT_SIZE)
                			{
                				fprintf(fpe,"ERROR!!! time %f, s : %d ,d : %d ,confirm receiver : %s , vc_id :%d ,flits recieved :%d , FLIT MISSING in PACKET RECEIVED\n",sc_simulation_time(),source[vc_id_v],dest[vc_id_v],name,vc_id_v,in_flit_count[vc_id_v]);
                    				fflush(fpe);
                			}
					else
					{
						i.write(i.read()+1);
						suc_count.write(suc_count.read()+1);
						fp_in_payload_00<<(suc_count.read()+1) << " time " << sc_simulation_time() << "   s : " << source[vc_id_v] <<" d : " << dest[vc_id_v] << "confirm receiver :" << name <<" PACKET RECEIVED SUCCESSFULLY" << "\n" << endl;
                    				fprintf(fp_scs ," time : %f , s : %d , d %d , confirm receiver : %s , packet recieved successfully \n" ,sc_simulation_time(),source[vc_id_v],dest[vc_id_v],name);
                    				fflush(fp_scs);
					}

					fp_in_payload_00 << "-----------------------------------------------------------" << "\n" << endl;
				}
			}
		}
	}

    	void assign_lat_thr()
    	{	
        	temp_total_latency = total_latency;
        	temp_suc_count = suc_count;
    	}

	SC_CTOR(network_interface):reg1("reg1"),del_elem("del_elem")
	{
		suc_count.write(0);
		msb1 = "0b10000000000000000000000000000000";
		//cout<<"in NI1\n";
		high.write(true);
		
		output_header_flag = 0;
		starting_flit = 0;
		pointer = 0;
		latency = 0;
		packet_number = 0;
		//vc_id = 0;

		SC_METHOD(read_packet_out_process);
			sensitive_pos << get_new_packet;

		SC_THREAD(network_interface_packet_out_process);
			sensitive << reset << clk_core.pos() << traffic <<  packet_out;
			for(int count = 0; count < MAX_VC; count++)
				sensitive << full_req[count];

		SC_METHOD(data_valid_process);
			sensitive << packet_out << clk_core.pos();

		SC_METHOD(network_interface_packet_in_process);
			sensitive << reset << clk_core.pos();

		SC_METHOD(assign_lat_thr);
			sensitive << total_latency << suc_count;


		reg1.din(traffic);
		reg1.clk(clk_core);
		reg1.clr(reset);
		reg1.ce(high);
		reg1.dout(data1);

		del_elem.din(data1);
		del_elem.ce(high);
		del_elem.dout(packet_out);
	}
};

#endif
