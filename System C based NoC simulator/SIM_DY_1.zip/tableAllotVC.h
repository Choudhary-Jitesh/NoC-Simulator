#ifndef alt
#define alt


#include "reg/register_1bit.h"
#include "reg/register_4bit.h"
#include "tableMUX_1.h"

SC_MODULE(allot_vc)
{
	int total_link;

	sc_in<bool> reset;
	sc_in_clk  rd_clk;
	sc_in<bool>  *g , *tailer;
	sc_in<sc_uint<LINK_BIT + VC_BIT> > encoded_addr;
	sc_out<bool> b[MAX_VC];				// Status of ith VC. 
	sc_out<sc_uint<LINK_BIT + VC_BIT> > e[MAX_VC];
	sc_out<bool> gnt_or;
	
	sc_signal<bool> ce_b[MAX_VC], clr_b[MAX_VC];
	sc_signal<bool> high, mux_out[MAX_VC];
	sc_uint<LINK_BIT + VC_BIT> e_temp;
	sc_bv<LINK_BIT> alink[MAX_VC], alink_temp;
	sc_bv<VC_BIT> avc_id[MAX_VC], avc_id_temp;

	register_1bit *r1[MAX_VC];

	register_4bit *r4[MAX_VC];

	mux_sel *m[MAX_VC];

	int i,j;

	void grant_process()
	{
		bool gnt_or_temp = 0;
		for(i = 0; i < MAX_VC*(total_link); i++)
			gnt_or_temp |= g[i];
		gnt_or.write(gnt_or_temp);
	}

	void allot_vc_process()
	{		
		bool temp;
		for(i = 0; i < MAX_VC; i++)	
		{
			temp =  gnt_or.read();
			for(j = 0;j < i; j++)
				temp &= b[j];
			temp &= !b[i];
			ce_b[i].write(temp);
		}

		for(i = 0; i < MAX_VC; i++)
			clr_b[i].write( (!mux_out[i].read()) & b[i].read());

	}

	SC_HAS_PROCESS(allot_vc);
	allot_vc(sc_module_name nm, int total): sc_module(nm), total_link(total)
	{
		//cout<<"here in allot vc\n";
		g = new sc_in<bool>[MAX_VC*(total_link)];
		tailer = new sc_in<bool>[MAX_VC*(total_link)];
		
		high.write(true);
		char str[10];
		for(i = 0; i < MAX_VC; i++)	
		{
			sprintf(str,"r1(%0d)", i);
			r1[i] = new register_1bit(str);

			r1[i]->din(high);
			r1[i]->clk(rd_clk);
			r1[i]->ce(ce_b[i]);
			r1[i]->clr(clr_b[i]);
			r1[i]->dout(b[i]);
		}

		for(i = 0; i < MAX_VC; i++)	
		{
			sprintf(str,"r4(%0d)", i);
			r4[i] = new register_4bit(str);

			r4[i]->din(encoded_addr);
			r4[i]->clk(rd_clk);
			r4[i]->ce(ce_b[i]);
			r4[i]->clr(reset);
			r4[i]->dout(e[i]);
		}

		for(i = 0; i < MAX_VC; i++)	
		{
			sprintf(str,"m(%0d)", i);
			m[i] = new mux_sel(str, total_link);
			
			for(j = 0;j < MAX_VC*(total_link); j++)
				m[i]->t[j]( tailer[j] );
				
			m[i]->sel(e[i]);
			m[i]->m_out(mux_out[i]);

		}

		SC_METHOD(grant_process);
			sensitive << rd_clk.pos();
			for(j = 0;j < MAX_VC*(total_link); j++)
				sensitive << g[j] << tailer[j];

		SC_METHOD(allot_vc_process);
			sensitive << gnt_or << rd_clk.pos() << reset;
			for(i = 0; i < MAX_VC; i++)
				sensitive << mux_out[i] << b[i];
	}

	~allot_vc()							//*** destructor
	{
		for(int count = 0; count < MAX_VC; count++)
		{
			delete r1[count];
			delete r4[count];
			delete m[count];
		}
		delete[] g;
		delete[] tailer;
	}

};

#endif
