#ifndef IPC
#define IPC

#include "routerFIFO.h"
#include "reg/register_32bit.h"
#include "IRS.h"
#include "d_ff/dff_synch_reset.h"
#include "d_ff/dff_synch_set.h"
#include "tableRoutingAlgo.h"

SC_MODULE(ip_chnl)
{
	int total_link;

	sc_in<bool> reset, rd_clk, wr_clk, rd_en, wr_en;
	sc_in<sc_uint<FLIT_LEN> > data_in;
	sc_in<sc_uint<ADD_BIT_LEN> > current_address;
	sc_in<int> **outLinkBufferStatus;
	
	sc_out<int> localBufferStatus;
	sc_out<bool> full_ext, empty_synch_rdclk;
	sc_out<bool> *req_l;  
	sc_out<sc_uint<FLIT_LEN> > data_out;
	sc_out<bool> tailer_org;

	sc_signal<bool> tailer;
	sc_signal<bool> *reqa, *reqs;
	sc_signal<bool> data_sel;
	sc_signal<bool> header, empty;
	sc_signal<sc_uint<FLIT_LEN> > fifo_out, header_flit, mux_data_out, header_out;//, router_out;
	sc_signal<bool> rd_en_out, rd_en_out2, clr1;
	
	sc_signal<bool> wr_dir,rd_dir;
	sc_signal<sc_uint<BUFFER_BIT_LEN> > wr_add, rd_add;
	sc_signal<bool> wen_int, full_int, ren_int;

	dff_synch_reset **d;
	router_fifo *r1;
	register_32bit *reg2;
	routing *routingLogic;
	IRS *irs1;
	dff_synch_reset *dff_tailer;
	dff_synch_set *dff_empty;
	
	sc_trace_file *ft;
	
	void assign1()
	{	
		header.write((!fifo_out.read()[30]) & fifo_out.read()[29]);
		tailer_org.write(fifo_out.read()[30] & (!fifo_out.read()[29]));
	}

	void ip_chnl_process()
	{	
		clr1.write(reset | tailer);

		if(header.read()==true)
			header_out.write(fifo_out.read());
		else
			header_out.write(header_flit.read());
	}

	void ip_chnl1_process()
	{	
		if(data_sel.read()==true)
			mux_data_out.write(header_flit);
		else
			mux_data_out.write(fifo_out);
	}

	void ip_chnl2_process()
	{	
		data_out.write(mux_data_out);
                rd_en_out2.write(rd_en_out.read() & (!tailer_org.read()));
	}

	void ip_chnl3()
	{	
		for(int count = 0; count < total_link; count++)
			req_l[count] = reqa[count] & reqs[count];
	}

	SC_HAS_PROCESS(ip_chnl);
	ip_chnl(sc_module_name nm, int link, int total, int buffer_size, int router, int vc):sc_module(nm), total_link(total)
	{
		int count;
        //cout<<"here in channel in\n";
		r1 = new router_fifo("r1",buffer_size);
		reg2 = new register_32bit("reg2");
		routingLogic = new routing("routingLogic", link, total_link, vc);
		irs1 = new IRS("irs1");
		dff_tailer = new dff_synch_reset("dff_tailer");
		dff_empty = new dff_synch_set("dff_empty");

		d = new dff_synch_reset*[total_link];
		reqa = new sc_signal<bool>[total_link];
		reqs = new sc_signal<bool>[total_link];
		req_l = new sc_out<bool>[total_link];
		
		if( routingAlgo == OE_NOP )	{
            		outLinkBufferStatus = new sc_in<int>*[MAX_LINK];
            		for( count = 0; count < MAX_LINK; count++ )
            			outLinkBufferStatus[count] = new sc_in<int> [MAX_LINK];
            	}
            	else	{
            		outLinkBufferStatus = new sc_in<int>*[1];
            		outLinkBufferStatus[0] = new sc_in<int>[1];
            	}

		//*** router_fifo
		r1->reset(reset);
		r1->rd_clk(rd_clk);
		r1->rd_en(rd_en_out2);
		r1->data_in(data_in);
		r1->wr_clk(wr_clk);
		r1->wr_en(wr_en);
		r1->data_out(fifo_out);
		r1->full_ext(full_ext);
		r1->empty(empty);
		r1->bufferStatus(localBufferStatus);
		r1->rd_add(rd_add);
		r1->wr_add(wr_add);
		r1->rd_dir(rd_dir);
		r1->wr_dir(wr_dir);
		r1->wen_int(wen_int);
		r1->ren_int(ren_int);
		r1->full_int(full_int);
		
		//*** reg_32_bit
		reg2->dout(header_flit);
		reg2->din(fifo_out);
		reg2->clk(rd_clk);
		reg2->clr(clr1);
		reg2->ce(header);

		//*** routing_table
		routingLogic->header_in(header_out);
		routingLogic->current_address(current_address);
		routingLogic->reset(reset);
		for(count = 0; count < total_link; count++)
			routingLogic->req_link[count](reqa[count]);
		if( routingAlgo == OE_NOP )
		 	for(int j = 0; j < MAX_LINK; j++)
				for(count = 0; count < MAX_LINK; count++)
					routingLogic->outBufferStatus[j][count]( outLinkBufferStatus[j][count] );
		else	routingLogic->outBufferStatus[0][0]( outLinkBufferStatus[0][0] );

		//*** dff_synch_reset
		char str[50];
		for(count = 0; count < total_link; count++)
		{
			sprintf(str,"d(%0d)",count);
			d[count] = new dff_synch_reset(str);

			d[count]->d(reqa[count]);
			d[count]->clk(rd_clk);
			d[count]->q(reqs[count]);
			d[count]->reset(reset);
		}

		//*** IRS
		irs1->reset(reset);
		irs1->empty(empty);
		irs1->rd_en(rd_en);
		irs1->rd_clk(rd_clk);
		irs1->tailer_org(tailer_org);
		irs1->tailer(tailer);
		irs1->rd_en_out(rd_en_out);
		irs1->header(header);
		irs1->data_sel(data_sel);


		dff_tailer->d(tailer_org);
		dff_tailer->clk(rd_clk);
		dff_tailer->reset(reset);
		dff_tailer->q(tailer);

		//*** dff_synch_set
		dff_empty->d(empty);
		dff_empty->clk(rd_clk);
		dff_empty->set(reset);
		dff_empty->q(empty_synch_rdclk);

		SC_METHOD(assign1);
			sensitive << fifo_out << reset << rd_clk;

		SC_METHOD(ip_chnl_process);
			sensitive << reset << rd_clk << wr_clk << header << tailer << rd_en << rd_en_out2;

		SC_METHOD(ip_chnl1_process);
			sensitive << rd_clk << data_sel << rd_en << fifo_out;

		SC_METHOD(ip_chnl2_process);
			sensitive << mux_data_out << rd_en_out << tailer_org;

		SC_METHOD(ip_chnl3);
		for(count = 0; count < total_link; count++)
			sensitive << reqa[count] << reqs[count];
		
		if( traceMode == 1 )	{	
			sprintf(str,"%strace/in_chnl_trace%0d_%0d_%0d",resultFolder,router,link,vc);
			ft = sc_create_vcd_trace_file(str);
			sc_trace(ft,reset,"reset");
			sc_trace(ft,rd_clk,"rd_clk");
			sc_trace(ft,wr_clk,"wr_clk");
			sc_trace(ft,rd_en,"rd_en");
			sc_trace(ft,wr_en,"wr_en");
			sc_trace(ft,rd_add,"rd_add");
			sc_trace(ft,wr_add,"wr_add");
			sc_trace(ft,rd_dir,"rd_dir");
			sc_trace(ft,wr_dir,"wr_dir");
			sc_trace(ft,full_int,"full_int");
			sc_trace(ft,wen_int,"wen_int");
			sc_trace(ft,ren_int,"ren_int");
			sc_trace(ft,header,"header");
			sc_trace(ft,tailer_org,"tailer_org");
			sc_trace(ft,tailer,"tailer");
			sc_trace(ft,data_sel,"data_sel");
			sc_trace(ft,rd_en_out,"rd_en_out");
			sc_trace(ft,rd_en_out2,"rd_en_out2");
			sc_trace(ft,data_in,"data_in");
			sc_trace(ft,full_ext,"full_ext");
			sc_trace(ft,empty,"empty");
			sc_trace(ft,empty_synch_rdclk,"empty_synch_rdclk");
			sc_trace(ft,clr1,"clr1");
			sc_trace(ft,fifo_out,"fifo_out");
			sc_trace(ft,header_out,"header_out");
			sc_trace(ft,header_flit,"header_flit");
			sc_trace(ft,mux_data_out,"mux_data_out");
			sc_trace(ft,data_out,"data_out");
			sc_trace(ft,localBufferStatus,"localBufferStatus");
			if( routingAlgo == OE_NOP )
				for(int j = 0; j < MAX_LINK; j++)
					for(count = 0; count < MAX_LINK; count++)	{
						sprintf(str,"outLinkBufferStatus(%0d)(%0d)",j,count);
						sc_trace(ft,outLinkBufferStatus[j][count],str);
					}
			for(count = 0; count < total_link; count++)	{
				sprintf(str,"reqa(%0d)",count);
				sc_trace(ft,reqa[count],str);
				sprintf(str,"reqs(%0d)",count);
				sc_trace(ft,reqs[count],str);
				sprintf(str,"req_l(%0d)",count);
				sc_trace(ft,req_l[count],str);
			}
		}

	}

	~ip_chnl()
	{
		for(int count = 0; count < total_link; count++)
			delete d[count];
		delete[] d;
		delete[] reqs;
		delete[] reqa;
		delete[] req_l;
		if( routingAlgo == OE_NOP )
        		for(int count = 0; count < MAX_LINK; count++)
        			delete[] outLinkBufferStatus[count];
        	else	delete[] outLinkBufferStatus[0];
		delete[] outLinkBufferStatus;
		delete r1;
		delete reg2;
		delete routingLogic;
		delete irs1;
		delete dff_tailer;
		delete dff_empty;
		
		if( traceMode == 1 )
			sc_close_vcd_trace_file(ft);
	}
};

#endif
