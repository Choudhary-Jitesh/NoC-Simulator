#ifndef __INIT
#define __INIT

#include "configParam.h"

void initializeParam(int argc, char **argv)
{
	if(argc < 3)	{
		cout << "ERROR: Insufficient no. of parameters supplied" << endl;
		exit(1);
	}
	else	{
			MAX_ROUTER = DEF_MAX_ROUTER;
			MAX_LINK = DEF_MAX_LINK;
			MAX_CORE = DEF_MAX_CORE;
			SIMULATION_TIME = DEF_SIM_TIME;
			SAT_TIME_00 = DEF_SAT_TIME;
			routingAlgo = DEF_R_ALGO;
			inj_rate = 0;
			traceMode = 0;
			ext_table = 1;

			for(int count = 1; count < argc; count++)	{
				if( !strcmp(argv[count],"-r") )
					MAX_ROUTER = atoi(argv[count+1]);
				else if( !strcmp(argv[count],"-l") )
					MAX_LINK = atoi(argv[count+1]);
				else if( !strcmp(argv[count],"-c") )
					MAX_CORE = atoi(argv[count+1]);
				else if( !strcmp(argv[count],"-sim") )
					SIMULATION_TIME = atoi(argv[count+1]) * CLK_PERIOD;
				else if( !strcmp(argv[count],"-sat") )
					SAT_TIME_00 = atoi(argv[count+1]) * CLK_PERIOD;
				else if( !strcmp(argv[count],"-con") )
					routerConn = argv[count+1];
				else if( !strcmp(argv[count],"-traffic") )
					coreComm = argv[count+1];
				else if( !strcmp( argv[count],"-inj" ) )
					inj_rate = atof( argv[count + 1] );
				else if( !strcmp(argv[count],"-folder") )
					resultFolder = argv[count+1];
				else if( !strcmp(argv[count],"-routing") )
					routingAlgo = atoi(argv[count+1]);
				else if( !strcmp(argv[count],"-trace") )
					traceMode = 1;
				else if( !strcmp(argv[count],"-tab") )	{
					if( routingAlgo == TABLE )	{
						ext_table = 0;
						rTable = argv[count + 1];
					}
				}
			}
			if( routerConn == NULL)	{
				cout << "ERROR: Connection file not supplied" << endl;
				exit(1);
			}
			MAX_LINK1 = MAX_LINK + MAX_CORE;
			
			cout << "\n\t\tVirtual Channel Simulator" << endl;
			cout << "Simulation Time\t: " << setw(-6) << SIMULATION_TIME/CLK_PERIOD <<" cycles"<< endl;
			cout << "Saturation Time\t: " << setw(-6) << SAT_TIME_00/CLK_PERIOD <<" cycles" << endl;
			cout << "Routers\t\t: "<< MAX_ROUTER << endl;
			cout << "Max Links\t: "<< MAX_LINK1 << endl;
			cout << "Conn. File\t: "<< routerConn << endl;
			
			if( coreComm != NULL )
				cout << "Traffic\t\t: " << coreComm << endl;
			else if( inj_rate != 0)	
				cout << "Traffic\t\t: " << "SYNTHETIC\nInjection Rate\t: " << inj_rate << " Pkts/Cycle/IP" << endl;
			else	cout << "Traffic\t\t: " << "SUPPLIED" << endl;
			
			if( routingAlgo == XY )
				cout << "Routing Op\t: XY"<< endl;
			else if( routingAlgo == TABLE )	{
				cout << "Routing Op\t: TABLE"<< endl;
				if( ext_table == 0 )
					cout << "Routing File\t: "<< rTable << endl;
				else
					cout << "Routing File\t:"<< " NOT SUPPLIED" << endl;
			}
			else if( routingAlgo == OE_R )
				cout << "Routing Op\t: OE-Random"<< endl;
			else 	cout << "Routing Op\t: OE-NoP"<< endl;		
				
			if( resultFolder != NULL )
				cout << "Result Folder\t: "<< resultFolder << endl;
			else
				cout << "Result Folder\t: "<<" NOT SUPPLIED. Using Main Folder" << endl;
			
			if( traceMode == 1 )			
				cout << "Trace\t\t: ON" << endl;
	}
}

#endif
