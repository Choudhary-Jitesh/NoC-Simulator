#define encodey

// encoden  -- No ENCODER,
// encodey -- Has Encoder
