#include<stdio.h>
#include<systemc.h>

SC_MODULE (posedgecount)
{
       sc_in_clk inp;


        sc_signal<int>count;
    

       void edge_countprocess()
          {

             count.write(count.read()+1);
             printf("%d \n",count.read());
                   
          }

      SC_CTOR (posedgecount)
       {
	  count.write(0);
          SC_METHOD(edge_countprocess);
          sensitive << inp.pos() ;
       }

};

