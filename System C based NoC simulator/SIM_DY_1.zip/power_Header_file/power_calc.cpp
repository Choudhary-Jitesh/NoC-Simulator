/*
PURPOSE : THIS FILE CONTAINS TWO MODULE, THEY WILL GENERATE THE FORMATED FILE(S) FOR PRIME POWER TO CALCULATE THE POWER FOR ROUTER.
LAST UPDATED DATE: 10-NOV-2009
*/

#include "systemc.h"
//#include "enter.h"
#include "../config/define.cpp"

#ifndef _POWER_H
#define _POWER_H
template < typename type ,typename data_type ,typename ack_type , int in_port, int number >

class power_calc : public sc_module{

        private :
                int tog [ in_port + number + 64 ], no_1s [ in_port + number + 64  ] ;
                
                type prev_bit [ in_port + number + 64  ] ;
                char  file_name[50] , par0[50] , par1[50] , par2[50] , par3[50] , par4[50];
                fstream fp;
        public:
                sc_in < type > in [ in_port ] ;
                sc_in <data_type > data ;
                sc_in <ack_type >  ack [ number ];
                sc_in < bool > clk ;
                SC_HAS_PROCESS ( power_calc ) ;
                
                virtual void log_power ( void ) ;
                
                
                power_calc ( sc_module_name nm, const char *file_name_tmp ,const  char *t_par0, const char *t_par1 , const  char *t_par2,
                              const char *t_par3 ,const char *t_par4 ) : sc_module ( nm ) {
                        
                        strcpy ( par0 , t_par0 ) ;
                        strcpy ( par1 , t_par1 ) ;
                        strcpy ( par2 , t_par2 ) ;
                        strcpy ( par3 , t_par3 ) ;
                        strcpy ( par4 , t_par4 ) ;
                        strcpy ( file_name , file_name_tmp ) ;
                        for ( int i = 0 ; i < in_port + number + 64  ; i++){
                                  tog [ i ] = 0 ;
                                  no_1s [ i ] = 0 ;
                                   prev_bit [ i ] = false;
                        }                                  
                        SC_METHOD(log_power);
                                sensitive << clk.pos() ; //in [ in_port - 1 ].pos() ;
                        
                }
                ~power_calc() {
                       //cout << " I am here ! "<<endl; 
                       if ( strcmp ( par0,"NO") != 0 )
                            fp.open ( file_name , ios::out ); // if u remove the ios::out , it will not work.
                        else
                            fp.open ( file_name , ios::app | ios::out );
                      //fp.open ( file_name , ios::app | ios::out ); // if u remove the ios::out , it will not work.
                      if ( fp.good() ){
                      if ( strcmp ( par0,"NO") != 0 ){
                        fp << HEADER << endl;
                        fp << endl << POWER_STR0 << par0 <<"]    " << POWER_STR1<<(float)no_1s[ 0 ]/NO_SIMU_CLK <<POWER_STR2<<tog[0] <<POWER_STR3<<NO_SIMU_CLK*5<<endl;  
                      }
                      if ( strcmp ( par1,"NO") != 0 )
                      fp << endl << POWER_STR0 << par1 <<"]    " << POWER_STR1<<(float)no_1s[ 1 ]/NO_SIMU_CLK <<POWER_STR2<<tog[1] <<POWER_STR3<<NO_SIMU_CLK*5<<endl;  
                      if ( strcmp ( par2,"NO") != 0 )
                      fp << endl << POWER_STR0 << par2 <<"]    " << POWER_STR1<<(float)no_1s[ 2 ]/NO_SIMU_CLK <<POWER_STR2<<tog[2] <<POWER_STR3<<NO_SIMU_CLK*5<<endl;  
                      for ( int ii = 3 ; ii < in_port + 64; ii++ )
                        fp << endl << POWER_STR0 << par3 <<"["<< (ii - 3) <<"] ]   " << POWER_STR1<<(float)no_1s[ ii ]/NO_SIMU_CLK <<POWER_STR2<<tog[ii] <<POWER_STR3<<NO_SIMU_CLK*5<<endl;  
                      if ( strcmp ( par4,"NO") != 0 ){
                      fp << endl << POWER_STR0 << par4 << "_1]    " << POWER_STR1<<(float)no_1s[in_port - 3]/NO_SIMU_CLK <<POWER_STR2<<tog[in_port - 3] <<POWER_STR3<<NO_SIMU_CLK*5<<endl;
                      fp << endl << POWER_STR0 << par4 << "_2]    " << POWER_STR1<<(float)no_1s[in_port - 2]/NO_SIMU_CLK <<POWER_STR2<<tog[in_port - 3] <<POWER_STR3<<NO_SIMU_CLK*5<<endl;
                      fp << endl << POWER_STR0 << par4 << "_3]    " << POWER_STR1<<(float)no_1s[in_port - 1]/NO_SIMU_CLK <<POWER_STR2<<tog[in_port - 3] <<POWER_STR3<<NO_SIMU_CLK*5<<endl;
                      }
                      }
                      else{
                        cout << "POWER_CALC:: error \n";
                      } 
                      fp.close();
                }
        
};
template < typename type ,typename data_type ,typename ack_type , int in_port, int number >
void power_calc < type , data_type, ack_type, in_port, number > :: log_power ( void ) {   
         
          for ( int i = 0 ; i < in_port  ; i++ ) {
                if ( (prev_bit [ i ] ^ in [ i ].read() ) == SC_LOGIC_1 ) { // FIND Toggle(s)
                        tog [ i ] ++ ;
                        
                }
                if ( in [ i ] == SC_LOGIC_1 ) no_1s [ i ] ++;                 
                prev_bit [ i ] = in [ i ].read() ;
          }
          for ( int i = in_port ; i < in_port + 64  ; i++ ) {
                if ( (prev_bit [ i ] ^ ( type )(data.read().range(i - in_port , i - in_port)) ) == SC_LOGIC_1 ) { // FIND Toggle(s)
                        tog [ i ] ++ ;
                        
                }
                if ( (type)(data.read().range(i - in_port , i - in_port)) == SC_LOGIC_1 ) no_1s [ i ] ++;                 
                prev_bit [ i ] = data.read().range(i - in_port ,i - in_port) ;  
          }   
          if ( strcmp ( par4,"NO") != 0 ){        
          for ( int i = in_port + 64 ; i < in_port + number + 64  ; i++ ) {
                if ( (prev_bit [ i ] ^ ack [ i - (in_port + 64) ].read() ) == SC_LOGIC_1 ) { // FIND Toggle(s)
                        tog [ i ] ++ ;
                        
                }
                if ( ack [ i - (in_port + 64) ] == SC_LOGIC_1 ) no_1s [ i ] ++;                 
                prev_bit [ i ] = ack [ i - (in_port + 64) ].read() ;
          }                   
          }               
}
// ====================================================================================================
template < typename type ,typename data_type , int in_port >

class power_calc_l : public sc_module{

        private :
                int tog [ in_port +  32 ], no_1s [ in_port + 32  ] ;
                
                type prev_bit [ in_port  + 32  ] ;
                char  file_name[50] , par0[50] , par1[50] , par2[50] , par3[50] , par4[50] , par5[50] ;
                fstream fp;
        public:
                sc_in < type > in [ in_port ] ;
                sc_in <data_type > data ;
                
                sc_in < bool > clk ;
                SC_HAS_PROCESS ( power_calc_l ) ;
                
                virtual void log_power ( void ) ;
                
                
                power_calc_l ( sc_module_name nm, char *file_name_tmp , const char *t_par0, const char *t_par1 , const  char *t_par2,
                              const char *t_par3 , const char *t_par4,const char *t_par5  ) : sc_module ( nm ) {
                        
                        strcpy ( par0 , t_par0 ) ;
                        strcpy ( par1 , t_par1 ) ;
                        strcpy ( par2 , t_par2 ) ;
                        strcpy ( par3 , t_par3 ) ;
                        strcpy ( par4 , t_par4 ) ;
			strcpy ( par5 , t_par5 ) ;

                        strcpy ( file_name , file_name_tmp ) ;
                        for ( int i = 0 ; i < in_port + 32  ; i++){
                                  tog [ i ] = 0 ;
                                  no_1s [ i ] = 0 ;
                                  prev_bit [ i ] = false;
                        }                                  
                        SC_METHOD(log_power);
                                sensitive << clk.pos() ; //in [ in_port - 1 ].pos() ;
                        
                }
                ~power_calc_l() {
                       //cout << " I am here ! "<<endl; 
                        if ( strcmp ( par0,"NO") != 0 )
                            fp.open ( file_name , ios::out ); // if u remove the ios::out , it will not work.
                        else
                            fp.open ( file_name , ios::app | ios::out );
                      if ( fp.good() ){
                      
                      if ( strcmp ( par0,"NO") != 0 ){
                       fp << HEADER << endl;
                       fp << endl << POWER_STR0 << par0 <<"]    " << POWER_STR1<<(float)no_1s[ 0 ]/NO_SIMU_CLK <<POWER_STR2<<tog[0] <<POWER_STR3<<NO_SIMU_CLK*5<<endl;  
                      }                      
                      if ( strcmp ( par1,"NO") != 0 )
                      fp << endl << POWER_STR0 << par1 <<"]    " << POWER_STR1<<(float)no_1s[ 1 ]/NO_SIMU_CLK <<POWER_STR2<<tog[1] <<POWER_STR3<<NO_SIMU_CLK*5<<endl;  
                      if ( strcmp ( par2,"NO") != 0 )
                      fp << endl << POWER_STR0 << par2 <<"]    " << POWER_STR1<<(float)no_1s[ 2 ]/NO_SIMU_CLK <<POWER_STR2<<tog[2] <<POWER_STR3<<NO_SIMU_CLK*5<<endl;  
                      if ( strcmp ( par3,"NO") != 0 )
                      fp << endl << POWER_STR0 << par3 <<"]    " << POWER_STR1<<(float)no_1s[ 3 ]/NO_SIMU_CLK <<POWER_STR2<<tog[3] <<POWER_STR3<<NO_SIMU_CLK*5<<endl;  
		 
		      if ( strcmp ( par4,"NO") != 0 )
                      fp << endl << POWER_STR0 << par4 <<"]    " << POWER_STR1<<(float)no_1s[ 4 ]/NO_SIMU_CLK <<POWER_STR2<<tog[4] <<POWER_STR3<<NO_SIMU_CLK*5<<endl;  
                      for ( int ii = 5 ; ii < in_port + 32; ii++ ){
                        fp << endl << POWER_STR0 << par5 <<"["<< (ii - 5) <<"] ]   " << POWER_STR1<<(float)no_1s[ ii ]/NO_SIMU_CLK <<POWER_STR2<<tog[ii] <<POWER_STR3<<NO_SIMU_CLK*5<<endl;  
			//cout <<  par5 << endl;
                     }
                      }
                      else{
                        cout << "POWER_CALC_Leaf:: error \n";
                      } 
                      fp.close();
                }
        
};
template < typename type ,typename data_type , int in_port >
void power_calc_l < type , data_type,  in_port > :: log_power ( void ) {   
           
          for ( int i = 0 ; i < in_port  ; i++ ) {
                if ( (prev_bit [ i ] ^ in [ i ].read() ) == SC_LOGIC_1 ) { // FIND Toggle(s)
                        tog [ i ] ++ ;
                        
                }
                if ( in [ i ] == SC_LOGIC_1 ) no_1s [ i ] ++;                 
                prev_bit [ i ] = in [ i ].read() ;
          }
          for ( int i = in_port ; i < in_port + 32  ; i++ ) {
                if ( (prev_bit [ i ] ^ ( type )(data.read().range(i - in_port , i - in_port)) ) == SC_LOGIC_1 ) { // FIND Toggle(s)
                        tog [ i ] ++ ;
                        
                }
                if ( (type)(data.read().range(i - in_port,i - in_port)) == SC_LOGIC_1 ) no_1s [ i ] ++;                 
                prev_bit [ i ] = (type)(data.read().range(i - in_port ,i - in_port)) ;  
          }   
           
                         
}
#endif
