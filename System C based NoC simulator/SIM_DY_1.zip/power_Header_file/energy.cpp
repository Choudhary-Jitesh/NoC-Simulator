#include <iostream>
#include <fstream>
using namespace std;
int main () {
	char c[17];
	fstream fp ("dt.txt" ,  ios::in );
	float s_total = 0;
	int s_prev[16], V=1, j=0;
	float wire_length = 1;
	float MAKE_mm = 0.001;
	for ( int i = 0 ; i < 16 ; i ++ ) s_prev [ i ] = 0;
	do{
	fp >> c;
		s_total = s_total +   ( ( 64.2 + (7.4) ) * ( (c[0] -48)  - s_prev [ 0 ] ) - 
                                                                    (7.4) * ( (c[1] -48)- s_prev [ 1 ])
                                                                     ) * V;
                 //cout << s_total << endl;                                                    
                for ( int i = 0 ; i < 14 ; i++ ){
                	s_total = s_total  +  ( - (7.4)  * ( (c[i]-48)  - s_prev [ i ] ) + 
		                                                         ( 57.5 + 2 * (7.4)) *( (c[i+1] - 48) - s_prev [ i+1 ]) -
		                                                         (7.4)  * ( (c[i+2] - 48 ) - s_prev [ i+2 ] )
		                                                                ) * V; 
                }
                //cout << s_total << endl;
                s_total = s_total  +  (  - (7.4) * ( (c[14] - 48 ) - s_prev [ 14]) +
                                                                  ( 48.626 + (7.4) ) * ( (c[15] - 48 ) - s_prev [ 15] )
                 
                                                                                     ) * V;  
                 //cout << s_total << endl;
                 //j++ ;
                 cout << c << endl;
                 //if( j == 4 ) break ;
                for ( int i = 0 ; i < 16 ; i++ ){
                	s_prev [ i ] = (c[i] - 48 );  
                	//cout << (c[i] - 48 ) ;
               } 	                      
              // cout << s_total;                                               
	
	} while ( !fp.eof());
	cout << s_total*wire_length*MAKE_mm << endl ;
	return 0;
}
