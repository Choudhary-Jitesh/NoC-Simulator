#ifndef macros_MOT
#define macros_MOT

#include "systemc.h"
/*
#define  flit_size                            32
#define  flit_sz                              31*/
typedef sc_uint<64>                           flit ;// for storing flit_size bits of a flit
typedef sc_uint<64>                           mflit ;
/*
typedef  char                                 mddr ;// for storing 3 bits of read/write addresses in memory module 
typedef  sc_uint<12>                          lddr ;// for addresses of core and routers(initial 'l' for location )     
#define  invalid_macro                        0x60000000
#define  tailerf                              0x40000000
#define  headerf                              0x20000000
#define  invalidf                             0x60000000
#define  gt_bef                               0x80000000   
#define  bitf(x)                              (1<<x)
#define  bitv(v,x)                            ((v>>x)&1)
#define  copyv(v,a,b)                         ( (v>>b) & ((1<<(a-b+1))-1) )
#define  copyf_nn(x,y)                        x=y
#define  copyf_nsc(x,y)                       x=y.read()
#define  copyf_scn(x,y)                       x.write(y)
#define  copyf_scsc(x,y)                      x.write(y.read())   
#define  C5_LIMIT                             0b11111 // maximum count in counter_5bit process
typedef  char                                 cfv   ;// for storing 5 bits of counter variable in counter_5bit process 
#define  READ_DISABLE_FLIT                    1610612736
#define  EOP(x)                               ((x&(tailerf))!=0)
#define  BOP(x)                               ((x&(headerf))!=0)
#define  GT_BE(x)                             ((x&(gt_bef))!=0)
#define  type(x)                              (x&(invalidf))
#define  INVALID(x)                           (type(x)==invalidf)
#define  TAILER(x)                            (type(x)==tailerf)
#define  HEADER(x)                            (type(x)==headerf)
#define  BODY(x)                              (type(x)==0)*/
// SEE THE FLOOR PLAN DIAGRAM
#define factor_leaf1                           0.5  // core distance from leaf router.
#define factor_leaf2                           0.5 // core distance from leaf router.
#define factor_leaf3                           1  // stem distance from leaf router.
#define factor_leaf4                           1  // stem distance from leaf router.

#define factor_r_stem1                         2  // stem distance from root router.
#define factor_r_stem2                         1
#define factor_r_stem3                         1

#define factor_c_stem1                         1
#define factor_c_stem2                         1
#define factor_c_stem3                         1

#define factor_r_root1                         2
#define factor_r_root2                         2

#define factor_c_root1                         1
#define factor_c_root2                         1

#define factor_core                            0.5
// Capacitace Line to Ground (CLG), coupling Capacitance (CC) SEE the reliability papaer Page 12.
#define CLG_ref                                19.0916
#define CC_ref                                 69.0313
#endif
 
