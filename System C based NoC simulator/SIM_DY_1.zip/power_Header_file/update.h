#include "encodez.h"
 
#define update_d(x)                            \
                                               \
 if(x.read()!=prev_##x)                        \
    sp_##x=sp_##x+1;                           \
 if(prev_##x==1)                               \
   pb1_##x=pb1_##x+1;                          \
   
   

#ifndef encoden
//64                                                                          
#define update_out(out)                                \
                                                       \
                                                       \
present_##out=out.read();                              \
c=present_##out[0]-prev_##out[0];                      \
if(c!=0)                                               \
   {                                                   \
   sp_##out[0]=sp_##out[0]+1;                          \
   if(present_##out[0]==1)                             \
      Lg_##out=Lg_##out+fLg[0];                        \
   }                                                   \
if(prev_##out[0]==1)                                   \
     pb1_##out[0]=pb1_##out[0]+1;                      \
                                                       \
                                                       \
for(i=1;i<64;i++)                                      \
 {                                                     \
 d=present_##out[i]-prev_##out[i];                     \
 if(d!=0)                                              \
   {                                                   \
    sp_##out[i]=sp_##out[i]+1;                         \
    if(present_##out[i]==1)                            \
      Lg_##out=Lg_##out+fLg[i];                        \
   }                                                   \
 if(prev_##out[i]==1)                                  \
    pb1_##out[i]=pb1_##out[i]+1;                       \
 if(present_##out[i]!=present_##out[i-1])              \
   {                                                   \
    if(present_##out[i]==1)                            \
      Cc_##out=Cc_##out+d-c;                           \
    else                                               \
      Cc_##out=Cc_##out+c-d;                           \
   }                                                   \
   c=d;                                                \
 }                                                     \


#endif

#ifndef encodey  
//8_8_8_8

#define update_out(out)                                \
                                                       \
                                                       \
present_##out=out.read();                              \
c=present_##out[0]-prev_##out[0];                      \
if(c!=0)                                               \
   {                                                   \
   sp_##out[0]=sp_##out[0]+1;                          \
   if(present_##out[0]==1)                             \
      Lg_##out=Lg_##out+fLg[0];                        \
   }                                                   \
if(prev_##out[0]==1)                                   \
     pb1_##out[0]=pb1_##out[0]+1;                      \
                                                       \
t=1;                                                   \
j=1;                                                   \
for(i=1;i<64;i++)                                      \
 {                                                     \
 d=present_##out[i]-prev_##out[i];                     \
 if(d!=0)                                              \
   {                                                   \
    sp_##out[i]=sp_##out[i]+1;                         \
    if(present_##out[i]==1)                            \
      Lg_##out=Lg_##out+fLg[i];                        \
   }                                                   \
 if(prev_##out[i]==1)                                  \
    pb1_##out[i]=pb1_##out[i]+1;                       \
 if(present_##out[i]!=present_##out[i-t])              \
   {                                                   \
    if(present_##out[i]==1)                            \
      Cc_##out=Cc_##out+d-c;                           \
    else                                               \
      Cc_##out=Cc_##out+c-d;                           \
   }                                                   \
   c=d;                                                \
   j++;                                                \
   if(j==8)                                            \
    {                                                  \
      i=i+8;                                           \
      t=9;                                             \
      j=0;                                             \
    }                                                  \
   else                                                \
    t=1;                                               \
 }                                                     \

#endif

     
 
 
#define le_xy(x,y,out)                                     \
                                                           \
  d=x.read()-prev_##x;                                     \
  if(d>0)                                                  \
   Lg_##out=Lg_##out+fLg_x;                                \
  if(x.read()!=(bool)present_##out[terminate])             \
    {                                                      \
      if(x.read()==1)                                      \
        Cc_##out=Cc_##out+d-c;                             \
      else                                                 \
        Cc_##out=Cc_##out+c-d;                             \
    }                                                      \
  c=d;                                                     \
  d=y.read()-prev_##y;                                     \
  if(d>0)                                                  \
    Lg_##out=Lg_##out+fLg_y;                               \
  if(y.read()!=x.read())                                   \
    {                                                      \
      if(y.read()==1)                                      \
        Cc_##out=Cc_##out+d-c;                             \
      else                                                 \
        Cc_##out=Cc_##out+c-d;                             \
    }                                                      \


#define general_update(val, req, out)                  \
                                                       \
 update_out(out)                                       \
 terminate=63;                                         \
 le_xy(val,req,out)                                    \
 prev_##out=present_##out;                             \
                                                       \
 update_d(val)                                         \
 prev_##val= val.read();                               \
                                                       \
 update_d(req)                                         \
 prev_##req= req.read();                               \
                                                       \

#define update_outz(out)                               \
                                                       \
                                                       \
present_##out=out.read();                              \
c=present_##out[0]-prev_##out[0];                      \
if(c!=0)                                               \
   {                                                   \
   sp_##out[0]=sp_##out[0]+1;                          \
   if(present_##out[0]==1)                             \
      Lg_##out=Lg_##out+fLgz[0];                       \
   }                                                   \
if(prev_##out[0]==1)                                   \
     pb1_##out[0]=pb1_##out[0]+1;                      \
                                                       \
                                                       \
for(i=1;i<32;i++)                                      \
 {                                                     \
 d=present_##out[i]-prev_##out[i];                     \
 if(d!=0)                                              \
   {                                                   \
    sp_##out[i]=sp_##out[i]+1;                         \
    if(present_##out[i]==1)                            \
      Lg_##out=Lg_##out+fLgz[i];                       \
   }                                                   \
 if(prev_##out[i]==1)                                  \
    pb1_##out[i]=pb1_##out[i]+1;                       \
 if(present_##out[i]!=present_##out[i-1])              \
   {                                                   \
    if(present_##out[i]==1)                            \
      Cc_##out=Cc_##out+d-c;                           \
    else                                               \
      Cc_##out=Cc_##out+c-d;                           \
   }                                                   \
   c=d;                                                \
 }                                                     \

 
#define general_updatez(val, req, out)                 \
                                                       \
 update_outz(out)                                      \
 terminate=31;                                         \
 le_xy(val,req,out)                                    \
 prev_##out=present_##out;                             \
                                                       \
 update_d(val)                                         \
 prev_##val= val.read();                               \
                                                       \
 update_d(req)                                         \
 prev_##req= req.read();                               \
                                                       \


#define update_leaf(link)   general_update(out_val##link ,data_in_req##link, router_out##link)

#define update_leafz(link)  general_updatez(out_val##link,data_in_req##link, router_out##link)

#define update_stem(link)   general_update(out_val##link , data_in_req##link, router_out##link)

#define update_root(link)   general_update(out_val##link , data_in_req##link , data_out##link)

#define update_NI(link)     general_updatez(data_valid##link, data_in_req_NI##link ,packet_out##link)      

 
 
 
