#include <stdio.h>

int main ( void ){
        
        FILE *fp;
        
        fp = fopen ("ttt.txt" , "r" ) ;
        float T = 0, t , t1 , T1 = 0 ;
        char c[50];
        do {
                fscanf ( fp , "%f" , &t );
                printf ( " %f\n" , t );
                //T = T + t ;
                //T1 = T1 + t1;
        } while ( !feof( fp ) ) ;
        fclose ( fp );
        
        //fp = fopen ("power_result/Energy.txt" , "a" );
        
        //fprintf ( fp , "TOTAL ENGY : %f \n " , T);
        //printf (  "TOTAL ENGY : %f \n " , T);
        //fprintf ( stdout , "TOTAL ENGY : %f \n " , T1);
        fclose ( fp );
        return 0;
}
