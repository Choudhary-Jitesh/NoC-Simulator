#include "systemc.h"
int sc_main(int argc, char *argv[]){
        sc_uint<3> a;
        bool b;
        b=0;
        char c[6];//="0b101";
        c[0]='0'; c[1]='b'; c[2]='1';c[3]='0'+b;c[4]='1';c[5]='\0';
        //a="0b011";//(0,1,1);
        //a=(0,1,1);
        a="0b011";
        cout << a <<endl;
}
