/*
 PURPOSE : THIS FILE CONTAINS TWO MODULE WHICH WILL CALCULATE LINK POWER.
 LAST UPDATE DATE: 20 MARCH 2010.
*/
#include "systemc.h"
#include "enter.h"
#include "../config/define.cpp"
#ifndef _ENERGY_H
#define _ENERGY_H

template < typename type , typename type_data , typename type_ack ,int in_port ,int number >

class energy_calc_64 : public sc_module{

        private :
                
                float energy [(in_port + number + 64) ] ,s_energy [(in_port + number + 64) ], wire_length;
                
                int prev [ (in_port + number + 64) ] , s_prev [ (in_port + number + 64) ] ;;
                char  file_name[50] , par0[50]  ;
                fstream fp, fpl;
                float total;
                float s_total;
        public:
        	
                sc_in < type > in [ in_port ] ;
                sc_in < type_data > data ;
                sc_in < type_ack > ack[ number ];
                sc_in < bool > clk ;
                
                SC_HAS_PROCESS ( energy_calc_64 ) ;                
                energy_calc_64 (sc_module_name nm,const  char *router_name, const char *channel, const char *file_name_tmp , const char *t_par0 , float t_w_len);
                ~energy_calc_64();
                virtual void log_energy ( void ) ;
                
                
        
};
 

template < typename type , typename type_data  ,int in_port  >

class energy_calc_32 : public sc_module{

        private :
                
                float energy [(in_port + 32) ] , s_energy [(in_port + 32) ] ,wire_length;
                
                int prev [ (in_port  + 32) ],s_prev [ (in_port  + 32) ] ;
                char  file_name[50] , par0[50]  ;
                fstream fp;
                float total,s_total;
        public:
        	
                sc_in < type > in [ in_port ] ;
                sc_in < type_data > data ;
                //sc_in < type_ack > ack[ number ];
                sc_in < bool > clk ;
                
                SC_HAS_PROCESS ( energy_calc_32 ) ;
                
                energy_calc_32 ( sc_module_name nm, const char *file_name_tmp ,const  char *t_par0 , float t_w_len);
                ~energy_calc_32();
                virtual void log_energy ( void ) ;
                
                        
};
 










///===============================================================================================================
template < typename type , typename type_data , typename type_ack ,int in_port ,int number >
 energy_calc_64 < type , type_data , type_ack, in_port ,number > :: energy_calc_64 (sc_module_name nm, const char *router_name, const char *channel, const char *file_name_tmp , const char *t_par0 , float t_w_len) : sc_module ( nm ) {
                        
                        //cout << router_name << channel << endl;
                        strcpy ( par0 , t_par0 ) ;
                        wire_length = t_w_len ;
                        //total = s_total = 0 ;
                        strcpy ( file_name , file_name_tmp ) ;
                        if ( strcmp ( router_name , "power_result/stem_row0_01.scr") == 0 && strcmp ( channel , "in_com_ch1") == 0 ){
                            fpl.open ("power_result/in_com_ch1.txt" , ios::app | ios::out );
                            cout << router_name << channel << endl;
                        }    
                       
                        strcpy ( file_name , file_name_tmp ) ;
                        for ( int i = 0 ; i < (in_port + number + 64) ; i++){                                  
                                  energy [ i ] = s_energy [ i ] = 0 ;
                                    prev [ i ] = s_prev [ i ] = 0;
                        }                                  
                       
                        SC_METHOD(log_energy);
                                sensitive << clk.pos() ; //in [ in_port - 1 ].pos() ;
}

template < typename type , typename type_data , typename type_ack ,int in_port ,int number >
 energy_calc_64 < type , type_data , type_ack, in_port ,number > :: ~energy_calc() {                  
                
                      
                      fp.open ( file_name , ios::app | ios::out ); // if u remove the ios::out , it will not work.
                      if ( fp.good() ){
                                fp  << total*wire_length * MAKE_mm * V  << "\t"<<s_total*wire_length * MAKE_mm * V<<endl;
                      }
                      else{
                        cout << "ENERGY_CALC:: error \n";
                      } 
                      fp.close();
}

template < typename type , typename type_data , typename type_ack ,int in_port ,int number >
void energy_calc_64 < type , type_data , type_ack, in_port ,number > :: log_energy ( void ) {  
        
        
        int t_data[64];
        for ( int i = 0 ; i < 64 ; i ++ ){
             t_data[ i ] =(int) data.read().range(i,i); 
             //cout <<t_data[ i ] ;
             } 
             //cout << endl;
        //============  ENERGY  ====
                
       // cout << data.read() << endl;        
        total = total +   ( ( clg_ref_ns_64lines[0] +(cc_ref_ns_64lines ) ) * ( (int)in [ 0 ]  - prev [ 0 ] ) - 
                                                                    (cc_ref_ns_64lines ) * ( (int)in [ 1 ] - prev [ 1 ])
                                                                  ) * (int)in [ 0 ];
                                                                 
        total = total +  ( - (cc_ref_ns_64lines  )  * ( (int)in [ 0 ]  - prev [ 0 ] ) + 
                                                                    ( clg_ref_ns_64lines[1] + 2 * (cc_ref_ns_64lines)) * ( (int)in [ 1 ] - prev [ 1 ]) -
                                                                      (cc_ref_ns_64lines)  * ( (int)in [ 2 ]  - prev [ 2 ] )
                                                                ) * (int)in [ 1 ]; 
                                                                 
        total = total +  ( - (cc_ref_ns_64lines  )  * ( (int)in [ 1 ]  - prev [ 1 ] ) + 
                                                                    ( clg_ref_ns_64lines[2] + 2 * (cc_ref_ns_64lines  )) * ( (int)in [ 2 ] - prev [ 2 ]) -
                                                                      (cc_ref_ns_64lines  )  * ( t_data[0]  - prev [ 3 ] )
                                                                ) * (int)in [ 2 ]; 
          
        
        total = total  + ( - (cc_ref_ns_64lines  )  * ( (int)in [ 2 ]  - prev [ 2 ] ) + 
                                                                    ( clg_ref_ns_64lines[3] + 2 * (cc_ref_ns_64lines  )) * ( t_data[0] - prev [ 3 ]) -
                                                                      (cc_ref_ns_64lines  )  * ( t_data[1]  - prev [ 4 ] )
                                                                ) * (int)t_data[0]; 
         
                                                                                                                                       
        for ( int i = 4 ; i < in_port + 63  ; i++ ) {                                                                                                                                     
                   total = total + ( - (cc_ref_ns_64lines  )  * ( t_data[i -4]  - prev [ i - 1 ] ) + 
                                                                    ( clg_ref_ns_64lines[i] + 2 * (cc_ref_ns_64lines  )) * ( t_data[i-4+1] - prev [ i ]) -
                                                                      (cc_ref_ns_64lines  )  * ( t_data[i-4+2]  - prev [ i + 1 ] )
                                                                           ) * t_data[i-4+1]; 
                                                                                                            
        } 
        
        total = total  +  ( - (cc_ref_ns_64lines  )  * ( t_data[62]   - prev [ 65 ] ) + 
                                                                    ( clg_ref_ns_64lines[66] + 2 * (cc_ref_ns_64lines  )) * ( t_data[63]  - prev [ 66]) -
                                                                      (cc_ref_ns_64lines)  * ( (int)ack [ 0]  - prev [ 67 ] )
                                                                  ) * (int)t_data[63];               
         
        total = total +  ( - (cc_ref_ns_64lines  )  * ( t_data[63]   - prev [ 66 ] ) + 
                                                                    ( clg_ref_ns_64lines[67] + 2 * (cc_ref_ns_64lines  )) * ( (int)ack [ 0 ] - prev [ 67]) -
                                                                      (cc_ref_ns_64lines  )  * ( (int)ack [ 1]  - prev [ 68 ] )
                                                                  ) * (int)ack [ 0 ]; 
                                                                  
         total = total  + ( - (cc_ref_ns_64lines  )  * ( (int)ack [ 0 ]  - prev [ 67 ] ) + 
                                                                    ( clg_ref_ns_64lines[68] + 2 * (cc_ref_ns_64lines)) * ( (int)ack [ 1 ] - prev [ 68 ]) -
                                                                      (cc_ref_ns_64lines  )  * ( (int)ack [ 2 ]  - prev [ 69] )
                                                                                     ) * (int)ack [ 1 ]; 
                                                                                   
         total = total  +  (  - (cc_ref_ns_64lines  ) * ( (int)ack [ 1 ] - prev [ 68 ]) +
                                ( clg_ref_ns_64lines[69] + (cc_ref_ns_64lines  ) ) * ( (int)ack [ 2 ]  - prev [ 69 ] )
                                                                                     ) * (int)ack [ 2 ];    
         
                                                                                      
         for ( int i = 0 ; i < in_port  ; i++ )                 
                        prev [ i ] =(int) in [ i ].read() ; 
         for ( int i = in_port ; i < in_port + 64  ; i++ )                 
                        prev [ i ] = (int)data.read().range(i - in_port , i - in_port ) ; 
         for ( int i = in_port + 64 ; i < in_port + 64 + number ; i++ )                 
                        prev [ i ] = (int)ack [ i - in_port - 64 ].read() ; 
          //------------------------------------               
         // ENERGY CALCULATION USING SERIALIZER.
         //-------------------------------------
         //cout << "S " <<data.read() << endl; 
         
         for ( int i = 0 ; i < 4 ; i ++ ) {
         	
         	        s_total = s_total +   ( ( clg_ref_ws[0] + (cc_ref_ws) ) * ( t_data[16*i]  - s_prev [ 0 ] ) - 
                                                                    (cc_ref_ws) * ( t_data[16*i+1] - s_prev [ 1 ])
                                                                  ) * t_data[16*i];
        		                                                            
		        for ( int k = 0 ; k < 14 ; k ++ )
         			  s_total = s_total  +  ( - (cc_ref_ws)  * ( t_data[16*i+k]  - s_prev [ k ] ) + 
                                                                    ( clg_ref_ws[k+1] + 2 * (cc_ref_ws)) * ( t_data[16*i+k+1]  - s_prev [ k+1 ]) -
                                                                      (cc_ref_ws) * ( t_data[16*i+k+2]  - s_prev [ k+2 ] )
                                                                           ) * t_data[16*i+k+1];                                                       
         		s_total = s_total  + (  - (cc_ref_ws) * ( t_data[16*i+14] - s_prev [ 14]) +
                                                  ( clg_ref_ws[15] + (cc_ref_ws) ) * (t_data[16*i+15] - s_prev [ 15] )
                                                                                     ) * t_data[16*i+15];    
         		
         		
         		for ( int j = 16*i ; j < 16*i+16 ; j ++)
         			s_prev [ j-16*i ] = t_data[j];
         	
         }                        
         
        
                                                                                                                   
}
// ===========================================================================================


template < typename type , typename type_data  ,int in_port  >
 energy_calc_32 < type , type_data ,  in_port  > ::energy_calc_32 ( sc_module_name nm, const char *file_name_tmp ,const  char *t_par0 , float t_w_len) : sc_module ( nm ) {
                        
                        strcpy ( par0 , t_par0 ) ;
                        wire_length = t_w_len ;
                        //total = s_total = 0 ;
                        strcpy ( file_name , file_name_tmp ) ;
                        for ( int i = 0 ; i < (in_port  + 32) ; i++){
                                  
                                  energy [ i ] = s_energy [ i ] = 0 ;
                                  prev [ i ] = s_prev [ i ] = 0;
                        }                                  
                       
                        SC_METHOD(log_energy);
                                sensitive << clk.pos() ; //in [ in_port - 1 ].pos() ;
                }
template < typename type , typename type_data  ,int in_port  >
energy_calc_32 < type , type_data ,  in_port  > :: ~energy_calc_32() {
                      
                      fp.open ( file_name , ios::app | ios::out ); // if u remove the ios::out , it will not work.
                      if ( fp.good() ){
                                fp  << total*wire_length * MAKE_mm *V<<"\t" << total*wire_length * MAKE_mm *V<<endl;
                      }
                      else{
                        cout << "ENERGY_CALC:: error \n";
                      } 
                      fp.close();
                }

template < typename type , typename type_data  ,int in_port  >
void energy_calc_32 < type , type_data ,  in_port  > :: log_energy ( void ) {  
        
        int t_data[32];
        for ( int i = 0 ; i < 32 ; i ++ )
             t_data[ i ] =(int) data.read().range(i,i); 
          
        //============  ENERGY  ====
                
                
        total = total +    ( ( clg_ref_ns_32lines[0] + cc_ref_ns_32lines ) * ( (int)in [ 0 ]  - prev [ 0 ] ) - 
                                                                    (cc_ref_ns_32lines) * ( (int)in [ 1 ] - prev [ 1 ])
                                                                  ) * (int)in [ 0 ];
                                                                   
        total = total +   ( - (cc_ref_ns_32lines)  * ( (int)in [ 0 ]  - prev [ 0 ] ) + 
                                                                    ( clg_ref_ns_32lines[1] + 2 * (cc_ref_ns_32lines)) * ( (int)in [ 1 ] - prev [ 1 ]) -
                                                                      (cc_ref_ns_32lines)  * ( (int)in [ 2 ]  - prev [ 2 ] )
                                                                ) * (int)in [ 1 ]; 
        total = total +   ( - (cc_ref_ns_32lines)  * ( (int)in [ 1 ]  - prev [ 1 ] ) + 
                                                                    ( clg_ref_ns_32lines[1] + 2 * (cc_ref_ns_32lines)) * ( (int)in [ 2 ] - prev [ 2 ]) -
                                                                      (cc_ref_ns_32lines)  * ( (int)in [ 3 ]  - prev [ 3 ] )
                                                                ) * (int)in [ 2 ];  

        total = total +   ( - (cc_ref_ns_32lines)  * ( (int)in [ 2 ]  - prev [ 2 ] ) + 
                                                                    ( clg_ref_ns_32lines[1] + 2 * (cc_ref_ns_32lines)) * ( (int)in [ 3 ] - prev [ 3 ]) -
                                                                      (cc_ref_ns_32lines)  * ( (int)in [ 4 ]  - prev [ 4 ] )
                                                                ) * (int)in [ 3 ];  
                                              
        total = total +  ( - (cc_ref_ns_32lines)  * ( (int)in [ 3 ]  - prev [ 3 ] ) + 
                                                                    ( clg_ref_ns_32lines[2] + 2 * (cc_ref_ns_32lines)) * ( (int)in [ 4 ] - prev [ 4 ]) -
                                                                      (cc_ref_ns_32lines)  * ( t_data[0]  - prev [ 5 ] )
                                                                ) * (int)in [ 2 ]; 
        
        
        total = total +  ( - (cc_ref_ns_32lines)  * ( (int)in [ 4 ]  - prev [ 4 ] ) + 
                                                                    ( clg_ref_ns_32lines[3] + 2 * (cc_ref_ns_32lines)) * ( t_data[0] - prev [ 5 ]) -
                                                                      (cc_ref_ns_32lines)  * ( t_data[1] - prev [ 6 ] )
                                                                ) * t_data[0]; 
      
                                                                                                                                       
        for ( int i = 6 ; i < in_port + 28  ; i++ ) {                                                                                                                                     
                   total = total  +  ( - (cc_ref_ns_32lines) * ( t_data[i - 6]  - prev [ i - 1 ] ) + 
                                                                    ( clg_ref_ns_32lines[i] + 2 * (cc_ref_ns_32lines)) * ( t_data[ i - 6 + 1] - prev [ i ]) -
                                                                      (cc_ref_ns_32lines)  * ( t_data[ i - 6 + 2]  - prev [ i + 1 ] )
                                                                           ) * t_data[ i - 6 + 1]; 
                                                                                                           
        } 
        
        total = total +  ( - (cc_ref_ns_32lines)  * ( t_data[ 27 ]  - prev [ 32 ] ) + 
                                                                    ( clg_ref_ns_32lines[33] + 2 * (cc_ref_ns_32lines)) * ( t_data[ 28] - prev [ 33]) -
                                                                      (cc_ref_ns_32lines)  * (t_data[29]  - prev [ 34 ] )
                                                                  ) * t_data[ 28];               
         
        total = total  +  ( - (cc_ref_ns_32lines)  * ( t_data[28]  - prev [ 33 ] ) + 
                                                                    ( clg_ref_ns_32lines[34] + 2 * (cc_ref_ns_32lines)) * ( t_data[29] - prev [ 34 ]) -
                                                                      (cc_ref_ns_32lines)  * ( t_data[30]  - prev [ 35 ] )
                                                                  ) * t_data[29]; 
                                                              
        total = total +  ( - (cc_ref_ns_32lines)  * ( t_data[29]  - prev [ 34 ] ) + 
                                                                    (clg_ref_ns_32lines[35] + 2 * (cc_ref_ns_32lines)) * (t_data[30] - prev [ 35 ]) -
                                                                      (cc_ref_ns_32lines)  * ( t_data[31]  - prev [ 36] )
                                                                                     ) * t_data[30]; 
                                                                                 
        total = total + (  - (cc_ref_ns_32lines) * (t_data[30] - prev [ 35 ]) +
                                       (clg_ref_ns_32lines[36]  + (cc_ref_ns_32lines) ) * ( t_data[31]  - prev [ 36 ] )
                                                                                     ) * t_data[31] ;    
         
                                                                                      
         for ( int i = 0 ; i < in_port  ; i++ )                 
                        prev [ i ] =(int) in [ i ].read() ; 
         for ( int i = in_port ; i < in_port + 32  ; i++ )                 
                        prev [ i ] =(int)  data.read().range(i - in_port , i - in_port ) ; 
         
         //-------------------------------------               
         // ENERGY CALCULATION USING SERIALIZER.
         //-------------------------------------
        /* for ( int i = 0 ; i < 2 ; i ++ ) {
         	
         	        s_total = s_total +   ( ( 64.2  +(cc_ref_ws) ) * (t_data[16*i]  - s_prev [ 0 ] ) - 
                                                                    (cc_ref_ws) * (t_data[16*i+1] - s_prev [ 1 ])
                                                                  ) * t_data[16*i];
        		                                                          
		      for ( int k = 0 ; k < 14 ; k ++ )
         			  s_total = s_total  +  ( - (cc_ref_ws)  * ( t_data[16*i+k]  - s_prev [ k ] ) + 
                                                                    ( 57.5 + 2 * (cc_ref_ws)) * ( t_data[16*i+k+1]  - s_prev [ k+1 ]) -
                                                                      (cc_ref_ws) * ( t_data[16*i+k+2]  - s_prev [ k+2 ] )
                                                                           ) * t_data[16*i+k+1];                                                       
         		s_total = s_total  + (  - (cc_ref_ws) * ( t_data[16*i+14] - s_prev [ 14]) +
                                                  ( 48.626 + (cc_ref_ws) ) * (t_data[16*i+15] - s_prev [ 15] )
                                                                                     ) * t_data[16*i+15];    
         		
         		
         		for ( int j = 16*i ; j < 16*i+16 ; j ++)
         			s_prev [ j-16*i ] = t_data[j];
        }*/
                                                                                                                   
}
#endif
