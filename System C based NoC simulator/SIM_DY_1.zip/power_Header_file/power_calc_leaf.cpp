#include "systemc.h"
//#include "enter.h"
#include "../config/define.cpp"
// THIS MODULE WOULD FIND THE # of 1s and count the toggle(s).
#ifndef _POWER_H_LEAF
#define _POWER_H_LEAF

// ====================================================================================================
template < typename type ,typename data_type , int in_port >

class power_calc_l : public sc_module{

        private :
                int tog [ in_port +  32 ], no_1s [ in_port + 32  ] ;
                
                type prev_bit [ in_port  + 32  ] ;
                char  file_name[50] , par0[50] , par1[50] , par2[50] , par3[50] ;
                fstream fp;
        public:
                sc_in < type > in [ in_port ] ;
                sc_in <data_type > data ;
                
                sc_in < bool > clk ;
                SC_HAS_PROCESS ( power_calc_l ) ;
                
                virtual void log_power ( void ) ;
                
                
                power_calc_l ( sc_module_name nm, char *file_name_tmp , char *t_par0, char *t_par1 ,  char *t_par2,
                              char *t_par3  ) : sc_module ( nm ) {
                        
                        strcpy ( par0 , t_par0 ) ;
                        strcpy ( par1 , t_par1 ) ;
                        strcpy ( par2 , t_par2 ) ;
                        strcpy ( par3 , t_par3 ) ;
                        
                        strcpy ( file_name , file_name_tmp ) ;
                        for ( int i = 0 ; i < in_port + 32  ; i++){
                                  tog [ i ] = 0 ;
                                  no_1s [ i ] = 0 ;
                                  prev_bit [ i ] = false;
                        }                                  
                        SC_METHOD(log_power);
                                sensitive << clk.pos() ; //in [ in_port - 1 ].pos() ;
                        
                }
                ~power_calc_l() {
                     //  cout << " I am here ! "<<endl; 
                      fp.open ( file_name , ios::app | ios::out ); // if u remove the ios::out , it will not work.
                      if ( fp.good() ){
                      if ( strcmp ( par0,"NO") != 0 )
                      fp << endl << POWER_STR0 << par0 <<"]    " << POWER_STR1<<(float)no_1s[ 0 ]/NO_SIMU_CLK <<POWER_STR2<<tog[0] <<POWER_STR3<<NO_SIMU_CLK<<endl;  
                      if ( strcmp ( par1,"NO") != 0 )
                      fp << endl << POWER_STR0 << par1 <<"]    " << POWER_STR1<<(float)no_1s[ 1 ]/NO_SIMU_CLK <<POWER_STR2<<tog[1] <<POWER_STR3<<NO_SIMU_CLK<<endl;  
                      if ( strcmp ( par2,"NO") != 0 )
                      fp << endl << POWER_STR0 << par2 <<"]    " << POWER_STR1<<(float)no_1s[ 2 ]/NO_SIMU_CLK <<POWER_STR2<<tog[2] <<POWER_STR3<<NO_SIMU_CLK<<endl;  
                      for ( int ii = 3 ; ii < in_port + 32; ii++ )
                        fp << endl << POWER_STR0 << par3 <<"["<< (ii - 3) <<"] ]   " << POWER_STR1<<(float)no_1s[ ii ]/NO_SIMU_CLK <<POWER_STR2<<tog[ii] <<POWER_STR3<<NO_SIMU_CLK<<endl;  
                     
                      }
                      else{
                        cout << "POWER_CALC_Leaf:: error \n";
                      } 
                      fp.close();
                }
        
};
template < typename type ,typename data_type , int in_port >
void power_calc_l < type , data_type,  in_port > :: log_power ( void ) {   
           
          for ( int i = 0 ; i < in_port  ; i++ ) {
                if ( (prev_bit [ i ] ^ in [ i ].read() ) == SC_LOGIC_1 ) { // FIND Toggle(s)
                        tog [ i ] ++ ;
                        
                }
                if ( in [ i ] == SC_LOGIC_1 ) no_1s [ i ] ++;                 
                prev_bit [ i ] = in [ i ].read() ;
          }
          for ( int i = in_port ; i < in_port + 32  ; i++ ) {
                if ( (prev_bit [ i ] ^ ( type )(data.read().range(i - in_port , i - in_port)) ) == SC_LOGIC_1 ) { // FIND Toggle(s)
                        tog [ i ] ++ ;
                        
                }
                if ( (type)(data.read().range(i - in_port,i - in_port)) == SC_LOGIC_1 ) no_1s [ i ] ++;                 
                prev_bit [ i ] = (type)(data.read().range(i - in_port ,i - in_port)) ;  
          }   
           
                         
}
#endif
