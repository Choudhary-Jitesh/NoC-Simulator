#include "macrosMOT.h"
#include "update.h"

#define initialx(a)

#define STRING0   "\
\
report activity $m -file reports/activity.txt \n\n \
report activity $m -file reports/not_annotated.txt -nets not_annotated \n\n \
\n\
force timing clock $m/clk0 4.3n \n\n \
force activity annotate $m/mpin:clr -probability 0.000002 -toggles 1 -interval 0.001 \n\n" 

#define STRING1   "force activity annotate $m/mpin:"

#define STRING2   "    -probability %f -toggles %7d -interval 0.001\n"


#define STRINGL    "\
\n\nforce activity -propagate $m -verbose \n\
\n \
report activity $m -file reports/not_annotated_aftrpropgate_clk_0.5.txt -nets not_annotated \n \
\n \
report activity $m -file reports/activity_aftr_propgt_clk_0.5.txt \n \
\n \
report power analysis $m -file reports/power_detail_clk_0.5.txt -detail \n \
report power analysis $m -file reports/power_summary_clk_0.5.txt -summary \n \
report power analysis $m -file reports/power_leakage_clk_0.5.txt -leakage \n \
report power analysis $m -file reports/power_cells_clk_0.5.txt -cells -detail \n" 




// Ken: For Link Energy

#define LE(factor,link) \
\
nl=factor*LE_SP_PB1.Lg_##link;  \
wl=factor*LE_SP_PB1.Cc_##link;  \
tl=CLG_ref*nl+CC_ref*wl; \
TNL=TNL+nl;              \
TWL=TWL+wl;              \
fprintf(fp_le_sp_pb1, "\n"#link":\n   nl(factor*Lg_) = %15.5f   wl(factor*Cc_) = %15.5f   tl(CLG_ref*nl+ CC_ref*wl) = %15.5f \n",nl,wl,tl);

  
// Ken : For Router Power

#define initial(a,fpl)                 \
\
gp=fopen("power_result/powercalc_clkg_"#fpl".scr","w");\
initialx(a) \
fprintf(gp,STRING0);


#ifndef encoden

#define general( val, req, out, valid , data_req, w_out, link)  \
\
\
fprintf(gp, "\n\n" STRING1 #val STRING2, LE_SP_PB1.pb1_##valid##link/M ,LE_SP_PB1.sp_##valid##link);                    \
fprintf(gp, "\n" STRING1 #req STRING2,LE_SP_PB1.pb1_##data_req##link/M, LE_SP_PB1.sp_##data_req##link);                \
for(i=0;i<64;i++)                                                                                            \
 fprintf(gp, "\n" STRING1 #out "[%d]" STRING2 , i ,LE_SP_PB1.pb1_##w_out##link[i]/M, LE_SP_PB1.sp_##w_out##link[i]);   \

#endif

#ifndef encodey


#define general( val, req, out, valid , data_req, w_out, link)  \
\
\
fprintf(gp, "\n\n" STRING1 #val STRING2, LE_SP_PB1.pb1_##valid##link/M ,LE_SP_PB1.sp_##valid##link);                    \
fprintf(gp, "\n" STRING1 #req STRING2,LE_SP_PB1.pb1_##data_req##link/M, LE_SP_PB1.sp_##data_req##link);                \
j=0;                                                                                                                 \
t=0;                                                                                                                 \
for(i=0;i<64;i++)                                                                                            \
 {                                                                                                                   \
  fprintf(gp, "\n" STRING1 #out "[%d]" STRING2 , t ,LE_SP_PB1.pb1_##w_out##link[i]/M, LE_SP_PB1.sp_##w_out##link[i]);   \
  j++;                                                                                                               \
  if(j==8)                                                                                                             \
   {                                                                                                                   \
    i=i+8;                                                                                                             \
    j=0;                                                                                                               \
   }                                                                                                                   \
  t++;                                                                                                                 \
 }                                                                                                                     \

#endif

#define generaln( val, req, out, valid , data_req, w_out, link)  \
\
\
fprintf(gp, "\n\n" STRING1 #val STRING2, LE_SP_PB1.pb1_##valid##link/M ,LE_SP_PB1.sp_##valid##link);                    \
fprintf(gp, "\n" STRING1 #req STRING2,LE_SP_PB1.pb1_##data_req##link/M, LE_SP_PB1.sp_##data_req##link);                \
for(i=0;i<32;i++)                                                                                            \
 fprintf(gp, "\n" STRING1 #out "[%d]" STRING2 , i ,LE_SP_PB1.pb1_##w_out##link[i]/M, LE_SP_PB1.sp_##w_out##link[i]);   \



#define correspond_leafz( val, req, out, link, fpl)    general( val ,req, out, out_val, data_in_req, router_out , link)
#define correspond_leaf( val, req, out, link, fpl)     generaln(val ,req, out, out_val, data_in_req, router_out , link)
#define correspond_stem( val, req, out, link, fpl)    general( val, req, out, out_val, data_in_req, router_out , link)
#define correspond_root( val, req, out, link, fpl)    general( val, req, out, out_val, data_in_req, data_out , link)
#define correspond_NI( val, req, out ,link, fpl)       generaln( val, req, out, data_valid , data_in_req_NI, packet_out ,link)

                                                                                    
                                                                                                                                                                
#define correspond_core_NI(send)                                                                                                               //not required


#define correspond_NI_core(received)                                                                              //not required



/*#define conclude(fpl)   \
                        \
fprintf(gp,STRINGL);    \ Change by Ken.*/
#define conclude(fpl) \
fclose(gp);  
 // change by Ken.
                                                                                                                                                               

                                                                                                                                                                                           
