/*
 PURPOSE : THIS FILE CONTAINS TWO MODULE WHICH WILL CALCULATE LINK POWER.
 LAST UPDATE DATE: 20 MARCH 2010.
*/
#include "systemc.h"
#include "enter.h"
#include "../config/define.cpp"
#include "../ser_deser/deserializer_h.cpp"
#include "../ser_deser/serializer_h.cpp"
#ifndef _ENERGY_H
#define _ENERGY_H


 

template < typename type , typename type_data  ,int in_port >

class energy_calc_32 : public sc_module{

        private :
                
                float energy [(in_port + 32) ] , s_energy [(in_port + 32) ] ,wire_length;
                char fl_nm[100];
                int prev [ (in_port  + 32) ],s_prev [ (in_port  + 32) ] ;
                char  file_name[50] , par0[50]  ;
                sc_uint<1> ini_ser [8][3] , ini [ 32 ] [ 3 ];
                fstream fp,fp1;
                double total,sh_total,sm_total,h_total;
                double table[8][8] , table_ser [ 8] [8] ;
                bool prev_bit[65] ;
                int no_1s[65], tog[65];
                deserializer *deser;
                serializer *ser;
        public:
        	
                sc_in < type > in [ in_port ] ;
                sc_in < type_data > data ;
                //sc_in < type_ack > ack[ number ];
                sc_in < bool > clk4x ,clk,ce;
                
                
                sc_signal< sc_uint<2> > cntr_out ;
                sc_signal< sc_uint<8> > ser_out ;
                SC_HAS_PROCESS ( energy_calc_32 ) ;
                
                energy_calc_32 ( sc_module_name nm, const char *router_name, const char *file_name_tmp ,const  char *t_par0 , float t_w_len, char *folder);
                ~energy_calc_32();
                virtual void log_energy_8 ( void ) ;
                virtual void log_energy_32 ( void ) ;
                virtual void log_energy_ser_HSPICE(void) ;
                virtual void log_energy_HSPICE(void) ;
                        
};

template < typename type , typename type_data  ,int in_port >
 energy_calc_32 < type , type_data ,  in_port  > ::energy_calc_32 ( sc_module_name nm, const char *router_ser ,const char *file_name_tmp ,const  char *t_par0 , float t_w_len, char *folder) : sc_module ( nm ) {
                        
                        
                        for( int ii = 0 ; ii<65 ; ii++ ){
                                no_1s [ ii ] = 0 ;
                                tog [ ii ] = 0 ;
                                prev_bit [ ii ] = false;
                        }
                        fl_nm[0]='\0';
                        strcat(fl_nm,folder);
                        strcat(fl_nm,"power_result/serializer_power/");
                        strcat(fl_nm,router_ser);
                        //sprintf(fl_nm,"%s/power_result/serializer_power/%s",folder,router_ser);
                        strcpy ( par0 , t_par0 ) ;
                        wire_length = t_w_len ;
                        total = sh_total = sm_total =  h_total = 0;
                        strcpy ( file_name , file_name_tmp ) ;
                        for ( int i = 0 ; i < (in_port  + 32) ; i++){
                                  
                                  energy [ i ] = s_energy [ i ] = 0 ;
                                  prev [ i ] = s_prev [ i ] = 0;
                        }          
                        for ( int k = 0 ; k  < 8 ; k++ )
                            for ( int i = 0 ; i < 3 ; i ++ )
                        	ini_ser[ k ] [ i ] = 0;                        
                        for ( int k = 0 ; k  < 32 ; k++ )
                            for ( int i = 0 ; i < 3 ; i ++ )
                        	ini[ k ] [ i ] = 0;        	
                        //cout << par0 ;
                        if ( strcmp(par0,"L_125") == 0 ){
		        	for ( int i = 0 ; i < 8 ; i++ ) {
		        		for ( int j = 0 ; j < 8 ; j ++ ) {
		        			table_ser [ i ] [ j ] = tab_ser_1_25mm [ i ] [ j ] ;
		        		}
		        	}
                           //cout << " " <<par0 ;
			}
			else if ( strcmp(par0,"L_25") == 0){
				for ( int i = 0 ; i < 8 ; i++ ) {
		        		for ( int j = 0 ; j < 8 ; j ++ ) {
		        			table_ser [ i ] [ j ] = tab_ser_2_5mm  [ i ] [ j ] ;
		        		}
		        	}//cout << " " <<par0 ;
			}
			else{
				for ( int i = 0 ; i < 8 ; i++ ) {
		        		for ( int j = 0 ; j < 8 ; j ++ ) {
		        			table_ser [ i ] [ j ] = tab_ser_5mm  [ i ] [ j ] ;
		        		}
		        	}//cout << " " <<par0 ;
			}
			
			
			if ( strcmp(par0,"L_125") == 0 ){
        			for ( int i = 0 ; i < 8 ; i++ ) {
        				for ( int j = 0 ; j < 8 ; j ++ ) {
        					table [ i ] [ j ] = tab_no_ser_1_25mm [ i ] [ j ] ;
        				}
        			}//cout << " " <<par0 <<endl;
			}
			else if ( strcmp(par0,"L_25") == 0){
				for ( int i = 0 ; i < 8 ; i++ ) {
		        		for ( int j = 0 ; j < 8 ; j ++ ) {
		        			table [ i ] [ j ] = tab_no_ser_2_5mm  [ i ] [ j ] ;
		        		}
		        	}//cout << " " <<par0 <<endl;
			}
			else{
				for ( int i = 0 ; i < 8 ; i++ ) {
		        		for ( int j = 0 ; j < 8 ; j ++ ) {
		        			table [ i ] [ j ] = tab_no_ser_5mm  [ i ] [ j ] ;
		        		}
		        	}//cout << " " <<par0 <<endl;
			}
		       // cout << fl_nm << endl;
                        
                        //=====================
                        deser = new deserializer("dser");
                          ser = new serializer("ser");
                        ser->ser_in(data);ser->clk4x(clk4x); ser->ce(ce) , ser->reset(in[0]);  ser->ser_out(ser_out);
                        ser->cntr_out(cntr_out);
                        
                        deser->deser_in(ser_out); deser->clk4x(clk4x) ; deser->reset(in[0]);
                        deser->sel(cntr_out) ;
                        
                        SC_METHOD(log_energy_8);
                                sensitive << clk4x.pos() ; //in [ in_port - 1 ].pos() ;
                        SC_METHOD(log_energy_32);
                                sensitive << clk.pos() ; //in [ in_port - 1 ].pos() ;
                        SC_METHOD(log_energy_ser_HSPICE);
                                sensitive << clk4x.pos() ; //in [ in_port - 1 ].pos() ;
                        SC_METHOD(log_energy_HSPICE);
                                sensitive << clk.pos() ; //in [ in_port - 1 ].pos() ;
                }
template < typename type , typename type_data  ,int in_port >
energy_calc_32 < type , type_data ,  in_port > :: ~energy_calc_32() {
                      
                      fp.open ( file_name , ios::app | ios::out ); // if u remove the ios::out , it will not work.
                      if ( fp.good() ){
                                fp  << total*wire_length * MAKE_mm *V<<"\t" << sm_total*wire_length * MAKE_mm *V<<"\t"<<
                                       h_total <<"\t" << sh_total << endl;
                      }
                      else{
                        cout << "ENERGY_CALC:: error \n";
                      } 
                      fp.close();
                       fp1.open ( fl_nm , ios::out );
                      if(fp1.good() ) {
                          fp1 << "set_input_transition 0 [all_inputs]\n";
                          fp1 << "create_clock -p 1.25 [get_ports clk]\n";
                          fp1 << "create_clock -p 5 [get_ports rd_clk]\n\n";
                          fp1 << "set_switching_activity [get_net reset]   -static_probability "<<(float)no_1s[ 0 ]/NO_SIMU_CLK  << POWER_STR2 <<tog[0] << POWER_STR3<< NO_SIMU_CLK *5 << endl;
                          fp1 << endl;
                          for ( int ii=1 ;ii < 33 ; ii ++ ){
                              fp1 << "set_switching_activity [get_net data_in["<<ii-1<<"]]" << POWER_STR1 <<(float)no_1s[ ii ]/NO_SIMU_CLK<< POWER_STR2 <<tog[ii] << POWER_STR3 << NO_SIMU_CLK *5 << endl;  
                              fp1 << endl;
                          }
                          for ( int ii=0 ;ii <32 ; ii ++ ){
                              fp1 << "set_switching_activity [get_net data_out["<<ii<<"]]" << POWER_STR1<<(float)no_1s[ ii+33 ]/NO_SIMU_CLK << POWER_STR2 <<tog[ii+33] << POWER_STR3 << NO_SIMU_CLK *5 << endl;  
                              fp1 << endl;
                          }

                      }  
                      else {
                            cout << "SER:FILE:ERR\n";
                      }  
                }
template < typename type , typename type_data  ,int in_port >
void energy_calc_32 < type , type_data ,  in_port > :: log_energy_32 ( void ) {  
        int t_data[32];
        for ( int i = 0 ; i < 32 ; i ++ )
             t_data[ i ] =(int) data.read().range(i,i); 
          
          
        //============  ENERGY  ====
                
                
        total = total +    ( ( clg_ref_ns_32lines[0] + cc_ref_ns_32lines ) * ( (int)in [ 0 ]  - prev [ 0 ] ) - 
                                                                    (cc_ref_ns_32lines) * ( (int)in [ 1 ] - prev [ 1 ])
                                                                  ) * (int)in [ 0 ];
                                                                   
        total = total +   ( - (cc_ref_ns_32lines)  * ( (int)in [ 0 ]  - prev [ 0 ] ) + 
                                                                    ( clg_ref_ns_32lines[1] + 2 * (cc_ref_ns_32lines)) * ( (int)in [ 1 ] - prev [ 1 ]) -
                                                                      (cc_ref_ns_32lines)  * ( (int)in [ 2 ]  - prev [ 2 ] )
                                                                ) * (int)in [ 1 ]; 
                                                               
        total = total +  ( - (cc_ref_ns_32lines)  * ( (int)in [ 1 ]  - prev [ 1 ] ) + 
                                                                    ( clg_ref_ns_32lines[2] + 2 * (cc_ref_ns_32lines)) * ( (int)in [ 2 ] - prev [ 2 ]) -
                                                                      (cc_ref_ns_32lines)  * ( t_data[0]  - prev [ 3 ] )
                                                                ) * (int)in [ 2 ]; 
        
        
        total = total +  ( - (cc_ref_ns_32lines)  * ( (int)in [ 2 ]  - prev [ 2 ] ) + 
                                                                    ( clg_ref_ns_32lines[3] + 2 * (cc_ref_ns_32lines)) * ( t_data[0] - prev [ 3 ]) -
                                                                      (cc_ref_ns_32lines)  * ( t_data[1] - prev [ 4 ] )
                                                                ) * t_data[0]; 
      
                                                                                                                                       
        for ( int i = 4 ; i < in_port + 28  ; i++ ) {                                                                                                                                     
                   total = total  +  ( - (cc_ref_ns_32lines) * ( t_data[i - 4]  - prev [ i - 1 ] ) + 
                                                                    ( clg_ref_ns_32lines[i] + 2 * (cc_ref_ns_32lines)) * ( t_data[ i - 4 + 1] - prev [ i ]) -
                                                                      (cc_ref_ns_32lines)  * ( t_data[ i - 4 + 2]  - prev [ i + 1 ] )
                                                                           ) * t_data[ i - 4 + 1]; 
                                                                                                           
        } 
        
        total = total +  ( - (cc_ref_ns_32lines)  * ( t_data[ 27 ]  - prev [ 30 ] ) + 
                                                                    ( clg_ref_ns_32lines[31] + 2 * (cc_ref_ns_32lines)) * ( t_data[ 28] - prev [ 31]) -
                                                                      (cc_ref_ns_32lines)  * (t_data[29]  - prev [ 32 ] )
                                                                  ) * t_data[ 28];               
         
        total = total  +  ( - (cc_ref_ns_32lines)  * ( t_data[28]  - prev [ 31 ] ) + 
                                                                    ( clg_ref_ns_32lines[32] + 2 * (cc_ref_ns_32lines)) * ( t_data[29] - prev [ 32 ]) -
                                                                      (cc_ref_ns_32lines)  * ( t_data[30]  - prev [ 33 ] )
                                                                  ) * t_data[29]; 
                                                              
        total = total +  ( - (cc_ref_ns_32lines)  * ( t_data[29]  - prev [ 32 ] ) + 
                                                                    (clg_ref_ns_32lines[33] + 2 * (cc_ref_ns_32lines)) * (t_data[30] - prev [ 33 ]) -
                                                                      (cc_ref_ns_32lines)  * ( t_data[31]  - prev [ 34] )
                                                                                     ) * t_data[30]; 
                                                                                 
        total = total + (  - (cc_ref_ns_32lines) * (t_data[30] - prev [ 33 ]) +
                                       (clg_ref_ns_32lines[34]  + (cc_ref_ns_32lines) ) * ( t_data[31]  - prev [ 34 ] )
                                                                                     ) * t_data[31] ;    
         
                                                                                      
         for ( int i = 0 ; i < in_port  ; i++ )                 
                        prev [ i ] =(int) in [ i ].read() ; 
         for ( int i = in_port ; i < in_port + 32  ; i++ )                 
                        prev [ i ] =(int)  data.read().range(i - in_port , i - in_port ) ; 
         
        //-------------------------------------               
         // ENERGY CALCULATION USING SERIALIZER.
         //-------------------------------------
         /*for ( int i = 0 ; i < 2 ; i ++ ) {
         	
         	        s_total = s_total +   ( ( 64.2  +(cc_ref_ws) ) * (t_data[16*i]  - s_prev [ 0 ] ) - 
                                                                    (cc_ref_ws) * (t_data[16*i+1] - s_prev [ 1 ])
                                                                  ) * t_data[16*i];
        		                                                          
		      for ( int k = 0 ; k < 14 ; k ++ )
         			  s_total = s_total  +  ( - (cc_ref_ws)  * ( t_data[16*i+k]  - s_prev [ k ] ) + 
                                                                    ( 57.5 + 2 * (cc_ref_ws)) * ( t_data[16*i+k+1]  - s_prev [ k+1 ]) -
                                                                      (cc_ref_ws) * ( t_data[16*i+k+2]  - s_prev [ k+2 ] )
                                                                           ) * t_data[16*i+k+1];                                                       
         		s_total = s_total  + (  - (cc_ref_ws) * ( t_data[16*i+14] - s_prev [ 14]) +
                                                  ( 48.626 + (cc_ref_ws) ) * (t_data[16*i+15] - s_prev [ 15] )
                                                                                     ) * t_data[16*i+15];    
         		
         		
         		for ( int j = 16*i ; j < 16*i+16 ; j ++)
         			s_prev [ j-16*i ] = t_data[j];
        }*/
          
}
template < typename type , typename type_data  ,int in_port  >
void energy_calc_32 < type , type_data ,  in_port  > :: log_energy_8 ( void ) {  
        
        
        
        int tt_data[8];
        for ( int i = 0 ; i < 8 ; i ++ )
             tt_data[ i ] =(int) ser_out.read().range(i,i); 
             
                      sm_total = sm_total +   ( ( clg_ref_ws[0]  +(cc_ref_ws) ) * (tt_data[0]  - s_prev [ 0 ] ) - 
                                                                    (cc_ref_ws) * (tt_data[1] - s_prev [ 1 ])
                                                                  ) * tt_data[0];
        		                                                          
		      for ( int k = 0 ; k < 6 ; k ++ )
         			  sm_total = sm_total  +  ( - (cc_ref_ws)  * ( tt_data[k]  - s_prev [ k ] ) + 
                                                                    ( clg_ref_ws[k+1]+ 2 * (cc_ref_ws)) * ( tt_data[k+1]  - s_prev [ k+1 ]) -
                                                                      (cc_ref_ws) * ( tt_data[k+2]  - s_prev [ k+2 ] )
                                                                           ) * tt_data[k+1];                                                       
         		sm_total = sm_total  + (  - (cc_ref_ws) * ( tt_data[6] - s_prev [ 6]) +
                                                  ( clg_ref_ws[7] + (cc_ref_ws) ) * (tt_data[7] - s_prev [ 7] )
                                                                                     ) * tt_data[7];    
         		
         		
         		for ( int j = 0 ; j < 8 ; j ++)
         			s_prev [ j ] = tt_data[j];
         			
         	/*		
         	int t_data[32];
        	for ( int i = 0 ; i < 32 ; i ++ )
        		t_data[ i ] =(int) data.read().range(i,i); 
		for ( int i = 0 ; i < 4 ; i ++ ) {
         	
         	        s_total = s_total +   ( ( clg_ref_ws[0]  +(cc_ref_ws) ) * (t_data[8*i]  - s_prev [ 0 ] ) - 
                                                                    (cc_ref_ws) * (t_data[8*i+1] - s_prev [ 1 ])
                                                                  ) * t_data[8*i];
        		                                                          
		      for ( int k = 0 ; k < 6 ; k ++ )
         			  s_total = s_total  +  ( - (cc_ref_ws)  * ( t_data[8*i+k]  - s_prev [ k ] ) + 
                                                                    ( clg_ref_ws[k+1] + 2 * (cc_ref_ws)) * ( t_data[8*i+k+1]  - s_prev [ k+1 ]) -
                                                                      (cc_ref_ws) * ( t_data[8*i+k+2]  - s_prev [ k+2 ] )
                                                                           ) * t_data[8*i+k+1];                                                       
         		s_total = s_total  + (  - (cc_ref_ws) * ( t_data[8*i+6] - s_prev [ 6]) +
                                                  ( clg_ref_ws[7] + (cc_ref_ws) ) * (t_data[8*i+7] - s_prev [ 7] )
                                                                                     ) * t_data[8*i+7];    
         		
         		
         		for ( int j = 8*i ; j < 8*i+8 ; j ++)
         			s_prev [ j-8*i ] = t_data[j];
        }        	*/		
         		
         /*int t_data[32];	
         for ( int i = 0 ; i < 32 ; i ++ )
        		t_data[ i ] =(int) data.read().range(i,i); 
         for ( int i = 0 ; i < 2 ; i ++ ) {
         	
         	        s_total = s_total +   ( ( 64.2  +(cc_ref_ws) ) * (t_data[16*i]  - s_prev [ 0 ] ) - 
                                                                    (cc_ref_ws) * (t_data[16*i+1] - s_prev [ 1 ])
                                                                  ) * t_data[16*i];
        		                                                          
		      for ( int k = 0 ; k < 14 ; k ++ )
         			  s_total = s_total  +  ( - (cc_ref_ws)  * ( t_data[16*i+k]  - s_prev [ k ] ) + 
                                                                    ( 57.5 + 2 * (cc_ref_ws)) * ( t_data[16*i+k+1]  - s_prev [ k+1 ]) -
                                                                      (cc_ref_ws) * ( t_data[16*i+k+2]  - s_prev [ k+2 ] )
                                                                           ) * t_data[16*i+k+1];                                                       
         		s_total = s_total  + (  - (cc_ref_ws) * ( t_data[16*i+14] - s_prev [ 14]) +
                                                  ( 48.626 + (cc_ref_ws) ) * (t_data[16*i+15] - s_prev [ 15] )
                                                                                     ) * t_data[16*i+15];    
         		
         		
         		for ( int j = 16*i ; j < 16*i+16 ; j ++)
         			s_prev [ j-16*i ] = t_data[j];
        }*/
                                                                                                                   
}
template < typename type , typename type_data  ,int in_port  >
void energy_calc_32 < type , type_data ,  in_port  > :: log_energy_ser_HSPICE ( void ) {  
	sc_uint<3> row , col ;
        char cc[7];
        
        for ( int k = 0 ; k < 8; k ++ ) {
        	
        		// copy current values
        		if ( k == 0 ){
                                cc[0]='0'; cc[1]='b'; cc[2]='0'; cc[3]='0'+(int)ini_ser [k][0]; cc[4]='0'+(int)ini_ser [k][1];cc[5]='\0';
                                
        			row = cc ;
                                cc[0]='0'; cc[1]='b'; cc[2]='0'; cc[3]='0'+(int)ser_out.read()[0]; cc[4]='0'+(int)ser_out.read()[1];cc[5]='\0';
        			col = cc;
        			//cout << row <<"  " << col <<endl;
        			sh_total = sh_total + table_ser [ row ] [ col ] ;
        			
        			//ini_ser [ k ] [ 0 ] = 0;
        			//ini_ser [ k ] [ 1 ] = ser_out.read()[0] ;
        			//ini_ser [ k ] [ 2 ] = ser_out.read()[1] ;
        			
        			/*row = ( ini_ser [k][0]       , ini_ser [k][1]        , ini_ser [k][2] ) ;
        			col = ( ser_out.read()[0], ser_out.read()[1] , ser_out.read()[2] ) ;
        			sh_total = sh_total + table_ser [ row ] [ col ] ;
        			
        			ini_ser [ k ] [ 0 ] = ser_out.read()[k];
        			ini_ser [ k ] [ 1 ] = ser_out.read()[k+1];
        			ini_ser [ k ] [ 2 ] = ser_out.read()[k+2];*/
        		}
        		else if ( k == 7 ) {
                         cc[0]='0'; cc[1]='b'; cc[2]='0'+(int)ini_ser [7][0] ; cc[3]='0'+(int)ini_ser [7][1]; cc[4]='0';cc[5]='\0';
                        row = cc;
                         cc[0]='0'; cc[1]='b'; cc[2]='0'+(int)ser_out.read()[6] ; cc[3]='0'+(int)ser_out.read()[7]; cc[4]='0';cc[5]='\0';
        			
        			col = cc;
        			sh_total = sh_total + table_ser [ row ] [ col ] ;
        			//ini_ser [ k ] [ 0 ] = ser_out.read()[6] ;
        			//ini_ser [ k ] [ 1 ] = ser_out.read()[7] ;
        			//ini_ser [ k ] [ 2 ] = 0 ;
        		}
        		else {
        			cc[0]='0'; cc[1]='b'; cc[2]='0'+(int)ini_ser [k][0] ; cc[3]='0'+(int)ini_ser [k][1]; cc[4]='0'+(int)ini_ser [k][2] ;cc[5]='\0';
        			row = cc;//cout << cc <<" "<< row<< endl;
                                cc[0]='0'; cc[1]='b'; cc[2]='0'+(int)ser_out.read()[k-1] ; cc[3]='0'+(int)ser_out.read()[k ]; cc[4]='0'+(int)ser_out.read()[k+1] ;cc[5]='\0';
        			col = cc; //cout << cc << " "<< col <<endl;
        			sh_total = sh_total + table_ser [ row ] [ col ] ;
        			
			        //ini_ser [ k ] [ 0 ] = ser_out.read()[k-1];
			        //ini_ser [ k ] [ 1 ] = ser_out.read()[k];
			        //ini_ser [ k ] [ 2 ] = ser_out.read()[k+1];
        		}
        	
        }
        ini_ser [ 0 ] [ 0 ] = 0;
        ini_ser [ 0 ] [ 1 ] = ser_out.read()[0] ;
        ini_ser [ 0 ] [ 2 ] = ser_out.read()[1] ;
        
        for ( int k = 1 ; k < 7 ; k ++ ){
        	ini_ser [ k ] [ 0 ] = ser_out.read()[k-1];
	        ini_ser [ k ] [ 1 ] = ser_out.read()[k];
		ini_ser [ k ] [ 2 ] = ser_out.read()[k+1];
        }
        ini_ser [ 7 ] [ 0 ] = ser_out.read()[6] ;
        ini_ser [ 7 ] [ 1 ] = ser_out.read()[7] ;
        ini_ser [ 7 ] [ 2 ] = 0 ;

        
}

template < typename type , typename type_data  ,int in_port  >
void energy_calc_32 < type , type_data ,  in_port  > :: log_energy_HSPICE ( void ) {  
	sc_uint<3> row , col ;
        char cc[7];
        
        for ( int k = 0 ; k < 32; k ++ ) {
        	
        		// copy current values
        		if ( k == 0 ){
                                cc[0]='0'; cc[1]='b'; cc[2]='0'; cc[3]='0'+(int)ini[k][0]; cc[4]='0'+(int)ini [k][1];cc[5]='\0';                                
        			row = cc ;
                                cc[0]='0'; cc[1]='b'; cc[2]='0'; cc[3]='0'+(int)data.read()[0]; cc[4]='0'+(int)data.read()[1];cc[5]='\0';
        			col = cc;
        			//row = ( 0 , ini [k][0]        , ini [k][1] ) ;
        			//col = ( 0 , data.read()[0] , data.read()[1] ) ;
        			h_total = h_total + table [ row ] [ col ] ;
        			
        			//ini [ k ] [ 0 ] = 0;
        			//ini [ k ] [ 1 ] = data.read()[0] ;
        			//ini [ k ] [ 2 ] = data.read()[1] ;
        			
        			/*row = ( ini [k][0]       , ini [k][1]        , ini [k][2] ) ;
        			col = ( data.read()[0], data.read()[1] , data.read()[2] ) ;
        			h_total = h_total + table [ row ] [ col ] ;
        			
        			ini [ k ] [ 0 ] = data.read()[k];
        			ini [ k ] [ 1 ] = data.read()[k+1];
        			ini [ k ] [ 2 ] = data.read()[k+2];*/
        		}
        		else if ( k == 31 ) {
                             cc[0]='0'; cc[1]='b'; cc[2]='0'+(int)ini [31][0] ; cc[3]='0'+(int)ini [31][1]; cc[4]='0';cc[5]='\0';
                             row = cc;
                             cc[0]='0'; cc[1]='b'; cc[2]='0'+(int)data.read()[30] ; cc[3]='0'+(int)data.read()[31]; cc[4]='0';cc[5]='\0';
        		     col = cc;

        			//row = ( ini [30][0]       , ini [31][1]        , 0 ) ;
        			//col = ( data.read()[30], data.read()[31] , 0 ) ;
        			h_total = h_total + table [ row ] [ col ] ;
        			//ini [ k ] [ 0 ] = data.read()[30] ;
        			//ini [ k ] [ 1 ] = data.read()[31] ;
        			//ini [ k ] [ 2 ] = 0 ;
        		}
        		else {
        			cc[0]='0'; cc[1]='b'; cc[2]='0'+(int)ini [k][0]  ; cc[3]='0'+(int)ini [k][1]; cc[4]='0'+(int)ini [k][2];cc[5]='\0';
                                row = cc;
                                cc[0]='0'; cc[1]='b'; cc[2]='0'+(int)data.read()[k-1] ; cc[3]='0'+(int)data.read()[k ]; cc[4]='0'+(int)data.read()[k+1] ;cc[5]='\0';
        		        col = cc;
        			//row = ( ini [k][0]       , ini [k][1]        , ini [k][2] ) ;
        			//col = ( data.read()[k-1], data.read()[k ] , data.read()[k+1] ) ;
        			h_total = h_total + table [ row ] [ col ] ;
        			
			        //ini [ k ] [ 0 ] = data.read()[k-1];
			        //ini [ k ] [ 1 ] = data.read()[k];
			        //ini [ k ] [ 2 ] = data.read()[k+1];
        		}
        	
        }
        ini [ 0 ] [ 0 ] = 0;
        ini [ 0 ] [ 1 ] = data.read()[0] ;
        ini [ 0 ] [ 2 ] = data.read()[1] ;
        
        for ( int k = 1 ; k < 31 ; k ++ ){
        	ini [ k ] [ 0 ] = data.read()[k-1];
	        ini [ k ] [ 1 ] = data.read()[k];
		ini [ k ] [ 2 ] = data.read()[k+1];
        }
        ini [ 31 ] [ 0 ] = data.read()[30] ;
        ini [ 31 ] [ 1 ] = data.read()[31] ;
        ini [ 31 ] [ 2 ] = 0 ;
        
        if ( (prev_bit [ 0 ] ^ in[0].read())  == SC_LOGIC_1 ) { // FIND Toggle(s)
                        tog [ 0 ] ++ ;
                        
        }
        if ( (bool)(in[0].read()) == SC_LOGIC_1 ) no_1s [ 0 ] ++;                 
                prev_bit [ 0 ] = in[0].read() ;  

        for ( int i = 1 ; i <  33 ; i++ ) {
                if ( (prev_bit [ i-1 ] ^ ( type )(data.read().range(i-1  , i-1 )) ) == SC_LOGIC_1 ) { // FIND Toggle(s)
                        tog [ i ] ++ ;
                        
                }
                if ( (bool)(data.read().range(i-1  , i-1 )) == SC_LOGIC_1 ) no_1s [ i ] ++;                 
                prev_bit [ i ] = data.read().range(i-1  ,i-1 ) ;  
          } 
          for ( int i = 0 ; i <  32 ; i++ ) {
                if ( (prev_bit [ 33+i ] ^ ( type )(deser->deser_out.read().range(i  , i )) ) == SC_LOGIC_1 ) { // FIND Toggle(s)
                        tog [ 33+i ] ++ ;
                        
                }
                if ( (bool)(deser->deser_out.read().range(i  , i )) == SC_LOGIC_1 ) no_1s [ 33+i ] ++;                 
                prev_bit [ 33+i ] = deser->deser_out.read().range(i  , i );
          }   
}
#endif
