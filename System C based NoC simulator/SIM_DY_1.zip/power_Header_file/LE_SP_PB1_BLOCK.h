
#include  "systemc.h"
#include<stdio.h>
#include "macrosMOT.h"
#include "update.h"

SC_MODULE(LE_SP_PB1_BLOCK)
 {

    sc_in < flit > router_out3_00,
                   router_out4_00,
                   router_out3_01,
                   router_out4_01,
                   router_out3_02,
                   router_out4_02,
                   router_out3_03,
                   router_out4_03,
                   router_out3_10,
                   router_out4_10,
                   router_out3_11,
                   router_out4_11,
                   router_out3_12,
                   router_out4_12,
                   router_out3_13,
                   router_out4_13,
                   router_out3_20,
                   router_out4_20,
                   router_out3_21,
                   router_out4_21,
                   router_out3_22,
                   router_out4_22,
                   router_out3_23,
                   router_out4_23,
                   router_out3_30,
                   router_out4_30,
                   router_out3_31,
                   router_out4_31,
                   router_out3_32,
                   router_out4_32,
                   router_out3_33,
                   router_out4_33,
                   router_out1_r0_01,
                   router_out2_r0_01,
                   router_out3_r0_01,
                   router_out1_r0_23,
                   router_out2_r0_23,
                   router_out3_r0_23,
                   router_out1_r1_01,
                   router_out2_r1_01,
                   router_out3_r1_01,
                   router_out1_r1_23,
                   router_out2_r1_23,
                   router_out3_r1_23,
                   router_out1_r2_01,
                   router_out2_r2_01,
                   router_out3_r2_01,
                   router_out1_r2_23,
                   router_out2_r2_23,
                   router_out3_r2_23,
                   router_out1_r3_01,
                   router_out2_r3_01,
                   router_out3_r3_01,
                   router_out1_r3_23,
                   router_out2_r3_23,
                   router_out3_r3_23,
                   router_out1_c0_01,
                   router_out2_c0_01,
                   router_out3_c0_01,
                   router_out1_c0_23,
                   router_out2_c0_23,
                   router_out3_c0_23,
                   router_out1_c1_01,
                   router_out2_c1_01,
                   router_out3_c1_01,
                   router_out1_c1_23,
                   router_out2_c1_23,
                   router_out3_c1_23,
                   router_out1_c2_01,
                   router_out2_c2_01,
                   router_out3_c2_01,
                   router_out1_c2_23,
                   router_out2_c2_23,
                   router_out3_c2_23,
                   router_out1_c3_01,
                   router_out2_c3_01,
                   router_out3_c3_01,
                   router_out1_c3_23,
                   router_out2_c3_23,
                   router_out3_c3_23,
                   data_out1_r0,
                   data_out2_r0,
                   data_out1_r1,
                   data_out2_r1,
                   data_out1_r2,
                   data_out2_r2,
                   data_out1_r3,
                   data_out2_r3,
                   data_out1_c0,
                   data_out2_c0,
                   data_out1_c1,
                   data_out2_c1,
                   data_out1_c2,
                   data_out2_c2,
                   data_out1_c3,
                   data_out2_c3;
              

 sc_in<sc_uint<32> > packet_out1_00,
                   router_out1_00,
                   packet_out2_00,
                   router_out2_00,
                   packet_out1_01,
                   router_out1_01,
                   packet_out2_01,
                   router_out2_01,
                   packet_out1_02,
                   router_out1_02,
                   packet_out2_02,
                   router_out2_02,
                   packet_out1_03,
                   router_out1_03,
                   packet_out2_03,
                   router_out2_03,
                   packet_out1_10,
                   router_out1_10,
                   packet_out2_10,
                   router_out2_10,
                   packet_out1_11,
                   router_out1_11,
                   packet_out2_11,
                   router_out2_11,
                   packet_out1_12,
                   router_out1_12,
                   packet_out2_12,
                   router_out2_12,
                   packet_out1_13,
                   router_out1_13,
                   packet_out2_13,
                   router_out2_13,
                   packet_out1_20,
                   router_out1_20,
                   packet_out2_20,
                   router_out2_20,
                   packet_out1_21,
                   router_out1_21,
                   packet_out2_21,
                   router_out2_21,
                   packet_out1_22,
                   router_out1_22,
                   packet_out2_22,
                   router_out2_22,
                   packet_out1_23,
                   router_out1_23,
                   packet_out2_23,
                   router_out2_23,
                   packet_out1_30,
                   router_out1_30,
                   packet_out2_30,
                   router_out2_30,
                   packet_out1_31,
                   router_out1_31,
                   packet_out2_31,
                   router_out2_31,
                   packet_out1_32,
                   router_out1_32,
                   packet_out2_32,
                   router_out2_32,
                   packet_out1_33,
                   router_out1_33,
                   router_out2_33,
                   packet_out2_33;

    sc_in< bool > data_in_req1_00,
                  data_in_req2_00,
                  data_in_req3_00,
                  data_in_req4_00,
                  data_in_req1_01,
                  data_in_req2_01,
                  data_in_req3_01,
                  data_in_req4_01,
                  data_in_req1_02,
                  data_in_req2_02,
                  data_in_req3_02,
                  data_in_req4_02,
                  data_in_req1_03,
                  data_in_req2_03,
                  data_in_req3_03,
                  data_in_req4_03,
                  data_in_req1_10,
                  data_in_req2_10,
                  data_in_req3_10,
                  data_in_req4_10,
                  data_in_req1_11,
                  data_in_req2_11,
                  data_in_req3_11,
                  data_in_req4_11,
                  data_in_req1_12,
                  data_in_req2_12,
                  data_in_req3_12,
                  data_in_req4_12,
                  data_in_req1_13,
                  data_in_req2_13,
                  data_in_req3_13,
                  data_in_req4_13,
                  data_in_req1_20,
                  data_in_req2_20,
                  data_in_req3_20,
                  data_in_req4_20,
                  data_in_req1_21,
                  data_in_req2_21,
                  data_in_req3_21,
                  data_in_req4_21,
                  data_in_req1_22,
                  data_in_req2_22,
                  data_in_req3_22,
                  data_in_req4_22,
                  data_in_req1_23,
                  data_in_req2_23,
                  data_in_req3_23,
                  data_in_req4_23,
                  data_in_req1_30,
                  data_in_req2_30,
                  data_in_req3_30,
                  data_in_req4_30,
                  data_in_req1_31,
                  data_in_req2_31,
                  data_in_req3_31,
                  data_in_req4_31,
                  data_in_req1_32,
                  data_in_req2_32,
                  data_in_req3_32,
                  data_in_req4_32,
                  data_in_req1_33,
                  data_in_req2_33,
                  data_in_req3_33,
                  data_in_req4_33,
                  data_in_req1_r0_01,
                  data_in_req2_r0_01,
                  data_in_req3_r0_01,
                  data_in_req1_r0_23,
                  data_in_req2_r0_23,
                  data_in_req3_r0_23,
                  data_in_req1_r1_01,
                  data_in_req2_r1_01,
                  data_in_req3_r1_01,
                  data_in_req1_r1_23,
                  data_in_req2_r1_23,
                  data_in_req3_r1_23,
                  data_in_req1_r2_01,
                  data_in_req2_r2_01,
                  data_in_req3_r2_01,
                  data_in_req1_r2_23,
                  data_in_req2_r2_23,
                  data_in_req3_r2_23,
                  data_in_req1_r3_01,
                  data_in_req2_r3_01,
                  data_in_req3_r3_01,
                  data_in_req1_r3_23,
                  data_in_req2_r3_23,
                  data_in_req3_r3_23,
                  data_in_req1_c0_01,
                  data_in_req2_c0_01,
                  data_in_req3_c0_01,
                  data_in_req1_c0_23,
                  data_in_req2_c0_23,
                  data_in_req3_c0_23,
                  data_in_req1_c1_01,
                  data_in_req2_c1_01,
                  data_in_req3_c1_01,
                  data_in_req1_c1_23,
                  data_in_req2_c1_23,
                  data_in_req3_c1_23,
                  data_in_req1_c2_01,
                  data_in_req2_c2_01,
                  data_in_req3_c2_01,
                  data_in_req1_c2_23,
                  data_in_req2_c2_23,
                  data_in_req3_c2_23,
                  data_in_req1_c3_01,
                  data_in_req2_c3_01,
                  data_in_req3_c3_01,
                  data_in_req1_c3_23,
                  data_in_req2_c3_23,
                  data_in_req3_c3_23,
                  data_in_req1_r0,
                  data_in_req2_r0,
                  data_in_req1_r1,
                  data_in_req2_r1,
                  data_in_req1_r2,
                  data_in_req2_r2,
                  data_in_req1_r3,
                  data_in_req2_r3,
                  data_in_req1_c0,
                  data_in_req2_c0,
                  data_in_req1_c1,
                  data_in_req2_c1,
                  data_in_req1_c2,
                  data_in_req2_c2,
                  data_in_req1_c3,
                  data_in_req2_c3,
                  data_in_req_NI1_00,
                  data_in_req_NI2_00,
                  data_in_req_NI1_01,
                  data_in_req_NI2_01,
                  data_in_req_NI1_02,
                  data_in_req_NI2_02,
                  data_in_req_NI1_03,
                  data_in_req_NI2_03,
                  data_in_req_NI1_10,
                  data_in_req_NI2_10,
                  data_in_req_NI1_11,
                  data_in_req_NI2_11,
                  data_in_req_NI1_12,
                  data_in_req_NI2_12,
                  data_in_req_NI1_13,
                  data_in_req_NI2_13,
                  data_in_req_NI1_20,
                  data_in_req_NI2_20,
                  data_in_req_NI1_21,
                  data_in_req_NI2_21,
                  data_in_req_NI1_22,
                  data_in_req_NI2_22,
                  data_in_req_NI1_23,
                  data_in_req_NI2_23,
                  data_in_req_NI1_30,
                  data_in_req_NI2_30,
                  data_in_req_NI1_31,
                  data_in_req_NI2_31,
                  data_in_req_NI1_32,
                  data_in_req_NI2_32,
                  data_in_req_NI1_33,
                  data_in_req_NI2_33;

    sc_in< bool > out_val1_00,
                  out_val2_00,
                  out_val3_00,
                  out_val4_00,
                  out_val1_01,
                  out_val2_01,
                  out_val3_01,
                  out_val4_01,
                  out_val1_02,
                  out_val2_02,
                  out_val3_02,
                  out_val4_02,
                  out_val1_03,
                  out_val2_03,
                  out_val3_03,
                  out_val4_03,
                  out_val1_10,
                  out_val2_10,
                  out_val3_10,
                  out_val4_10,
                  out_val1_11,
                  out_val2_11,
                  out_val3_11,
                  out_val4_11,
                  out_val1_12,
                  out_val2_12,
                  out_val3_12,
                  out_val4_12,
                  out_val1_13,
                  out_val2_13,
                  out_val3_13,
                  out_val4_13,
                  out_val1_20,
                  out_val2_20,
                  out_val3_20,
                  out_val4_20,
                  out_val1_21,
                  out_val2_21,
                  out_val3_21,
                  out_val4_21,
                  out_val1_22,
                  out_val2_22,
                  out_val3_22,
                  out_val4_22,
                  out_val1_23,
                  out_val2_23,
                  out_val3_23,
                  out_val4_23,
                  out_val1_30,
                  out_val2_30,
                  out_val3_30,
                  out_val4_30,
                  out_val1_31,
                  out_val2_31,
                  out_val3_31,
                  out_val4_31,
                  out_val1_32,
                  out_val2_32,
                  out_val3_32,
                  out_val4_32,
                  out_val1_33,
                  out_val2_33,
                  out_val3_33,
                  out_val4_33,
                  out_val1_r0_01,
                  out_val2_r0_01,
                  out_val3_r0_01,
                  out_val1_r0_23,
                  out_val2_r0_23,
                  out_val3_r0_23,
                  out_val1_r1_01,
                  out_val2_r1_01,
                  out_val3_r1_01,
                  out_val1_r1_23,
                  out_val2_r1_23,
                  out_val3_r1_23,
                  out_val1_r2_01,
                  out_val2_r2_01,
                  out_val3_r2_01,
                  out_val1_r2_23,
                  out_val2_r2_23,
                  out_val3_r2_23,
                  out_val1_r3_01,
                  out_val2_r3_01,
                  out_val3_r3_01,
                  out_val1_r3_23,
                  out_val2_r3_23,
                  out_val3_r3_23,
                  out_val1_c0_01,
                  out_val2_c0_01,
                  out_val3_c0_01,
                  out_val1_c0_23,
                  out_val2_c0_23,
                  out_val3_c0_23,
                  out_val1_c1_01,
                  out_val2_c1_01,
                  out_val3_c1_01,
                  out_val1_c1_23,
                  out_val2_c1_23,
                  out_val3_c1_23,
                  out_val1_c2_01,
                  out_val2_c2_01,
                  out_val3_c2_01,
                  out_val1_c2_23,
                  out_val2_c2_23,
                  out_val3_c2_23,
                  out_val1_c3_01,
                  out_val2_c3_01,
                  out_val3_c3_01,
                  out_val1_c3_23,
                  out_val2_c3_23,
                  out_val3_c3_23,
                  out_val1_r0,
                  out_val2_r0,
                  out_val1_r1,
                  out_val2_r1,
                  out_val1_r2,
                  out_val2_r2,
                  out_val1_r3,
                  out_val2_r3,
                  out_val1_c0,
                  out_val2_c0,
                  out_val1_c1,
                  out_val2_c1,
                  out_val1_c2,
                  out_val2_c2,
                  out_val1_c3,
                  out_val2_c3,
                  data_valid1_00,
                  data_valid2_00,
                  data_valid1_01,
                  data_valid2_01,
                  data_valid1_02,
                  data_valid2_02,
                  data_valid1_03,
                  data_valid2_03,
                  data_valid1_10,
                  data_valid2_10,
                  data_valid1_11,
                  data_valid2_11,
                  data_valid1_12,
                  data_valid2_12,
                  data_valid1_13,
                  data_valid2_13,
                  data_valid1_20,
                  data_valid2_20,
                  data_valid1_21,
                  data_valid2_21,
                  data_valid1_22,
                  data_valid2_22,
                  data_valid1_23,
                  data_valid2_23,
                  data_valid1_30,
                  data_valid2_30,
                  data_valid1_31,
                  data_valid2_31,
                  data_valid1_32,
                  data_valid2_32,
                  data_valid1_33,
                  data_valid2_33; 

    sc_in_clk router_clk_00,
              router_clk_01,
              router_clk_02,
              router_clk_03,
              router_clk_10,
              router_clk_11,
              router_clk_12,
              router_clk_13,
              router_clk_20,
              router_clk_21,
              router_clk_22,
              router_clk_23,
              router_clk_30,
              router_clk_31,
              router_clk_32,
              router_clk_33,
              router_clk_r0_01,
              router_clk_r0_23,
              router_clk_r1_01,
              router_clk_r1_23,
              router_clk_r2_01,
              router_clk_r2_23,
              router_clk_r3_01,
              router_clk_r3_23,
              router_clk_c0_01,
              router_clk_c0_23,
              router_clk_c1_01,
              router_clk_c1_23,
              router_clk_c2_01,
              router_clk_c2_23,
              router_clk_c3_01,
              router_clk_c3_23,
              router_clk_r0,
              router_clk_r1,
              router_clk_r2,
              router_clk_r3,
              router_clk_c0,
              router_clk_c1,
              router_clk_c2,
              router_clk_c3,
              clk_core1_00,
              clk_core2_00,
              clk_core1_01,
              clk_core2_01,
              clk_core1_02,
              clk_core2_02,
              clk_core1_03,
              clk_core2_03,
              clk_core1_10,
              clk_core2_10,
              clk_core1_11,
              clk_core2_11,
              clk_core1_12,
              clk_core2_12,
              clk_core1_13,
              clk_core2_13,
              clk_core1_20,
              clk_core2_20,
              clk_core1_21,
              clk_core2_21,
              clk_core1_22,
              clk_core2_22,
              clk_core1_23,
              clk_core2_23,
              clk_core1_30,
              clk_core2_30,
              clk_core1_31,
              clk_core2_31,
              clk_core1_32,
              clk_core2_32,
              clk_core1_33,
              clk_core2_33;

    mflit present_router_out1_00,
          present_router_out2_00,
          present_router_out3_00,
          present_router_out4_00,
          present_router_out1_01,
          present_router_out2_01,
          present_router_out3_01,
          present_router_out4_01,
          present_router_out1_02,
          present_router_out2_02,
          present_router_out3_02,
          present_router_out4_02,
          present_router_out1_03,
          present_router_out2_03,
          present_router_out3_03,
          present_router_out4_03,
          present_router_out1_10,
          present_router_out2_10,
          present_router_out3_10,
          present_router_out4_10,
          present_router_out1_11,
          present_router_out2_11,
          present_router_out3_11,
          present_router_out4_11,
          present_router_out1_12,
          present_router_out2_12,
          present_router_out3_12,
          present_router_out4_12,
          present_router_out1_13,
          present_router_out2_13,
          present_router_out3_13,
          present_router_out4_13,
          present_router_out1_20,
          present_router_out2_20,
          present_router_out3_20,
          present_router_out4_20,
          present_router_out1_21,
          present_router_out2_21,
          present_router_out3_21,
          present_router_out4_21,
          present_router_out1_22,
          present_router_out2_22,
          present_router_out3_22,
          present_router_out4_22,
          present_router_out1_23,
          present_router_out2_23,
          present_router_out3_23,
          present_router_out4_23,
          present_router_out1_30,
          present_router_out2_30,
          present_router_out3_30,
          present_router_out4_30,
          present_router_out1_31,
          present_router_out2_31,
          present_router_out3_31,
          present_router_out4_31,
          present_router_out1_32,
          present_router_out2_32,
          present_router_out3_32,
          present_router_out4_32,
          present_router_out1_33,
          present_router_out2_33,
          present_router_out3_33,
          present_router_out4_33,
          present_router_out1_r0_01,
          present_router_out2_r0_01,
          present_router_out3_r0_01,
          present_router_out1_r0_23,
          present_router_out2_r0_23,
          present_router_out3_r0_23,
          present_router_out1_r1_01,
          present_router_out2_r1_01,
          present_router_out3_r1_01,
          present_router_out1_r1_23,
          present_router_out2_r1_23,
          present_router_out3_r1_23,
          present_router_out1_r2_01,
          present_router_out2_r2_01,
          present_router_out3_r2_01,
          present_router_out1_r2_23,
          present_router_out2_r2_23,
          present_router_out3_r2_23,
          present_router_out1_r3_01,
          present_router_out2_r3_01,
          present_router_out3_r3_01,
          present_router_out1_r3_23,
          present_router_out2_r3_23,
          present_router_out3_r3_23,
          present_router_out1_c0_01,
          present_router_out2_c0_01,
          present_router_out3_c0_01,
          present_router_out1_c0_23,
          present_router_out2_c0_23,
          present_router_out3_c0_23,
          present_router_out1_c1_01,
          present_router_out2_c1_01,
          present_router_out3_c1_01,
          present_router_out1_c1_23,
          present_router_out2_c1_23,
          present_router_out3_c1_23,
          present_router_out1_c2_01,
          present_router_out2_c2_01,
          present_router_out3_c2_01,
          present_router_out1_c2_23,
          present_router_out2_c2_23,
          present_router_out3_c2_23,
          present_router_out1_c3_01,
          present_router_out2_c3_01,
          present_router_out3_c3_01,
          present_router_out1_c3_23,
          present_router_out2_c3_23,
          present_router_out3_c3_23,
          present_data_out1_r0,
          present_data_out2_r0,
          present_data_out1_r1,
          present_data_out2_r1,
          present_data_out1_r2,
          present_data_out2_r2,
          present_data_out1_r3,
          present_data_out2_r3,
          present_data_out1_c0,
          present_data_out2_c0,
          present_data_out1_c1,
          present_data_out2_c1,
          present_data_out1_c2,
          present_data_out2_c2,
          present_data_out1_c3,
          present_data_out2_c3,
          present_packet_out1_00,
          present_packet_out2_00,
          present_packet_out1_01,
          present_packet_out2_01,
          present_packet_out1_02,
          present_packet_out2_02,
          present_packet_out1_03,
          present_packet_out2_03,
          present_packet_out1_10,
          present_packet_out2_10,
          present_packet_out1_11,
          present_packet_out2_11,
          present_packet_out1_12,
          present_packet_out2_12,
          present_packet_out1_13,
          present_packet_out2_13,
          present_packet_out1_20,
          present_packet_out2_20,
          present_packet_out1_21,
          present_packet_out2_21,
          present_packet_out1_22,
          present_packet_out2_22,
          present_packet_out1_23,
          present_packet_out2_23,
          present_packet_out1_30,
          present_packet_out2_30,
          present_packet_out1_31,
          present_packet_out2_31,
          present_packet_out1_32,
          present_packet_out2_32,
          present_packet_out1_33,
          present_packet_out2_33;
    
    mflit prev_router_out1_00,
          prev_router_out2_00,
          prev_router_out3_00,
          prev_router_out4_00,
          prev_router_out1_01,
          prev_router_out2_01,
          prev_router_out3_01,
          prev_router_out4_01,
          prev_router_out1_02,
          prev_router_out2_02,
          prev_router_out3_02,
          prev_router_out4_02,
          prev_router_out1_03,
          prev_router_out2_03,
          prev_router_out3_03,
          prev_router_out4_03,
          prev_router_out1_10,
          prev_router_out2_10,
          prev_router_out3_10,
          prev_router_out4_10,
          prev_router_out1_11,
          prev_router_out2_11,
          prev_router_out3_11,
          prev_router_out4_11,
          prev_router_out1_12,
          prev_router_out2_12,
          prev_router_out3_12,
          prev_router_out4_12,
          prev_router_out1_13,
          prev_router_out2_13,
          prev_router_out3_13,
          prev_router_out4_13,
          prev_router_out1_20,
          prev_router_out2_20,
          prev_router_out3_20,
          prev_router_out4_20,
          prev_router_out1_21,
          prev_router_out2_21,
          prev_router_out3_21,
          prev_router_out4_21,
          prev_router_out1_22,
          prev_router_out2_22,
          prev_router_out3_22,
          prev_router_out4_22,
          prev_router_out1_23,
          prev_router_out2_23,
          prev_router_out3_23,
          prev_router_out4_23,
          prev_router_out1_30,
          prev_router_out2_30,
          prev_router_out3_30,
          prev_router_out4_30,
          prev_router_out1_31,
          prev_router_out2_31,
          prev_router_out3_31,
          prev_router_out4_31,
          prev_router_out1_32,
          prev_router_out2_32,
          prev_router_out3_32,
          prev_router_out4_32,
          prev_router_out1_33,
          prev_router_out2_33,
          prev_router_out3_33,
          prev_router_out4_33,
          prev_router_out1_r0_01,
          prev_router_out2_r0_01,
          prev_router_out3_r0_01,
          prev_router_out1_r0_23,
          prev_router_out2_r0_23,
          prev_router_out3_r0_23,
          prev_router_out1_r1_01,
          prev_router_out2_r1_01,
          prev_router_out3_r1_01,
          prev_router_out1_r1_23,
          prev_router_out2_r1_23,
          prev_router_out3_r1_23,
          prev_router_out1_r2_01,
          prev_router_out2_r2_01,
          prev_router_out3_r2_01,
          prev_router_out1_r2_23,
          prev_router_out2_r2_23,
          prev_router_out3_r2_23,
          prev_router_out1_r3_01,
          prev_router_out2_r3_01,
          prev_router_out3_r3_01,
          prev_router_out1_r3_23,
          prev_router_out2_r3_23,
          prev_router_out3_r3_23,
          prev_router_out1_c0_01,
          prev_router_out2_c0_01,
          prev_router_out3_c0_01,
          prev_router_out1_c0_23,
          prev_router_out2_c0_23,
          prev_router_out3_c0_23,
          prev_router_out1_c1_01,
          prev_router_out2_c1_01,
          prev_router_out3_c1_01,
          prev_router_out1_c1_23,
          prev_router_out2_c1_23,
          prev_router_out3_c1_23,
          prev_router_out1_c2_01,
          prev_router_out2_c2_01,
          prev_router_out3_c2_01,
          prev_router_out1_c2_23,
          prev_router_out2_c2_23,
          prev_router_out3_c2_23,
          prev_router_out1_c3_01,
          prev_router_out2_c3_01,
          prev_router_out3_c3_01,
          prev_router_out1_c3_23,
          prev_router_out2_c3_23,
          prev_router_out3_c3_23,
          prev_data_out1_r0,
          prev_data_out2_r0,
          prev_data_out1_r1,
          prev_data_out2_r1,
          prev_data_out1_r2,
          prev_data_out2_r2,
          prev_data_out1_r3,
          prev_data_out2_r3,
          prev_data_out1_c0,
          prev_data_out2_c0,
          prev_data_out1_c1,
          prev_data_out2_c1,
          prev_data_out1_c2,
          prev_data_out2_c2,
          prev_data_out1_c3,
          prev_data_out2_c3,
          prev_packet_out1_00,
          prev_packet_out2_00,
          prev_packet_out1_01,
          prev_packet_out2_01,
          prev_packet_out1_02,
          prev_packet_out2_02,
          prev_packet_out1_03,
          prev_packet_out2_03,
          prev_packet_out1_10,
          prev_packet_out2_10,
          prev_packet_out1_11,
          prev_packet_out2_11,
          prev_packet_out1_12,
          prev_packet_out2_12,
          prev_packet_out1_13,
          prev_packet_out2_13,
          prev_packet_out1_20,
          prev_packet_out2_20,
          prev_packet_out1_21,
          prev_packet_out2_21,
          prev_packet_out1_22,
          prev_packet_out2_22,
          prev_packet_out1_23,
          prev_packet_out2_23,
          prev_packet_out1_30,
          prev_packet_out2_30,
          prev_packet_out1_31,
          prev_packet_out2_31,
          prev_packet_out1_32,
          prev_packet_out2_32,
          prev_packet_out1_33,
          prev_packet_out2_33;

    bool  prev_data_in_req1_00,
          prev_data_in_req2_00,
          prev_data_in_req3_00,
          prev_data_in_req4_00,
          prev_data_in_req1_01,
          prev_data_in_req2_01,
          prev_data_in_req3_01,
          prev_data_in_req4_01,
          prev_data_in_req1_02,
          prev_data_in_req2_02,
          prev_data_in_req3_02,
          prev_data_in_req4_02,
          prev_data_in_req1_03,
          prev_data_in_req2_03,
          prev_data_in_req3_03,
          prev_data_in_req4_03,
          prev_data_in_req1_10,
          prev_data_in_req2_10,
          prev_data_in_req3_10,
          prev_data_in_req4_10,
          prev_data_in_req1_11,
          prev_data_in_req2_11,
          prev_data_in_req3_11,
          prev_data_in_req4_11,
          prev_data_in_req1_12,
          prev_data_in_req2_12,
          prev_data_in_req3_12,
          prev_data_in_req4_12,
          prev_data_in_req1_13,
          prev_data_in_req2_13,
          prev_data_in_req3_13,
          prev_data_in_req4_13,
          prev_data_in_req1_20,
          prev_data_in_req2_20,
          prev_data_in_req3_20,
          prev_data_in_req4_20,
          prev_data_in_req1_21,
          prev_data_in_req2_21,
          prev_data_in_req3_21,
          prev_data_in_req4_21,
          prev_data_in_req1_22,
          prev_data_in_req2_22,
          prev_data_in_req3_22,
          prev_data_in_req4_22,
          prev_data_in_req1_23,
          prev_data_in_req2_23,
          prev_data_in_req3_23,
          prev_data_in_req4_23,
          prev_data_in_req1_30,
          prev_data_in_req2_30,
          prev_data_in_req3_30,
          prev_data_in_req4_30,
          prev_data_in_req1_31,
          prev_data_in_req2_31,
          prev_data_in_req3_31,
          prev_data_in_req4_31,
          prev_data_in_req1_32,
          prev_data_in_req2_32,
          prev_data_in_req3_32,
          prev_data_in_req4_32,
          prev_data_in_req1_33,
          prev_data_in_req2_33,
          prev_data_in_req3_33,
          prev_data_in_req4_33,
          prev_data_in_req1_r0_01,
          prev_data_in_req2_r0_01,
          prev_data_in_req3_r0_01,
          prev_data_in_req1_r0_23,
          prev_data_in_req2_r0_23,
          prev_data_in_req3_r0_23,
          prev_data_in_req1_r1_01,
          prev_data_in_req2_r1_01,
          prev_data_in_req3_r1_01,
          prev_data_in_req1_r1_23,
          prev_data_in_req2_r1_23,
          prev_data_in_req3_r1_23,
          prev_data_in_req1_r2_01,
          prev_data_in_req2_r2_01,
          prev_data_in_req3_r2_01,
          prev_data_in_req1_r2_23,
          prev_data_in_req2_r2_23,
          prev_data_in_req3_r2_23,
          prev_data_in_req1_r3_01,
          prev_data_in_req2_r3_01,
          prev_data_in_req3_r3_01,
          prev_data_in_req1_r3_23,
          prev_data_in_req2_r3_23,
          prev_data_in_req3_r3_23,
          prev_data_in_req1_c0_01,
          prev_data_in_req2_c0_01,
          prev_data_in_req3_c0_01,
          prev_data_in_req1_c0_23,
          prev_data_in_req2_c0_23,
          prev_data_in_req3_c0_23,
          prev_data_in_req1_c1_01,
          prev_data_in_req2_c1_01,
          prev_data_in_req3_c1_01,
          prev_data_in_req1_c1_23,
          prev_data_in_req2_c1_23,
          prev_data_in_req3_c1_23,
          prev_data_in_req1_c2_01,
          prev_data_in_req2_c2_01,
          prev_data_in_req3_c2_01,
          prev_data_in_req1_c2_23,
          prev_data_in_req2_c2_23,
          prev_data_in_req3_c2_23,
          prev_data_in_req1_c3_01,
          prev_data_in_req2_c3_01,
          prev_data_in_req3_c3_01,
          prev_data_in_req1_c3_23,
          prev_data_in_req2_c3_23,
          prev_data_in_req3_c3_23,
          prev_data_in_req1_r0,
          prev_data_in_req2_r0,
          prev_data_in_req1_r1,
          prev_data_in_req2_r1,
          prev_data_in_req1_r2,
          prev_data_in_req2_r2,
          prev_data_in_req1_r3,
          prev_data_in_req2_r3,
          prev_data_in_req1_c0,
          prev_data_in_req2_c0,
          prev_data_in_req1_c1,
          prev_data_in_req2_c1,
          prev_data_in_req1_c2,
          prev_data_in_req2_c2,
          prev_data_in_req1_c3,
          prev_data_in_req2_c3,
          prev_data_in_req_NI1_00,
          prev_data_in_req_NI2_00,
          prev_data_in_req_NI1_01,
          prev_data_in_req_NI2_01,
          prev_data_in_req_NI1_02,
          prev_data_in_req_NI2_02,
          prev_data_in_req_NI1_03,
          prev_data_in_req_NI2_03,
          prev_data_in_req_NI1_10,
          prev_data_in_req_NI2_10,
          prev_data_in_req_NI1_11,
          prev_data_in_req_NI2_11,
          prev_data_in_req_NI1_12,
          prev_data_in_req_NI2_12,
          prev_data_in_req_NI1_13,
          prev_data_in_req_NI2_13,
          prev_data_in_req_NI1_20,
          prev_data_in_req_NI2_20,
          prev_data_in_req_NI1_21,
          prev_data_in_req_NI2_21,
          prev_data_in_req_NI1_22,
          prev_data_in_req_NI2_22,
          prev_data_in_req_NI1_23,
          prev_data_in_req_NI2_23,
          prev_data_in_req_NI1_30,
          prev_data_in_req_NI2_30,
          prev_data_in_req_NI1_31,
          prev_data_in_req_NI2_31,
          prev_data_in_req_NI1_32,
          prev_data_in_req_NI2_32,
          prev_data_in_req_NI1_33,
          prev_data_in_req_NI2_33;

    bool  prev_out_val1_00,
          prev_out_val2_00,
          prev_out_val3_00,
          prev_out_val4_00,
          prev_out_val1_01,
          prev_out_val2_01,
          prev_out_val3_01,
          prev_out_val4_01,
          prev_out_val1_02,
          prev_out_val2_02,
          prev_out_val3_02,
          prev_out_val4_02,
          prev_out_val1_03,
          prev_out_val2_03,
          prev_out_val3_03,
          prev_out_val4_03,
          prev_out_val1_10,
          prev_out_val2_10,
          prev_out_val3_10,
          prev_out_val4_10,
          prev_out_val1_11,
          prev_out_val2_11,
          prev_out_val3_11,
          prev_out_val4_11,
          prev_out_val1_12,
          prev_out_val2_12,
          prev_out_val3_12,
          prev_out_val4_12,
          prev_out_val1_13,
          prev_out_val2_13,
          prev_out_val3_13,
          prev_out_val4_13,
          prev_out_val1_20,
          prev_out_val2_20,
          prev_out_val3_20,
          prev_out_val4_20,
          prev_out_val1_21,
          prev_out_val2_21,
          prev_out_val3_21,
          prev_out_val4_21,
          prev_out_val1_22,
          prev_out_val2_22,
          prev_out_val3_22,
          prev_out_val4_22,
          prev_out_val1_23,
          prev_out_val2_23,
          prev_out_val3_23,
          prev_out_val4_23,
          prev_out_val1_30,
          prev_out_val2_30,
          prev_out_val3_30,
          prev_out_val4_30,
          prev_out_val1_31,
          prev_out_val2_31,
          prev_out_val3_31,
          prev_out_val4_31,
          prev_out_val1_32,
          prev_out_val2_32,
          prev_out_val3_32,
          prev_out_val4_32,
          prev_out_val1_33,
          prev_out_val2_33,
          prev_out_val3_33,
          prev_out_val4_33,
          prev_out_val1_r0_01,
          prev_out_val2_r0_01,
          prev_out_val3_r0_01,
          prev_out_val1_r0_23,
          prev_out_val2_r0_23,
          prev_out_val3_r0_23,
          prev_out_val1_r1_01,
          prev_out_val2_r1_01,
          prev_out_val3_r1_01,
          prev_out_val1_r1_23,
          prev_out_val2_r1_23,
          prev_out_val3_r1_23,
          prev_out_val1_r2_01,
          prev_out_val2_r2_01,
          prev_out_val3_r2_01,
          prev_out_val1_r2_23,
          prev_out_val2_r2_23,
          prev_out_val3_r2_23,
          prev_out_val1_r3_01,
          prev_out_val2_r3_01,
          prev_out_val3_r3_01,
          prev_out_val1_r3_23,
          prev_out_val2_r3_23,
          prev_out_val3_r3_23,
          prev_out_val1_c0_01,
          prev_out_val2_c0_01,
          prev_out_val3_c0_01,
          prev_out_val1_c0_23,
          prev_out_val2_c0_23,
          prev_out_val3_c0_23,
          prev_out_val1_c1_01,
          prev_out_val2_c1_01,
          prev_out_val3_c1_01,
          prev_out_val1_c1_23,
          prev_out_val2_c1_23,
          prev_out_val3_c1_23,
          prev_out_val1_c2_01,
          prev_out_val2_c2_01,
          prev_out_val3_c2_01,
          prev_out_val1_c2_23,
          prev_out_val2_c2_23,
          prev_out_val3_c2_23,
          prev_out_val1_c3_01,
          prev_out_val2_c3_01,
          prev_out_val3_c3_01,
          prev_out_val1_c3_23,
          prev_out_val2_c3_23,
          prev_out_val3_c3_23,
          prev_out_val1_r0,
          prev_out_val2_r0,
          prev_out_val1_r1,
          prev_out_val2_r1,
          prev_out_val1_r2,
          prev_out_val2_r2,
          prev_out_val1_r3,
          prev_out_val2_r3,
          prev_out_val1_c0,
          prev_out_val2_c0,
          prev_out_val1_c1,
          prev_out_val2_c1,
          prev_out_val1_c2,
          prev_out_val2_c2,
          prev_out_val1_c3,
          prev_out_val2_c3,
          prev_data_valid1_00,
          prev_data_valid2_00,
          prev_data_valid1_01,
          prev_data_valid2_01,
          prev_data_valid1_02,
          prev_data_valid2_02,
          prev_data_valid1_03,
          prev_data_valid2_03,
          prev_data_valid1_10,
          prev_data_valid2_10,
          prev_data_valid1_11,
          prev_data_valid2_11,
          prev_data_valid1_12,
          prev_data_valid2_12,
          prev_data_valid1_13,
          prev_data_valid2_13,
          prev_data_valid1_20,
          prev_data_valid2_20,
          prev_data_valid1_21,
          prev_data_valid2_21,
          prev_data_valid1_22,
          prev_data_valid2_22,
          prev_data_valid1_23,
          prev_data_valid2_23,
          prev_data_valid1_30,
          prev_data_valid2_30,
          prev_data_valid1_31,
          prev_data_valid2_31,
          prev_data_valid1_32,
          prev_data_valid2_32,
          prev_data_valid1_33,
          prev_data_valid2_33;

    int sp_router_out1_00[64],
        sp_router_out2_00[64],
        sp_router_out3_00[64],
        sp_router_out4_00[64],
        sp_router_out1_01[64],
        sp_router_out2_01[64],
        sp_router_out3_01[64],
        sp_router_out4_01[64],
        sp_router_out1_02[64],
        sp_router_out2_02[64],
        sp_router_out3_02[64],
        sp_router_out4_02[64],
        sp_router_out1_03[64],
        sp_router_out2_03[64],
        sp_router_out3_03[64],
        sp_router_out4_03[64],
        sp_router_out1_10[64],
        sp_router_out2_10[64],
        sp_router_out3_10[64],
        sp_router_out4_10[64],
        sp_router_out1_11[64],
        sp_router_out2_11[64],
        sp_router_out3_11[64],
        sp_router_out4_11[64],
        sp_router_out1_12[64],
        sp_router_out2_12[64],
        sp_router_out3_12[64],
        sp_router_out4_12[64],
        sp_router_out1_13[64],
        sp_router_out2_13[64],
        sp_router_out3_13[64],
        sp_router_out4_13[64],
        sp_router_out1_20[64],
        sp_router_out2_20[64],
        sp_router_out3_20[64],
        sp_router_out4_20[64],
        sp_router_out1_21[64],
        sp_router_out2_21[64],
        sp_router_out3_21[64],
        sp_router_out4_21[64],
        sp_router_out1_22[64],
        sp_router_out2_22[64],
        sp_router_out3_22[64],
        sp_router_out4_22[64],
        sp_router_out1_23[64],
        sp_router_out2_23[64],
        sp_router_out3_23[64],
        sp_router_out4_23[64],
        sp_router_out1_30[64],
        sp_router_out2_30[64],
        sp_router_out3_30[64],
        sp_router_out4_30[64],
        sp_router_out1_31[64],
        sp_router_out2_31[64],
        sp_router_out3_31[64],
        sp_router_out4_31[64],
        sp_router_out1_32[64],
        sp_router_out2_32[64],
        sp_router_out3_32[64],
        sp_router_out4_32[64],
        sp_router_out1_33[64],
        sp_router_out2_33[64],
        sp_router_out3_33[64],
        sp_router_out4_33[64],
        sp_router_out1_r0_01[64],
        sp_router_out2_r0_01[64],
        sp_router_out3_r0_01[64],
        sp_router_out1_r0_23[64],
        sp_router_out2_r0_23[64],
        sp_router_out3_r0_23[64],
        sp_router_out1_r1_01[64],
        sp_router_out2_r1_01[64],
        sp_router_out3_r1_01[64],
        sp_router_out1_r1_23[64],
        sp_router_out2_r1_23[64],
        sp_router_out3_r1_23[64],
        sp_router_out1_r2_01[64],
        sp_router_out2_r2_01[64],
        sp_router_out3_r2_01[64],
        sp_router_out1_r2_23[64],
        sp_router_out2_r2_23[64],
        sp_router_out3_r2_23[64],
        sp_router_out1_r3_01[64],
        sp_router_out2_r3_01[64],
        sp_router_out3_r3_01[64],
        sp_router_out1_r3_23[64],
        sp_router_out2_r3_23[64],
        sp_router_out3_r3_23[64],
        sp_router_out1_c0_01[64],
        sp_router_out2_c0_01[64],
        sp_router_out3_c0_01[64],
        sp_router_out1_c0_23[64],
        sp_router_out2_c0_23[64],
        sp_router_out3_c0_23[64],
        sp_router_out1_c1_01[64],
        sp_router_out2_c1_01[64],
        sp_router_out3_c1_01[64],
        sp_router_out1_c1_23[64],
        sp_router_out2_c1_23[64],
        sp_router_out3_c1_23[64],
        sp_router_out1_c2_01[64],
        sp_router_out2_c2_01[64],
        sp_router_out3_c2_01[64],
        sp_router_out1_c2_23[64],
        sp_router_out2_c2_23[64],
        sp_router_out3_c2_23[64],
        sp_router_out1_c3_01[64],
        sp_router_out2_c3_01[64],
        sp_router_out3_c3_01[64],
        sp_router_out1_c3_23[64],
        sp_router_out2_c3_23[64],
        sp_router_out3_c3_23[64],
        sp_data_out1_r0[64],
        sp_data_out2_r0[64],
        sp_data_out1_r1[64],
        sp_data_out2_r1[64],
        sp_data_out1_r2[64],
        sp_data_out2_r2[64],
        sp_data_out1_r3[64],
        sp_data_out2_r3[64],
        sp_data_out1_c0[64],
        sp_data_out2_c0[64],
        sp_data_out1_c1[64],
        sp_data_out2_c1[64],
        sp_data_out1_c2[64],
        sp_data_out2_c2[64],
        sp_data_out1_c3[64],
        sp_data_out2_c3[64],
        sp_packet_out1_00[64],
        sp_packet_out2_00[64],
        sp_packet_out1_01[64],
        sp_packet_out2_01[64],
        sp_packet_out1_02[64],
        sp_packet_out2_02[64],
        sp_packet_out1_03[64],
        sp_packet_out2_03[64],
        sp_packet_out1_10[64],
        sp_packet_out2_10[64],
        sp_packet_out1_11[64],
        sp_packet_out2_11[64],
        sp_packet_out1_12[64],
        sp_packet_out2_12[64],
        sp_packet_out1_13[64],
        sp_packet_out2_13[64],
        sp_packet_out1_20[64],
        sp_packet_out2_20[64],
        sp_packet_out1_21[64],
        sp_packet_out2_21[64],
        sp_packet_out1_22[64],
        sp_packet_out2_22[64],
        sp_packet_out1_23[64],
        sp_packet_out2_23[64],
        sp_packet_out1_30[64],
        sp_packet_out2_30[64],
        sp_packet_out1_31[64],
        sp_packet_out2_31[64],
        sp_packet_out1_32[64],
        sp_packet_out2_32[64],
        sp_packet_out1_33[64],
        sp_packet_out2_33[64];

    int sp_data_in_req1_00,
        sp_data_in_req2_00,
        sp_data_in_req3_00,
        sp_data_in_req4_00,
        sp_data_in_req1_01,
        sp_data_in_req2_01,
        sp_data_in_req3_01,
        sp_data_in_req4_01,
        sp_data_in_req1_02,
        sp_data_in_req2_02,
        sp_data_in_req3_02,
        sp_data_in_req4_02,
        sp_data_in_req1_03,
        sp_data_in_req2_03,
        sp_data_in_req3_03,
        sp_data_in_req4_03,
        sp_data_in_req1_10,
        sp_data_in_req2_10,
        sp_data_in_req3_10,
        sp_data_in_req4_10,
        sp_data_in_req1_11,
        sp_data_in_req2_11,
        sp_data_in_req3_11,
        sp_data_in_req4_11,
        sp_data_in_req1_12,
        sp_data_in_req2_12,
        sp_data_in_req3_12,
        sp_data_in_req4_12,
        sp_data_in_req1_13,
        sp_data_in_req2_13,
        sp_data_in_req3_13,
        sp_data_in_req4_13,
        sp_data_in_req1_20,
        sp_data_in_req2_20,
        sp_data_in_req3_20,
        sp_data_in_req4_20,
        sp_data_in_req1_21,
        sp_data_in_req2_21,
        sp_data_in_req3_21,
        sp_data_in_req4_21,
        sp_data_in_req1_22,
        sp_data_in_req2_22,
        sp_data_in_req3_22,
        sp_data_in_req4_22,
        sp_data_in_req1_23,
        sp_data_in_req2_23,
        sp_data_in_req3_23,
        sp_data_in_req4_23,
        sp_data_in_req1_30,
        sp_data_in_req2_30,
        sp_data_in_req3_30,
        sp_data_in_req4_30,
        sp_data_in_req1_31,
        sp_data_in_req2_31,
        sp_data_in_req3_31,
        sp_data_in_req4_31,
        sp_data_in_req1_32,
        sp_data_in_req2_32,
        sp_data_in_req3_32,
        sp_data_in_req4_32,
        sp_data_in_req1_33,
        sp_data_in_req2_33,
        sp_data_in_req3_33,
        sp_data_in_req4_33,
        sp_data_in_req1_r0_01,
        sp_data_in_req2_r0_01,
        sp_data_in_req3_r0_01,
        sp_data_in_req1_r0_23,
        sp_data_in_req2_r0_23,
        sp_data_in_req3_r0_23,
        sp_data_in_req1_r1_01,
        sp_data_in_req2_r1_01,
        sp_data_in_req3_r1_01,
        sp_data_in_req1_r1_23,
        sp_data_in_req2_r1_23,
        sp_data_in_req3_r1_23,
        sp_data_in_req1_r2_01,
        sp_data_in_req2_r2_01,
        sp_data_in_req3_r2_01,
        sp_data_in_req1_r2_23,
        sp_data_in_req2_r2_23,
        sp_data_in_req3_r2_23,
        sp_data_in_req1_r3_01,
        sp_data_in_req2_r3_01,
        sp_data_in_req3_r3_01,
        sp_data_in_req1_r3_23,
        sp_data_in_req2_r3_23,
        sp_data_in_req3_r3_23,
        sp_data_in_req1_c0_01,
        sp_data_in_req2_c0_01,
        sp_data_in_req3_c0_01,
        sp_data_in_req1_c0_23,
        sp_data_in_req2_c0_23,
        sp_data_in_req3_c0_23,
        sp_data_in_req1_c1_01,
        sp_data_in_req2_c1_01,
        sp_data_in_req3_c1_01,
        sp_data_in_req1_c1_23,
        sp_data_in_req2_c1_23,
        sp_data_in_req3_c1_23,
        sp_data_in_req1_c2_01,
        sp_data_in_req2_c2_01,
        sp_data_in_req3_c2_01,
        sp_data_in_req1_c2_23,
        sp_data_in_req2_c2_23,
        sp_data_in_req3_c2_23,
        sp_data_in_req1_c3_01,
        sp_data_in_req2_c3_01,
        sp_data_in_req3_c3_01,
        sp_data_in_req1_c3_23,
        sp_data_in_req2_c3_23,
        sp_data_in_req3_c3_23,
        sp_data_in_req1_r0,
        sp_data_in_req2_r0,
        sp_data_in_req1_r1,
        sp_data_in_req2_r1,
        sp_data_in_req1_r2,
        sp_data_in_req2_r2,
        sp_data_in_req1_r3,
        sp_data_in_req2_r3,
        sp_data_in_req1_c0,
        sp_data_in_req2_c0,
        sp_data_in_req1_c1,
        sp_data_in_req2_c1,
        sp_data_in_req1_c2,
        sp_data_in_req2_c2,
        sp_data_in_req1_c3,
        sp_data_in_req2_c3,
        sp_data_in_req_NI1_00,
        sp_data_in_req_NI2_00,
        sp_data_in_req_NI1_01,
        sp_data_in_req_NI2_01,
        sp_data_in_req_NI1_02,
        sp_data_in_req_NI2_02,
        sp_data_in_req_NI1_03,
        sp_data_in_req_NI2_03,
        sp_data_in_req_NI1_10,
        sp_data_in_req_NI2_10,
        sp_data_in_req_NI1_11,
        sp_data_in_req_NI2_11,
        sp_data_in_req_NI1_12,
        sp_data_in_req_NI2_12,
        sp_data_in_req_NI1_13,
        sp_data_in_req_NI2_13,
        sp_data_in_req_NI1_20,
        sp_data_in_req_NI2_20,
        sp_data_in_req_NI1_21,
        sp_data_in_req_NI2_21,
        sp_data_in_req_NI1_22,
        sp_data_in_req_NI2_22,
        sp_data_in_req_NI1_23,
        sp_data_in_req_NI2_23,
        sp_data_in_req_NI1_30,
        sp_data_in_req_NI2_30,
        sp_data_in_req_NI1_31,
        sp_data_in_req_NI2_31,
        sp_data_in_req_NI1_32,
        sp_data_in_req_NI2_32,
        sp_data_in_req_NI1_33,
        sp_data_in_req_NI2_33;

    int sp_out_val1_00,
        sp_out_val2_00,
        sp_out_val3_00,
        sp_out_val4_00,
        sp_out_val1_01,
        sp_out_val2_01,
        sp_out_val3_01,
        sp_out_val4_01,
        sp_out_val1_02,
        sp_out_val2_02,
        sp_out_val3_02,
        sp_out_val4_02,
        sp_out_val1_03,
        sp_out_val2_03,
        sp_out_val3_03,
        sp_out_val4_03,
        sp_out_val1_10,
        sp_out_val2_10,
        sp_out_val3_10,
        sp_out_val4_10,
        sp_out_val1_11,
        sp_out_val2_11,
        sp_out_val3_11,
        sp_out_val4_11,
        sp_out_val1_12,
        sp_out_val2_12,
        sp_out_val3_12,
        sp_out_val4_12,
        sp_out_val1_13,
        sp_out_val2_13,
        sp_out_val3_13,
        sp_out_val4_13,
        sp_out_val1_20,
        sp_out_val2_20,
        sp_out_val3_20,
        sp_out_val4_20,
        sp_out_val1_21,
        sp_out_val2_21,
        sp_out_val3_21,
        sp_out_val4_21,
        sp_out_val1_22,
        sp_out_val2_22,
        sp_out_val3_22,
        sp_out_val4_22,
        sp_out_val1_23,
        sp_out_val2_23,
        sp_out_val3_23,
        sp_out_val4_23,
        sp_out_val1_30,
        sp_out_val2_30,
        sp_out_val3_30,
        sp_out_val4_30,
        sp_out_val1_31,
        sp_out_val2_31,
        sp_out_val3_31,
        sp_out_val4_31,
        sp_out_val1_32,
        sp_out_val2_32,
        sp_out_val3_32,
        sp_out_val4_32,
        sp_out_val1_33,
        sp_out_val2_33,
        sp_out_val3_33,
        sp_out_val4_33,
        sp_out_val1_r0_01,
        sp_out_val2_r0_01,
        sp_out_val3_r0_01,
        sp_out_val1_r0_23,
        sp_out_val2_r0_23,
        sp_out_val3_r0_23,
        sp_out_val1_r1_01,
        sp_out_val2_r1_01,
        sp_out_val3_r1_01,
        sp_out_val1_r1_23,
        sp_out_val2_r1_23,
        sp_out_val3_r1_23,
        sp_out_val1_r2_01,
        sp_out_val2_r2_01,
        sp_out_val3_r2_01,
        sp_out_val1_r2_23,
        sp_out_val2_r2_23,
        sp_out_val3_r2_23,
        sp_out_val1_r3_01,
        sp_out_val2_r3_01,
        sp_out_val3_r3_01,
        sp_out_val1_r3_23,
        sp_out_val2_r3_23,
        sp_out_val3_r3_23,
        sp_out_val1_c0_01,
        sp_out_val2_c0_01,
        sp_out_val3_c0_01,
        sp_out_val1_c0_23,
        sp_out_val2_c0_23,
        sp_out_val3_c0_23,
        sp_out_val1_c1_01,
        sp_out_val2_c1_01,
        sp_out_val3_c1_01,
        sp_out_val1_c1_23,
        sp_out_val2_c1_23,
        sp_out_val3_c1_23,
        sp_out_val1_c2_01,
        sp_out_val2_c2_01,
        sp_out_val3_c2_01,
        sp_out_val1_c2_23,
        sp_out_val2_c2_23,
        sp_out_val3_c2_23,
        sp_out_val1_c3_01,
        sp_out_val2_c3_01,
        sp_out_val3_c3_01,
        sp_out_val1_c3_23,
        sp_out_val2_c3_23,
        sp_out_val3_c3_23,
        sp_out_val1_r0,
        sp_out_val2_r0,
        sp_out_val1_r1,
        sp_out_val2_r1,
        sp_out_val1_r2,
        sp_out_val2_r2,
        sp_out_val1_r3,
        sp_out_val2_r3,
        sp_out_val1_c0,
        sp_out_val2_c0,
        sp_out_val1_c1,
        sp_out_val2_c1,
        sp_out_val1_c2,
        sp_out_val2_c2,
        sp_out_val1_c3,
        sp_out_val2_c3,
        sp_data_valid1_00,
        sp_data_valid2_00,
        sp_data_valid1_01,
        sp_data_valid2_01,
        sp_data_valid1_02,
        sp_data_valid2_02,
        sp_data_valid1_03,
        sp_data_valid2_03,
        sp_data_valid1_10,
        sp_data_valid2_10,
        sp_data_valid1_11,
        sp_data_valid2_11,
        sp_data_valid1_12,
        sp_data_valid2_12,
        sp_data_valid1_13,
        sp_data_valid2_13,
        sp_data_valid1_20,
        sp_data_valid2_20,
        sp_data_valid1_21,
        sp_data_valid2_21,
        sp_data_valid1_22,
        sp_data_valid2_22,
        sp_data_valid1_23,
        sp_data_valid2_23,
        sp_data_valid1_30,
        sp_data_valid2_30,
        sp_data_valid1_31,
        sp_data_valid2_31,
        sp_data_valid1_32,
        sp_data_valid2_32,
        sp_data_valid1_33,
        sp_data_valid2_33;

    int pb1_router_out1_00[64],
        pb1_router_out2_00[64],
        pb1_router_out3_00[64],
        pb1_router_out4_00[64],
        pb1_router_out1_01[64],
        pb1_router_out2_01[64],
        pb1_router_out3_01[64],
        pb1_router_out4_01[64],
        pb1_router_out1_02[64],
        pb1_router_out2_02[64],
        pb1_router_out3_02[64],
        pb1_router_out4_02[64],
        pb1_router_out1_03[64],
        pb1_router_out2_03[64],
        pb1_router_out3_03[64],
        pb1_router_out4_03[64],
        pb1_router_out1_10[64],
        pb1_router_out2_10[64],
        pb1_router_out3_10[64],
        pb1_router_out4_10[64],
        pb1_router_out1_11[64],
        pb1_router_out2_11[64],
        pb1_router_out3_11[64],
        pb1_router_out4_11[64],
        pb1_router_out1_12[64],
        pb1_router_out2_12[64],
        pb1_router_out3_12[64],
        pb1_router_out4_12[64],
        pb1_router_out1_13[64],
        pb1_router_out2_13[64],
        pb1_router_out3_13[64],
        pb1_router_out4_13[64],
        pb1_router_out1_20[64],
        pb1_router_out2_20[64],
        pb1_router_out3_20[64],
        pb1_router_out4_20[64],
        pb1_router_out1_21[64],
        pb1_router_out2_21[64],
        pb1_router_out3_21[64],
        pb1_router_out4_21[64],
        pb1_router_out1_22[64],
        pb1_router_out2_22[64],
        pb1_router_out3_22[64],
        pb1_router_out4_22[64],
        pb1_router_out1_23[64],
        pb1_router_out2_23[64],
        pb1_router_out3_23[64],
        pb1_router_out4_23[64],
        pb1_router_out1_30[64],
        pb1_router_out2_30[64],
        pb1_router_out3_30[64],
        pb1_router_out4_30[64],
        pb1_router_out1_31[64],
        pb1_router_out2_31[64],
        pb1_router_out3_31[64],
        pb1_router_out4_31[64],
        pb1_router_out1_32[64],
        pb1_router_out2_32[64],
        pb1_router_out3_32[64],
        pb1_router_out4_32[64],
        pb1_router_out1_33[64],
        pb1_router_out2_33[64],
        pb1_router_out3_33[64],
        pb1_router_out4_33[64],
        pb1_router_out1_r0_01[64],
        pb1_router_out2_r0_01[64],
        pb1_router_out3_r0_01[64],
        pb1_router_out1_r0_23[64],
        pb1_router_out2_r0_23[64],
        pb1_router_out3_r0_23[64],
        pb1_router_out1_r1_01[64],
        pb1_router_out2_r1_01[64],
        pb1_router_out3_r1_01[64],
        pb1_router_out1_r1_23[64],
        pb1_router_out2_r1_23[64],
        pb1_router_out3_r1_23[64],
        pb1_router_out1_r2_01[64],
        pb1_router_out2_r2_01[64],
        pb1_router_out3_r2_01[64],
        pb1_router_out1_r2_23[64],
        pb1_router_out2_r2_23[64],
        pb1_router_out3_r2_23[64],
        pb1_router_out1_r3_01[64],
        pb1_router_out2_r3_01[64],
        pb1_router_out3_r3_01[64],
        pb1_router_out1_r3_23[64],
        pb1_router_out2_r3_23[64],
        pb1_router_out3_r3_23[64],
        pb1_router_out1_c0_01[64],
        pb1_router_out2_c0_01[64],
        pb1_router_out3_c0_01[64],
        pb1_router_out1_c0_23[64],
        pb1_router_out2_c0_23[64],
        pb1_router_out3_c0_23[64],
        pb1_router_out1_c1_01[64],
        pb1_router_out2_c1_01[64],
        pb1_router_out3_c1_01[64],
        pb1_router_out1_c1_23[64],
        pb1_router_out2_c1_23[64],
        pb1_router_out3_c1_23[64],
        pb1_router_out1_c2_01[64],
        pb1_router_out2_c2_01[64],
        pb1_router_out3_c2_01[64],
        pb1_router_out1_c2_23[64],
        pb1_router_out2_c2_23[64],
        pb1_router_out3_c2_23[64],
        pb1_router_out1_c3_01[64],
        pb1_router_out2_c3_01[64],
        pb1_router_out3_c3_01[64],
        pb1_router_out1_c3_23[64],
        pb1_router_out2_c3_23[64],
        pb1_router_out3_c3_23[64],
        pb1_data_out1_r0[64],
        pb1_data_out2_r0[64],
        pb1_data_out1_r1[64],
        pb1_data_out2_r1[64],
        pb1_data_out1_r2[64],
        pb1_data_out2_r2[64],
        pb1_data_out1_r3[64],
        pb1_data_out2_r3[64],
        pb1_data_out1_c0[64],
        pb1_data_out2_c0[64],
        pb1_data_out1_c1[64],
        pb1_data_out2_c1[64],
        pb1_data_out1_c2[64],
        pb1_data_out2_c2[64],
        pb1_data_out1_c3[64],
        pb1_data_out2_c3[64],
        pb1_packet_out1_00[64],
        pb1_packet_out2_00[64],
        pb1_packet_out1_01[64],
        pb1_packet_out2_01[64],
        pb1_packet_out1_02[64],
        pb1_packet_out2_02[64],
        pb1_packet_out1_03[64],
        pb1_packet_out2_03[64],
        pb1_packet_out1_10[64],
        pb1_packet_out2_10[64],
        pb1_packet_out1_11[64],
        pb1_packet_out2_11[64],
        pb1_packet_out1_12[64],
        pb1_packet_out2_12[64],
        pb1_packet_out1_13[64],
        pb1_packet_out2_13[64],
        pb1_packet_out1_20[64],
        pb1_packet_out2_20[64],
        pb1_packet_out1_21[64],
        pb1_packet_out2_21[64],
        pb1_packet_out1_22[64],
        pb1_packet_out2_22[64],
        pb1_packet_out1_23[64],
        pb1_packet_out2_23[64],
        pb1_packet_out1_30[64],
        pb1_packet_out2_30[64],
        pb1_packet_out1_31[64],
        pb1_packet_out2_31[64],
        pb1_packet_out1_32[64],
        pb1_packet_out2_32[64],
        pb1_packet_out1_33[64],
        pb1_packet_out2_33[64];

    int pb1_data_in_req1_00,
        pb1_data_in_req2_00,
        pb1_data_in_req3_00,
        pb1_data_in_req4_00,
        pb1_data_in_req1_01,
        pb1_data_in_req2_01,
        pb1_data_in_req3_01,
        pb1_data_in_req4_01,
        pb1_data_in_req1_02,
        pb1_data_in_req2_02,
        pb1_data_in_req3_02,
        pb1_data_in_req4_02,
        pb1_data_in_req1_03,
        pb1_data_in_req2_03,
        pb1_data_in_req3_03,
        pb1_data_in_req4_03,
        pb1_data_in_req1_10,
        pb1_data_in_req2_10,
        pb1_data_in_req3_10,
        pb1_data_in_req4_10,
        pb1_data_in_req1_11,
        pb1_data_in_req2_11,
        pb1_data_in_req3_11,
        pb1_data_in_req4_11,
        pb1_data_in_req1_12,
        pb1_data_in_req2_12,
        pb1_data_in_req3_12,
        pb1_data_in_req4_12,
        pb1_data_in_req1_13,
        pb1_data_in_req2_13,
        pb1_data_in_req3_13,
        pb1_data_in_req4_13,
        pb1_data_in_req1_20,
        pb1_data_in_req2_20,
        pb1_data_in_req3_20,
        pb1_data_in_req4_20,
        pb1_data_in_req1_21,
        pb1_data_in_req2_21,
        pb1_data_in_req3_21,
        pb1_data_in_req4_21,
        pb1_data_in_req1_22,
        pb1_data_in_req2_22,
        pb1_data_in_req3_22,
        pb1_data_in_req4_22,
        pb1_data_in_req1_23,
        pb1_data_in_req2_23,
        pb1_data_in_req3_23,
        pb1_data_in_req4_23,
        pb1_data_in_req1_30,
        pb1_data_in_req2_30,
        pb1_data_in_req3_30,
        pb1_data_in_req4_30,
        pb1_data_in_req1_31,
        pb1_data_in_req2_31,
        pb1_data_in_req3_31,
        pb1_data_in_req4_31,
        pb1_data_in_req1_32,
        pb1_data_in_req2_32,
        pb1_data_in_req3_32,
        pb1_data_in_req4_32,
        pb1_data_in_req1_33,
        pb1_data_in_req2_33,
        pb1_data_in_req3_33,
        pb1_data_in_req4_33,
        pb1_data_in_req1_r0_01,
        pb1_data_in_req2_r0_01,
        pb1_data_in_req3_r0_01,
        pb1_data_in_req1_r0_23,
        pb1_data_in_req2_r0_23,
        pb1_data_in_req3_r0_23,
        pb1_data_in_req1_r1_01,
        pb1_data_in_req2_r1_01,
        pb1_data_in_req3_r1_01,
        pb1_data_in_req1_r1_23,
        pb1_data_in_req2_r1_23,
        pb1_data_in_req3_r1_23,
        pb1_data_in_req1_r2_01,
        pb1_data_in_req2_r2_01,
        pb1_data_in_req3_r2_01,
        pb1_data_in_req1_r2_23,
        pb1_data_in_req2_r2_23,
        pb1_data_in_req3_r2_23,
        pb1_data_in_req1_r3_01,
        pb1_data_in_req2_r3_01,
        pb1_data_in_req3_r3_01,
        pb1_data_in_req1_r3_23,
        pb1_data_in_req2_r3_23,
        pb1_data_in_req3_r3_23,
        pb1_data_in_req1_c0_01,
        pb1_data_in_req2_c0_01,
        pb1_data_in_req3_c0_01,
        pb1_data_in_req1_c0_23,
        pb1_data_in_req2_c0_23,
        pb1_data_in_req3_c0_23,
        pb1_data_in_req1_c1_01,
        pb1_data_in_req2_c1_01,
        pb1_data_in_req3_c1_01,
        pb1_data_in_req1_c1_23,
        pb1_data_in_req2_c1_23,
        pb1_data_in_req3_c1_23,
        pb1_data_in_req1_c2_01,
        pb1_data_in_req2_c2_01,
        pb1_data_in_req3_c2_01,
        pb1_data_in_req1_c2_23,
        pb1_data_in_req2_c2_23,
        pb1_data_in_req3_c2_23,
        pb1_data_in_req1_c3_01,
        pb1_data_in_req2_c3_01,
        pb1_data_in_req3_c3_01,
        pb1_data_in_req1_c3_23,
        pb1_data_in_req2_c3_23,
        pb1_data_in_req3_c3_23,
        pb1_data_in_req1_r0,
        pb1_data_in_req2_r0,
        pb1_data_in_req1_r1,
        pb1_data_in_req2_r1,
        pb1_data_in_req1_r2,
        pb1_data_in_req2_r2,
        pb1_data_in_req1_r3,
        pb1_data_in_req2_r3,
        pb1_data_in_req1_c0,
        pb1_data_in_req2_c0,
        pb1_data_in_req1_c1,
        pb1_data_in_req2_c1,
        pb1_data_in_req1_c2,
        pb1_data_in_req2_c2,
        pb1_data_in_req1_c3,
        pb1_data_in_req2_c3,
        pb1_data_in_req_NI1_00,
        pb1_data_in_req_NI2_00,
        pb1_data_in_req_NI1_01,
        pb1_data_in_req_NI2_01,
        pb1_data_in_req_NI1_02,
        pb1_data_in_req_NI2_02,
        pb1_data_in_req_NI1_03,
        pb1_data_in_req_NI2_03,
        pb1_data_in_req_NI1_10,
        pb1_data_in_req_NI2_10,
        pb1_data_in_req_NI1_11,
        pb1_data_in_req_NI2_11,
        pb1_data_in_req_NI1_12,
        pb1_data_in_req_NI2_12,
        pb1_data_in_req_NI1_13,
        pb1_data_in_req_NI2_13,
        pb1_data_in_req_NI1_20,
        pb1_data_in_req_NI2_20,
        pb1_data_in_req_NI1_21,
        pb1_data_in_req_NI2_21,
        pb1_data_in_req_NI1_22,
        pb1_data_in_req_NI2_22,
        pb1_data_in_req_NI1_23,
        pb1_data_in_req_NI2_23,
        pb1_data_in_req_NI1_30,
        pb1_data_in_req_NI2_30,
        pb1_data_in_req_NI1_31,
        pb1_data_in_req_NI2_31,
        pb1_data_in_req_NI1_32,
        pb1_data_in_req_NI2_32,
        pb1_data_in_req_NI1_33,
        pb1_data_in_req_NI2_33;

    int pb1_out_val1_00,
        pb1_out_val2_00,
        pb1_out_val3_00,
        pb1_out_val4_00,
        pb1_out_val1_01,
        pb1_out_val2_01,
        pb1_out_val3_01,
        pb1_out_val4_01,
        pb1_out_val1_02,
        pb1_out_val2_02,
        pb1_out_val3_02,
        pb1_out_val4_02,
        pb1_out_val1_03,
        pb1_out_val2_03,
        pb1_out_val3_03,
        pb1_out_val4_03,
        pb1_out_val1_10,
        pb1_out_val2_10,
        pb1_out_val3_10,
        pb1_out_val4_10,
        pb1_out_val1_11,
        pb1_out_val2_11,
        pb1_out_val3_11,
        pb1_out_val4_11,
        pb1_out_val1_12,
        pb1_out_val2_12,
        pb1_out_val3_12,
        pb1_out_val4_12,
        pb1_out_val1_13,
        pb1_out_val2_13,
        pb1_out_val3_13,
        pb1_out_val4_13,
        pb1_out_val1_20,
        pb1_out_val2_20,
        pb1_out_val3_20,
        pb1_out_val4_20,
        pb1_out_val1_21,
        pb1_out_val2_21,
        pb1_out_val3_21,
        pb1_out_val4_21,
        pb1_out_val1_22,
        pb1_out_val2_22,
        pb1_out_val3_22,
        pb1_out_val4_22,
        pb1_out_val1_23,
        pb1_out_val2_23,
        pb1_out_val3_23,
        pb1_out_val4_23,
        pb1_out_val1_30,
        pb1_out_val2_30,
        pb1_out_val3_30,
        pb1_out_val4_30,
        pb1_out_val1_31,
        pb1_out_val2_31,
        pb1_out_val3_31,
        pb1_out_val4_31,
        pb1_out_val1_32,
        pb1_out_val2_32,
        pb1_out_val3_32,
        pb1_out_val4_32,
        pb1_out_val1_33,
        pb1_out_val2_33,
        pb1_out_val3_33,
        pb1_out_val4_33,
        pb1_out_val1_r0_01,
        pb1_out_val2_r0_01,
        pb1_out_val3_r0_01,
        pb1_out_val1_r0_23,
        pb1_out_val2_r0_23,
        pb1_out_val3_r0_23,
        pb1_out_val1_r1_01,
        pb1_out_val2_r1_01,
        pb1_out_val3_r1_01,
        pb1_out_val1_r1_23,
        pb1_out_val2_r1_23,
        pb1_out_val3_r1_23,
        pb1_out_val1_r2_01,
        pb1_out_val2_r2_01,
        pb1_out_val3_r2_01,
        pb1_out_val1_r2_23,
        pb1_out_val2_r2_23,
        pb1_out_val3_r2_23,
        pb1_out_val1_r3_01,
        pb1_out_val2_r3_01,
        pb1_out_val3_r3_01,
        pb1_out_val1_r3_23,
        pb1_out_val2_r3_23,
        pb1_out_val3_r3_23,
        pb1_out_val1_c0_01,
        pb1_out_val2_c0_01,
        pb1_out_val3_c0_01,
        pb1_out_val1_c0_23,
        pb1_out_val2_c0_23,
        pb1_out_val3_c0_23,
        pb1_out_val1_c1_01,
        pb1_out_val2_c1_01,
        pb1_out_val3_c1_01,
        pb1_out_val1_c1_23,
        pb1_out_val2_c1_23,
        pb1_out_val3_c1_23,
        pb1_out_val1_c2_01,
        pb1_out_val2_c2_01,
        pb1_out_val3_c2_01,
        pb1_out_val1_c2_23,
        pb1_out_val2_c2_23,
        pb1_out_val3_c2_23,
        pb1_out_val1_c3_01,
        pb1_out_val2_c3_01,
        pb1_out_val3_c3_01,
        pb1_out_val1_c3_23,
        pb1_out_val2_c3_23,
        pb1_out_val3_c3_23,
        pb1_out_val1_r0,
        pb1_out_val2_r0,
        pb1_out_val1_r1,
        pb1_out_val2_r1,
        pb1_out_val1_r2,
        pb1_out_val2_r2,
        pb1_out_val1_r3,
        pb1_out_val2_r3,
        pb1_out_val1_c0,
        pb1_out_val2_c0,
        pb1_out_val1_c1,
        pb1_out_val2_c1,
        pb1_out_val1_c2,
        pb1_out_val2_c2,
        pb1_out_val1_c3,
        pb1_out_val2_c3,
        pb1_data_valid1_00,
        pb1_data_valid2_00,
        pb1_data_valid1_01,
        pb1_data_valid2_01,
        pb1_data_valid1_02,
        pb1_data_valid2_02,
        pb1_data_valid1_03,
        pb1_data_valid2_03,
        pb1_data_valid1_10,
        pb1_data_valid2_10,
        pb1_data_valid1_11,
        pb1_data_valid2_11,
        pb1_data_valid1_12,
        pb1_data_valid2_12,
        pb1_data_valid1_13,
        pb1_data_valid2_13,
        pb1_data_valid1_20,
        pb1_data_valid2_20,
        pb1_data_valid1_21,
        pb1_data_valid2_21,
        pb1_data_valid1_22,
        pb1_data_valid2_22,
        pb1_data_valid1_23,
        pb1_data_valid2_23,
        pb1_data_valid1_30,
        pb1_data_valid2_30,
        pb1_data_valid1_31,
        pb1_data_valid2_31,
        pb1_data_valid1_32,
        pb1_data_valid2_32,
        pb1_data_valid1_33,
        pb1_data_valid2_33;

    float Lg_router_out1_00,
        Lg_router_out2_00,
        Lg_router_out3_00,
        Lg_router_out4_00,
        Lg_router_out1_01,
        Lg_router_out2_01,
        Lg_router_out3_01,
        Lg_router_out4_01,
        Lg_router_out1_02,
        Lg_router_out2_02,
        Lg_router_out3_02,
        Lg_router_out4_02,
        Lg_router_out1_03,
        Lg_router_out2_03,
        Lg_router_out3_03,
        Lg_router_out4_03,
        Lg_router_out1_10,
        Lg_router_out2_10,
        Lg_router_out3_10,
        Lg_router_out4_10,
        Lg_router_out1_11,
        Lg_router_out2_11,
        Lg_router_out3_11,
        Lg_router_out4_11,
        Lg_router_out1_12,
        Lg_router_out2_12,
        Lg_router_out3_12,
        Lg_router_out4_12,
        Lg_router_out1_13,
        Lg_router_out2_13,
        Lg_router_out3_13,
        Lg_router_out4_13,
        Lg_router_out1_20,
        Lg_router_out2_20,
        Lg_router_out3_20,
        Lg_router_out4_20,
        Lg_router_out1_21,
        Lg_router_out2_21,
        Lg_router_out3_21,
        Lg_router_out4_21,
        Lg_router_out1_22,
        Lg_router_out2_22,
        Lg_router_out3_22,
        Lg_router_out4_22,
        Lg_router_out1_23,
        Lg_router_out2_23,
        Lg_router_out3_23,
        Lg_router_out4_23,
        Lg_router_out1_30,
        Lg_router_out2_30,
        Lg_router_out3_30,
        Lg_router_out4_30,
        Lg_router_out1_31,
        Lg_router_out2_31,
        Lg_router_out3_31,
        Lg_router_out4_31,
        Lg_router_out1_32,
        Lg_router_out2_32,
        Lg_router_out3_32,
        Lg_router_out4_32,
        Lg_router_out1_33,
        Lg_router_out2_33,
        Lg_router_out3_33,
        Lg_router_out4_33,
        Lg_router_out1_r0_01,
        Lg_router_out2_r0_01,
        Lg_router_out3_r0_01,
        Lg_router_out1_r0_23,
        Lg_router_out2_r0_23,
        Lg_router_out3_r0_23,
        Lg_router_out1_r1_01,
        Lg_router_out2_r1_01,
        Lg_router_out3_r1_01,
        Lg_router_out1_r1_23,
        Lg_router_out2_r1_23,
        Lg_router_out3_r1_23,
        Lg_router_out1_r2_01,
        Lg_router_out2_r2_01,
        Lg_router_out3_r2_01,
        Lg_router_out1_r2_23,
        Lg_router_out2_r2_23,
        Lg_router_out3_r2_23,
        Lg_router_out1_r3_01,
        Lg_router_out2_r3_01,
        Lg_router_out3_r3_01,
        Lg_router_out1_r3_23,
        Lg_router_out2_r3_23,
        Lg_router_out3_r3_23,
        Lg_router_out1_c0_01,
        Lg_router_out2_c0_01,
        Lg_router_out3_c0_01,
        Lg_router_out1_c0_23,
        Lg_router_out2_c0_23,
        Lg_router_out3_c0_23,
        Lg_router_out1_c1_01,
        Lg_router_out2_c1_01,
        Lg_router_out3_c1_01,
        Lg_router_out1_c1_23,
        Lg_router_out2_c1_23,
        Lg_router_out3_c1_23,
        Lg_router_out1_c2_01,
        Lg_router_out2_c2_01,
        Lg_router_out3_c2_01,
        Lg_router_out1_c2_23,
        Lg_router_out2_c2_23,
        Lg_router_out3_c2_23,
        Lg_router_out1_c3_01,
        Lg_router_out2_c3_01,
        Lg_router_out3_c3_01,
        Lg_router_out1_c3_23,
        Lg_router_out2_c3_23,
        Lg_router_out3_c3_23,
        Lg_data_out1_r0,
        Lg_data_out2_r0,
        Lg_data_out1_r1,
        Lg_data_out2_r1,
        Lg_data_out1_r2,
        Lg_data_out2_r2,
        Lg_data_out1_r3,
        Lg_data_out2_r3,
        Lg_data_out1_c0,
        Lg_data_out2_c0,
        Lg_data_out1_c1,
        Lg_data_out2_c1,
        Lg_data_out1_c2,
        Lg_data_out2_c2,
        Lg_data_out1_c3,
        Lg_data_out2_c3,
        Lg_packet_out1_00,
        Lg_packet_out2_00,
        Lg_packet_out1_01,
        Lg_packet_out2_01,
        Lg_packet_out1_02,
        Lg_packet_out2_02,
        Lg_packet_out1_03,
        Lg_packet_out2_03,
        Lg_packet_out1_10,
        Lg_packet_out2_10,
        Lg_packet_out1_11,
        Lg_packet_out2_11,
        Lg_packet_out1_12,
        Lg_packet_out2_12,
        Lg_packet_out1_13,
        Lg_packet_out2_13,
        Lg_packet_out1_20,
        Lg_packet_out2_20,
        Lg_packet_out1_21,
        Lg_packet_out2_21,
        Lg_packet_out1_22,
        Lg_packet_out2_22,
        Lg_packet_out1_23,
        Lg_packet_out2_23,
        Lg_packet_out1_30,
        Lg_packet_out2_30,
        Lg_packet_out1_31,
        Lg_packet_out2_31,
        Lg_packet_out1_32,
        Lg_packet_out2_32,
        Lg_packet_out1_33,
        Lg_packet_out2_33;

    int Cc_router_out1_00,
        Cc_router_out2_00,
        Cc_router_out3_00,
        Cc_router_out4_00,
        Cc_router_out1_01,
        Cc_router_out2_01,
        Cc_router_out3_01,
        Cc_router_out4_01,
        Cc_router_out1_02,
        Cc_router_out2_02,
        Cc_router_out3_02,
        Cc_router_out4_02,
        Cc_router_out1_03,
        Cc_router_out2_03,
        Cc_router_out3_03,
        Cc_router_out4_03,
        Cc_router_out1_10,
        Cc_router_out2_10,
        Cc_router_out3_10,
        Cc_router_out4_10,
        Cc_router_out1_11,
        Cc_router_out2_11,
        Cc_router_out3_11,
        Cc_router_out4_11,
        Cc_router_out1_12,
        Cc_router_out2_12,
        Cc_router_out3_12,
        Cc_router_out4_12,
        Cc_router_out1_13,
        Cc_router_out2_13,
        Cc_router_out3_13,
        Cc_router_out4_13,
        Cc_router_out1_20,
        Cc_router_out2_20,
        Cc_router_out3_20,
        Cc_router_out4_20,
        Cc_router_out1_21,
        Cc_router_out2_21,
        Cc_router_out3_21,
        Cc_router_out4_21,
        Cc_router_out1_22,
        Cc_router_out2_22,
        Cc_router_out3_22,
        Cc_router_out4_22,
        Cc_router_out1_23,
        Cc_router_out2_23,
        Cc_router_out3_23,
        Cc_router_out4_23,
        Cc_router_out1_30,
        Cc_router_out2_30,
        Cc_router_out3_30,
        Cc_router_out4_30,
        Cc_router_out1_31,
        Cc_router_out2_31,
        Cc_router_out3_31,
        Cc_router_out4_31,
        Cc_router_out1_32,
        Cc_router_out2_32,
        Cc_router_out3_32,
        Cc_router_out4_32,
        Cc_router_out1_33,
        Cc_router_out2_33,
        Cc_router_out3_33,
        Cc_router_out4_33,
        Cc_router_out1_r0_01,
        Cc_router_out2_r0_01,
        Cc_router_out3_r0_01,
        Cc_router_out1_r0_23,
        Cc_router_out2_r0_23,
        Cc_router_out3_r0_23,
        Cc_router_out1_r1_01,
        Cc_router_out2_r1_01,
        Cc_router_out3_r1_01,
        Cc_router_out1_r1_23,
        Cc_router_out2_r1_23,
        Cc_router_out3_r1_23,
        Cc_router_out1_r2_01,
        Cc_router_out2_r2_01,
        Cc_router_out3_r2_01,
        Cc_router_out1_r2_23,
        Cc_router_out2_r2_23,
        Cc_router_out3_r2_23,
        Cc_router_out1_r3_01,
        Cc_router_out2_r3_01,
        Cc_router_out3_r3_01,
        Cc_router_out1_r3_23,
        Cc_router_out2_r3_23,
        Cc_router_out3_r3_23,
        Cc_router_out1_c0_01,
        Cc_router_out2_c0_01,
        Cc_router_out3_c0_01,
        Cc_router_out1_c0_23,
        Cc_router_out2_c0_23,
        Cc_router_out3_c0_23,
        Cc_router_out1_c1_01,
        Cc_router_out2_c1_01,
        Cc_router_out3_c1_01,
        Cc_router_out1_c1_23,
        Cc_router_out2_c1_23,
        Cc_router_out3_c1_23,
        Cc_router_out1_c2_01,
        Cc_router_out2_c2_01,
        Cc_router_out3_c2_01,
        Cc_router_out1_c2_23,
        Cc_router_out2_c2_23,
        Cc_router_out3_c2_23,
        Cc_router_out1_c3_01,
        Cc_router_out2_c3_01,
        Cc_router_out3_c3_01,
        Cc_router_out1_c3_23,
        Cc_router_out2_c3_23,
        Cc_router_out3_c3_23,
        Cc_data_out1_r0,
        Cc_data_out2_r0,
        Cc_data_out1_r1,
        Cc_data_out2_r1,
        Cc_data_out1_r2,
        Cc_data_out2_r2,
        Cc_data_out1_r3,
        Cc_data_out2_r3,
        Cc_data_out1_c0,
        Cc_data_out2_c0,
        Cc_data_out1_c1,
        Cc_data_out2_c1,
        Cc_data_out1_c2,
        Cc_data_out2_c2,
        Cc_data_out1_c3,
        Cc_data_out2_c3,
        Cc_packet_out1_00,
        Cc_packet_out2_00,
        Cc_packet_out1_01,
        Cc_packet_out2_01,
        Cc_packet_out1_02,
        Cc_packet_out2_02,
        Cc_packet_out1_03,
        Cc_packet_out2_03,
        Cc_packet_out1_10,
        Cc_packet_out2_10,
        Cc_packet_out1_11,
        Cc_packet_out2_11,
        Cc_packet_out1_12,
        Cc_packet_out2_12,
        Cc_packet_out1_13,
        Cc_packet_out2_13,
        Cc_packet_out1_20,
        Cc_packet_out2_20,
        Cc_packet_out1_21,
        Cc_packet_out2_21,
        Cc_packet_out1_22,
        Cc_packet_out2_22,
        Cc_packet_out1_23,
        Cc_packet_out2_23,
        Cc_packet_out1_30,
        Cc_packet_out2_30,
        Cc_packet_out1_31,
        Cc_packet_out2_31,
        Cc_packet_out1_32,
        Cc_packet_out2_32,
        Cc_packet_out1_33,
        Cc_packet_out2_33;

    float fLg[64],fLgz[32],fLg_x,fLg_y;

    int i,c,d,j,t,terminate;


       


       void router_00_process()
          {

             int i ;


             update_leafz(1_00)


             update_leafz(2_00)


             update_leaf(3_00)


             update_leaf(4_00)


          }





       void router_01_process()
          {

             int i ;


             update_leafz(1_01)


             update_leafz(2_01)


             update_leaf(3_01)


             update_leaf(4_01)


          }





       void router_02_process()
          {

             int i ;


             update_leafz(1_02)


             update_leafz(2_02)


             update_leaf(3_02)


             update_leaf(4_02)


          }





       void router_03_process()
          {

             int i ;


             update_leafz(1_03)


             update_leafz(2_03)


             update_leaf(3_03)


             update_leaf(4_03)


          }





       void router_10_process()
          {

             int i ;


             update_leafz(1_10)


             update_leafz(2_10)


             update_leaf(3_10)


             update_leaf(4_10)


          }





       void router_11_process()
          {

             int i ;


             update_leafz(1_11)


             update_leafz(2_11)


             update_leaf(3_11)


             update_leaf(4_11)


          }





       void router_12_process()
          {

             int i ;


             update_leafz(1_12)


             update_leafz(2_12)


             update_leaf(3_12)


             update_leaf(4_12)


          }





       void router_13_process()
          {

             int i ;


             update_leafz(1_13)


             update_leafz(2_13)


             update_leaf(3_13)


             update_leaf(4_13)


          }





       void router_20_process()
          {

             int i ;


             update_leafz(1_20)


             update_leafz(2_20)


             update_leaf(3_20)


             update_leaf(4_20)


          }





       void router_21_process()
          {

             int i ;


             update_leafz(1_21)


             update_leafz(2_21)


             update_leaf(3_21)


             update_leaf(4_21)


          }





       void router_22_process()
          {

             int i ;


             update_leafz(1_22)


             update_leafz(2_22)


             update_leaf(3_22)


             update_leaf(4_22)


          }





       void router_23_process()
          {

             int i ;


             update_leafz(1_23)


             update_leafz(2_23)


             update_leaf(3_23)


             update_leaf(4_23)


          }





       void router_30_process()
          {

             int i ;


             update_leafz(1_30)


             update_leafz(2_30)


             update_leaf(3_30)


             update_leaf(4_30)


          }





       void router_31_process()
          {

             int i ;


             update_leafz(1_31)


             update_leafz(2_31)


             update_leaf(3_31)


             update_leaf(4_31)


          }





       void router_32_process()
          {

             int i ;


             update_leafz(1_32)


             update_leafz(2_32)


             update_leaf(3_32)


             update_leaf(4_32)


          }





       void router_33_process()
          {

             int i ;


             update_leafz(1_33)


             update_leafz(2_33)


             update_leaf(3_33)


             update_leaf(4_33)


          }




       void router_r0_01_process()
         { 
               int i;


               update_stem(1_r0_01)


               update_stem(2_r0_01)


               update_stem(3_r0_01)


         }




       void router_r0_23_process()
         { 
               int i;


               update_stem(1_r0_23)


               update_stem(2_r0_23)


               update_stem(3_r0_23)


         }




       void router_r1_01_process()
         { 
               int i;


               update_stem(1_r1_01)


               update_stem(2_r1_01)


               update_stem(3_r1_01)


         }




       void router_r1_23_process()
         { 
               int i;


               update_stem(1_r1_23)


               update_stem(2_r1_23)


               update_stem(3_r1_23)


         }




       void router_r2_01_process()
         { 
               int i;


               update_stem(1_r2_01)


               update_stem(2_r2_01)


               update_stem(3_r2_01)


         }




       void router_r2_23_process()
         { 
               int i;


               update_stem(1_r2_23)


               update_stem(2_r2_23)


               update_stem(3_r2_23)


         }




       void router_r3_01_process()
         { 
               int i;


               update_stem(1_r3_01)


               update_stem(2_r3_01)


               update_stem(3_r3_01)


         }




       void router_r3_23_process()
         { 
               int i;


               update_stem(1_r3_23)


               update_stem(2_r3_23)


               update_stem(3_r3_23)


         }




       void router_c0_01_process()
         { 
               int i;


               update_stem(1_c0_01)


               update_stem(2_c0_01)


               update_stem(3_c0_01)


         }




       void router_c0_23_process()
         { 
               int i;


               update_stem(1_c0_23)


               update_stem(2_c0_23)


               update_stem(3_c0_23)


         }




       void router_c1_01_process()
         { 
               int i;


               update_stem(1_c1_01)


               update_stem(2_c1_01)


               update_stem(3_c1_01)


         }




       void router_c1_23_process()
         { 
               int i;


               update_stem(1_c1_23)


               update_stem(2_c1_23)


               update_stem(3_c1_23)


         }




       void router_c2_01_process()
         { 
               int i;


               update_stem(1_c2_01)


               update_stem(2_c2_01)


               update_stem(3_c2_01)


         }




       void router_c2_23_process()
         { 
               int i;


               update_stem(1_c2_23)


               update_stem(2_c2_23)


               update_stem(3_c2_23)


         }




       void router_c3_01_process()
         { 
               int i;


               update_stem(1_c3_01)


               update_stem(2_c3_01)


               update_stem(3_c3_01)


         }




       void router_c3_23_process()
         { 
               int i;


               update_stem(1_c3_23)


               update_stem(2_c3_23)


               update_stem(3_c3_23)


         }




       void router_r0_process()
         {
             int i;


             update_root(1_r0)


             update_root(2_r0)


         }




       void router_r1_process()
         {
             int i;


             update_root(1_r1)


             update_root(2_r1)


         }




       void router_r2_process()
         {
             int i;


             update_root(1_r2)


             update_root(2_r2)


         }




       void router_r3_process()
         {
             int i;


             update_root(1_r3)


             update_root(2_r3)


         }




       void router_c0_process()
         {
             int i;


             update_root(1_c0)


             update_root(2_c0)


         }




       void router_c1_process()
         {
             int i;


             update_root(1_c1)


             update_root(2_c1)


         }




       void router_c2_process()
         {
             int i;


             update_root(1_c2)


             update_root(2_c2)


         }




       void router_c3_process()
         {
             int i;


             update_root(1_c3)


             update_root(2_c3)


         }


       void packet_1_00_process()
         {
           int i;
           update_NI(1_00)

         }


       void packet_2_00_process()
         {
           int i;
           update_NI(2_00)

         }


       void packet_1_01_process()
         {
           int i;
           update_NI(1_01)

         }


       void packet_2_01_process()
         {
           int i;
           update_NI(2_01)

         }


       void packet_1_02_process()
         {
           int i;
           update_NI(1_02)

         }


       void packet_2_02_process()
         {
           int i;
           update_NI(2_02)

         }


       void packet_1_03_process()
         {
           int i;
           update_NI(1_03)

         }


       void packet_2_03_process()
         {
           int i;
           update_NI(2_03)

         }


       void packet_1_10_process()
         {
           int i;
           update_NI(1_10)

         }


       void packet_2_10_process()
         {
           int i;
           update_NI(2_10)

         }


       void packet_1_11_process()
         {
           int i;
           update_NI(1_11)

         }


       void packet_2_11_process()
         {
           int i;
           update_NI(2_11)

         }


       void packet_1_12_process()
         {
           int i;
           update_NI(1_12)

         }


       void packet_2_12_process()
         {
           int i;
           update_NI(2_12)

         }


       void packet_1_13_process()
         {
           int i;
           update_NI(1_13)

         }


       void packet_2_13_process()
         {
           int i;
           update_NI(2_13)

         }


       void packet_1_20_process()
         {
           int i;
           update_NI(1_20)

         }


       void packet_2_20_process()
         {
           int i;
           update_NI(2_20)

         }


       void packet_1_21_process()
         {
           int i;
           update_NI(1_21)

         }


       void packet_2_21_process()
         {
           int i;
           update_NI(2_21)

         }


       void packet_1_22_process()
         {
           int i;
           update_NI(1_22)

         }


       void packet_2_22_process()
         {
           int i;
           update_NI(2_22)

         }


       void packet_1_23_process()
         {
           int i;
           update_NI(1_23)

         }


       void packet_2_23_process()
         {
           int i;
           update_NI(2_23)

         }


       void packet_1_30_process()
         {
           int i;
           update_NI(1_30)

         }


       void packet_2_30_process()
         {
           int i;
           update_NI(2_30)

         }


       void packet_1_31_process()
         {
           int i;
           update_NI(1_31)

         }


       void packet_2_31_process()
         {
           int i;
           update_NI(2_31)

         }


       void packet_1_32_process()
         {
           int i;
           update_NI(1_32)

         }


       void packet_2_32_process()
         {
           int i;
           update_NI(2_32)

         }


       void packet_1_33_process()
         {
           int i;
           update_NI(1_33)

         }


       void packet_2_33_process()
         {
           int i;
           update_NI(2_33)

         }

    SC_CTOR(LE_SP_PB1_BLOCK)
      {

        prev_router_out1_00=0;
        prev_router_out2_00=0;
        prev_router_out3_00=0;
        prev_router_out4_00=0;
        prev_router_out1_01=0;
        prev_router_out2_01=0;
        prev_router_out3_01=0;
        prev_router_out4_01=0;
        prev_router_out1_02=0;
        prev_router_out2_02=0;
        prev_router_out3_02=0;
        prev_router_out4_02=0;
        prev_router_out1_03=0;
        prev_router_out2_03=0;
        prev_router_out3_03=0;
        prev_router_out4_03=0;
        prev_router_out1_10=0;
        prev_router_out2_10=0;
        prev_router_out3_10=0;
        prev_router_out4_10=0;
        prev_router_out1_11=0;
        prev_router_out2_11=0;
        prev_router_out3_11=0;
        prev_router_out4_11=0;
        prev_router_out1_12=0;
        prev_router_out2_12=0;
        prev_router_out3_12=0;
        prev_router_out4_12=0;
        prev_router_out1_13=0;
        prev_router_out2_13=0;
        prev_router_out3_13=0;
        prev_router_out4_13=0;
        prev_router_out1_20=0;
        prev_router_out2_20=0;
        prev_router_out3_20=0;
        prev_router_out4_20=0;
        prev_router_out1_21=0;
        prev_router_out2_21=0;
        prev_router_out3_21=0;
        prev_router_out4_21=0;
        prev_router_out1_22=0;
        prev_router_out2_22=0;
        prev_router_out3_22=0;
        prev_router_out4_22=0;
        prev_router_out1_23=0;
        prev_router_out2_23=0;
        prev_router_out3_23=0;
        prev_router_out4_23=0;
        prev_router_out1_30=0;
        prev_router_out2_30=0;
        prev_router_out3_30=0;
        prev_router_out4_30=0;
        prev_router_out1_31=0;
        prev_router_out2_31=0;
        prev_router_out3_31=0;
        prev_router_out4_31=0;
        prev_router_out1_32=0;
        prev_router_out2_32=0;
        prev_router_out3_32=0;
        prev_router_out4_32=0;
        prev_router_out1_33=0;
        prev_router_out2_33=0;
        prev_router_out3_33=0;
        prev_router_out4_33=0;
        prev_router_out1_r0_01=0;
        prev_router_out2_r0_01=0;
        prev_router_out3_r0_01=0;
        prev_router_out1_r0_23=0;
        prev_router_out2_r0_23=0;
        prev_router_out3_r0_23=0;
        prev_router_out1_r1_01=0;
        prev_router_out2_r1_01=0;
        prev_router_out3_r1_01=0;
        prev_router_out1_r1_23=0;
        prev_router_out2_r1_23=0;
        prev_router_out3_r1_23=0;
        prev_router_out1_r2_01=0;
        prev_router_out2_r2_01=0;
        prev_router_out3_r2_01=0;
        prev_router_out1_r2_23=0;
        prev_router_out2_r2_23=0;
        prev_router_out3_r2_23=0;
        prev_router_out1_r3_01=0;
        prev_router_out2_r3_01=0;
        prev_router_out3_r3_01=0;
        prev_router_out1_r3_23=0;
        prev_router_out2_r3_23=0;
        prev_router_out3_r3_23=0;
        prev_router_out1_c0_01=0;
        prev_router_out2_c0_01=0;
        prev_router_out3_c0_01=0;
        prev_router_out1_c0_23=0;
        prev_router_out2_c0_23=0;
        prev_router_out3_c0_23=0;
        prev_router_out1_c1_01=0;
        prev_router_out2_c1_01=0;
        prev_router_out3_c1_01=0;
        prev_router_out1_c1_23=0;
        prev_router_out2_c1_23=0;
        prev_router_out3_c1_23=0;
        prev_router_out1_c2_01=0;
        prev_router_out2_c2_01=0;
        prev_router_out3_c2_01=0;
        prev_router_out1_c2_23=0;
        prev_router_out2_c2_23=0;
        prev_router_out3_c2_23=0;
        prev_router_out1_c3_01=0;
        prev_router_out2_c3_01=0;
        prev_router_out3_c3_01=0;
        prev_router_out1_c3_23=0;
        prev_router_out2_c3_23=0;
        prev_router_out3_c3_23=0;
        prev_data_out1_r0=0;
        prev_data_out2_r0=0;
        prev_data_out1_r1=0;
        prev_data_out2_r1=0;
        prev_data_out1_r2=0;
        prev_data_out2_r2=0;
        prev_data_out1_r3=0;
        prev_data_out2_r3=0;
        prev_data_out1_c0=0;
        prev_data_out2_c0=0;
        prev_data_out1_c1=0;
        prev_data_out2_c1=0;
        prev_data_out1_c2=0;
        prev_data_out2_c2=0;
        prev_data_out1_c3=0;
        prev_data_out2_c3=0;
        prev_packet_out1_00=0;
        prev_packet_out2_00=0;
        prev_packet_out1_01=0;
        prev_packet_out2_01=0;
        prev_packet_out1_02=0;
        prev_packet_out2_02=0;
        prev_packet_out1_03=0;
        prev_packet_out2_03=0;
        prev_packet_out1_10=0;
        prev_packet_out2_10=0;
        prev_packet_out1_11=0;
        prev_packet_out2_11=0;
        prev_packet_out1_12=0;
        prev_packet_out2_12=0;
        prev_packet_out1_13=0;
        prev_packet_out2_13=0;
        prev_packet_out1_20=0;
        prev_packet_out2_20=0;
        prev_packet_out1_21=0;
        prev_packet_out2_21=0;
        prev_packet_out1_22=0;
        prev_packet_out2_22=0;
        prev_packet_out1_23=0;
        prev_packet_out2_23=0;
        prev_packet_out1_30=0;
        prev_packet_out2_30=0;
        prev_packet_out1_31=0;
        prev_packet_out2_31=0;
        prev_packet_out1_32=0;
        prev_packet_out2_32=0;
        prev_packet_out1_33=0;
        prev_packet_out2_33=0;

        prev_data_in_req1_00=0;
        prev_data_in_req2_00=0;
        prev_data_in_req3_00=0;
        prev_data_in_req4_00=0;
        prev_data_in_req1_01=0;
        prev_data_in_req2_01=0;
        prev_data_in_req3_01=0;
        prev_data_in_req4_01=0;
        prev_data_in_req1_02=0;
        prev_data_in_req2_02=0;
        prev_data_in_req3_02=0;
        prev_data_in_req4_02=0;
        prev_data_in_req1_03=0;
        prev_data_in_req2_03=0;
        prev_data_in_req3_03=0;
        prev_data_in_req4_03=0;
        prev_data_in_req1_10=0;
        prev_data_in_req2_10=0;
        prev_data_in_req3_10=0;
        prev_data_in_req4_10=0;
        prev_data_in_req1_11=0;
        prev_data_in_req2_11=0;
        prev_data_in_req3_11=0;
        prev_data_in_req4_11=0;
        prev_data_in_req1_12=0;
        prev_data_in_req2_12=0;
        prev_data_in_req3_12=0;
        prev_data_in_req4_12=0;
        prev_data_in_req1_13=0;
        prev_data_in_req2_13=0;
        prev_data_in_req3_13=0;
        prev_data_in_req4_13=0;
        prev_data_in_req1_20=0;
        prev_data_in_req2_20=0;
        prev_data_in_req3_20=0;
        prev_data_in_req4_20=0;
        prev_data_in_req1_21=0;
        prev_data_in_req2_21=0;
        prev_data_in_req3_21=0;
        prev_data_in_req4_21=0;
        prev_data_in_req1_22=0;
        prev_data_in_req2_22=0;
        prev_data_in_req3_22=0;
        prev_data_in_req4_22=0;
        prev_data_in_req1_23=0;
        prev_data_in_req2_23=0;
        prev_data_in_req3_23=0;
        prev_data_in_req4_23=0;
        prev_data_in_req1_30=0;
        prev_data_in_req2_30=0;
        prev_data_in_req3_30=0;
        prev_data_in_req4_30=0;
        prev_data_in_req1_31=0;
        prev_data_in_req2_31=0;
        prev_data_in_req3_31=0;
        prev_data_in_req4_31=0;
        prev_data_in_req1_32=0;
        prev_data_in_req2_32=0;
        prev_data_in_req3_32=0;
        prev_data_in_req4_32=0;
        prev_data_in_req1_33=0;
        prev_data_in_req2_33=0;
        prev_data_in_req3_33=0;
        prev_data_in_req4_33=0;
        prev_data_in_req1_r0_01=0;
        prev_data_in_req2_r0_01=0;
        prev_data_in_req3_r0_01=0;
        prev_data_in_req1_r0_23=0;
        prev_data_in_req2_r0_23=0;
        prev_data_in_req3_r0_23=0;
        prev_data_in_req1_r1_01=0;
        prev_data_in_req2_r1_01=0;
        prev_data_in_req3_r1_01=0;
        prev_data_in_req1_r1_23=0;
        prev_data_in_req2_r1_23=0;
        prev_data_in_req3_r1_23=0;
        prev_data_in_req1_r2_01=0;
        prev_data_in_req2_r2_01=0;
        prev_data_in_req3_r2_01=0;
        prev_data_in_req1_r2_23=0;
        prev_data_in_req2_r2_23=0;
        prev_data_in_req3_r2_23=0;
        prev_data_in_req1_r3_01=0;
        prev_data_in_req2_r3_01=0;
        prev_data_in_req3_r3_01=0;
        prev_data_in_req1_r3_23=0;
        prev_data_in_req2_r3_23=0;
        prev_data_in_req3_r3_23=0;
        prev_data_in_req1_c0_01=0;
        prev_data_in_req2_c0_01=0;
        prev_data_in_req3_c0_01=0;
        prev_data_in_req1_c0_23=0;
        prev_data_in_req2_c0_23=0;
        prev_data_in_req3_c0_23=0;
        prev_data_in_req1_c1_01=0;
        prev_data_in_req2_c1_01=0;
        prev_data_in_req3_c1_01=0;
        prev_data_in_req1_c1_23=0;
        prev_data_in_req2_c1_23=0;
        prev_data_in_req3_c1_23=0;
        prev_data_in_req1_c2_01=0;
        prev_data_in_req2_c2_01=0;
        prev_data_in_req3_c2_01=0;
        prev_data_in_req1_c2_23=0;
        prev_data_in_req2_c2_23=0;
        prev_data_in_req3_c2_23=0;
        prev_data_in_req1_c3_01=0;
        prev_data_in_req2_c3_01=0;
        prev_data_in_req3_c3_01=0;
        prev_data_in_req1_c3_23=0;
        prev_data_in_req2_c3_23=0;
        prev_data_in_req3_c3_23=0;
        prev_data_in_req1_r0=0;
        prev_data_in_req2_r0=0;
        prev_data_in_req1_r1=0;
        prev_data_in_req2_r1=0;
        prev_data_in_req1_r2=0;
        prev_data_in_req2_r2=0;
        prev_data_in_req1_r3=0;
        prev_data_in_req2_r3=0;
        prev_data_in_req1_c0=0;
        prev_data_in_req2_c0=0;
        prev_data_in_req1_c1=0;
        prev_data_in_req2_c1=0;
        prev_data_in_req1_c2=0;
        prev_data_in_req2_c2=0;
        prev_data_in_req1_c3=0;
        prev_data_in_req2_c3=0;
        prev_data_in_req_NI1_00=0;
        prev_data_in_req_NI2_00=0;
        prev_data_in_req_NI1_01=0;
        prev_data_in_req_NI2_01=0;
        prev_data_in_req_NI1_02=0;
        prev_data_in_req_NI2_02=0;
        prev_data_in_req_NI1_03=0;
        prev_data_in_req_NI2_03=0;
        prev_data_in_req_NI1_10=0;
        prev_data_in_req_NI2_10=0;
        prev_data_in_req_NI1_11=0;
        prev_data_in_req_NI2_11=0;
        prev_data_in_req_NI1_12=0;
        prev_data_in_req_NI2_12=0;
        prev_data_in_req_NI1_13=0;
        prev_data_in_req_NI2_13=0;
        prev_data_in_req_NI1_20=0;
        prev_data_in_req_NI2_20=0;
        prev_data_in_req_NI1_21=0;
        prev_data_in_req_NI2_21=0;
        prev_data_in_req_NI1_22=0;
        prev_data_in_req_NI2_22=0;
        prev_data_in_req_NI1_23=0;
        prev_data_in_req_NI2_23=0;
        prev_data_in_req_NI1_30=0;
        prev_data_in_req_NI2_30=0;
        prev_data_in_req_NI1_31=0;
        prev_data_in_req_NI2_31=0;
        prev_data_in_req_NI1_32=0;
        prev_data_in_req_NI2_32=0;
        prev_data_in_req_NI1_33=0;
        prev_data_in_req_NI2_33=0;

        prev_out_val1_00=0;
        prev_out_val2_00=0;
        prev_out_val3_00=0;
        prev_out_val4_00=0;
        prev_out_val1_01=0;
        prev_out_val2_01=0;
        prev_out_val3_01=0;
        prev_out_val4_01=0;
        prev_out_val1_02=0;
        prev_out_val2_02=0;
        prev_out_val3_02=0;
        prev_out_val4_02=0;
        prev_out_val1_03=0;
        prev_out_val2_03=0;
        prev_out_val3_03=0;
        prev_out_val4_03=0;
        prev_out_val1_10=0;
        prev_out_val2_10=0;
        prev_out_val3_10=0;
        prev_out_val4_10=0;
        prev_out_val1_11=0;
        prev_out_val2_11=0;
        prev_out_val3_11=0;
        prev_out_val4_11=0;
        prev_out_val1_12=0;
        prev_out_val2_12=0;
        prev_out_val3_12=0;
        prev_out_val4_12=0;
        prev_out_val1_13=0;
        prev_out_val2_13=0;
        prev_out_val3_13=0;
        prev_out_val4_13=0;
        prev_out_val1_20=0;
        prev_out_val2_20=0;
        prev_out_val3_20=0;
        prev_out_val4_20=0;
        prev_out_val1_21=0;
        prev_out_val2_21=0;
        prev_out_val3_21=0;
        prev_out_val4_21=0;
        prev_out_val1_22=0;
        prev_out_val2_22=0;
        prev_out_val3_22=0;
        prev_out_val4_22=0;
        prev_out_val1_23=0;
        prev_out_val2_23=0;
        prev_out_val3_23=0;
        prev_out_val4_23=0;
        prev_out_val1_30=0;
        prev_out_val2_30=0;
        prev_out_val3_30=0;
        prev_out_val4_30=0;
        prev_out_val1_31=0;
        prev_out_val2_31=0;
        prev_out_val3_31=0;
        prev_out_val4_31=0;
        prev_out_val1_32=0;
        prev_out_val2_32=0;
        prev_out_val3_32=0;
        prev_out_val4_32=0;
        prev_out_val1_33=0;
        prev_out_val2_33=0;
        prev_out_val3_33=0;
        prev_out_val4_33=0;
        prev_out_val1_r0_01=0;
        prev_out_val2_r0_01=0;
        prev_out_val3_r0_01=0;
        prev_out_val1_r0_23=0;
        prev_out_val2_r0_23=0;
        prev_out_val3_r0_23=0;
        prev_out_val1_r1_01=0;
        prev_out_val2_r1_01=0;
        prev_out_val3_r1_01=0;
        prev_out_val1_r1_23=0;
        prev_out_val2_r1_23=0;
        prev_out_val3_r1_23=0;
        prev_out_val1_r2_01=0;
        prev_out_val2_r2_01=0;
        prev_out_val3_r2_01=0;
        prev_out_val1_r2_23=0;
        prev_out_val2_r2_23=0;
        prev_out_val3_r2_23=0;
        prev_out_val1_r3_01=0;
        prev_out_val2_r3_01=0;
        prev_out_val3_r3_01=0;
        prev_out_val1_r3_23=0;
        prev_out_val2_r3_23=0;
        prev_out_val3_r3_23=0;
        prev_out_val1_c0_01=0;
        prev_out_val2_c0_01=0;
        prev_out_val3_c0_01=0;
        prev_out_val1_c0_23=0;
        prev_out_val2_c0_23=0;
        prev_out_val3_c0_23=0;
        prev_out_val1_c1_01=0;
        prev_out_val2_c1_01=0;
        prev_out_val3_c1_01=0;
        prev_out_val1_c1_23=0;
        prev_out_val2_c1_23=0;
        prev_out_val3_c1_23=0;
        prev_out_val1_c2_01=0;
        prev_out_val2_c2_01=0;
        prev_out_val3_c2_01=0;
        prev_out_val1_c2_23=0;
        prev_out_val2_c2_23=0;
        prev_out_val3_c2_23=0;
        prev_out_val1_c3_01=0;
        prev_out_val2_c3_01=0;
        prev_out_val3_c3_01=0;
        prev_out_val1_c3_23=0;
        prev_out_val2_c3_23=0;
        prev_out_val3_c3_23=0;
        prev_out_val1_r0=0;
        prev_out_val2_r0=0;
        prev_out_val1_r1=0;
        prev_out_val2_r1=0;
        prev_out_val1_r2=0;
        prev_out_val2_r2=0;
        prev_out_val1_r3=0;
        prev_out_val2_r3=0;
        prev_out_val1_c0=0;
        prev_out_val2_c0=0;
        prev_out_val1_c1=0;
        prev_out_val2_c1=0;
        prev_out_val1_c2=0;
        prev_out_val2_c2=0;
        prev_out_val1_c3=0;
        prev_out_val2_c3=0;
        prev_data_valid1_00=0;
        prev_data_valid2_00=0;
        prev_data_valid1_01=0;
        prev_data_valid2_01=0;
        prev_data_valid1_02=0;
        prev_data_valid2_02=0;
        prev_data_valid1_03=0;
        prev_data_valid2_03=0;
        prev_data_valid1_10=0;
        prev_data_valid2_10=0;
        prev_data_valid1_11=0;
        prev_data_valid2_11=0;
        prev_data_valid1_12=0;
        prev_data_valid2_12=0;
        prev_data_valid1_13=0;
        prev_data_valid2_13=0;
        prev_data_valid1_20=0;
        prev_data_valid2_20=0;
        prev_data_valid1_21=0;
        prev_data_valid2_21=0;
        prev_data_valid1_22=0;
        prev_data_valid2_22=0;
        prev_data_valid1_23=0;
        prev_data_valid2_23=0;
        prev_data_valid1_30=0;
        prev_data_valid2_30=0;
        prev_data_valid1_31=0;
        prev_data_valid2_31=0;
        prev_data_valid1_32=0;
        prev_data_valid2_32=0;
        prev_data_valid1_33=0;
        prev_data_valid2_33=0;

        
        for(i=0;i<64;i++)
          {
             sp_router_out1_00[i]=0;
             sp_router_out2_00[i]=0;
             sp_router_out3_00[i]=0;
             sp_router_out4_00[i]=0;
             sp_router_out1_01[i]=0;
             sp_router_out2_01[i]=0;
             sp_router_out3_01[i]=0;
             sp_router_out4_01[i]=0;
             sp_router_out1_02[i]=0;
             sp_router_out2_02[i]=0;
             sp_router_out3_02[i]=0;
             sp_router_out4_02[i]=0;
             sp_router_out1_03[i]=0;
             sp_router_out2_03[i]=0;
             sp_router_out3_03[i]=0;
             sp_router_out4_03[i]=0;
             sp_router_out1_10[i]=0;
             sp_router_out2_10[i]=0;
             sp_router_out3_10[i]=0;
             sp_router_out4_10[i]=0;
             sp_router_out1_11[i]=0;
             sp_router_out2_11[i]=0;
             sp_router_out3_11[i]=0;
             sp_router_out4_11[i]=0;
             sp_router_out1_12[i]=0;
             sp_router_out2_12[i]=0;
             sp_router_out3_12[i]=0;
             sp_router_out4_12[i]=0;
             sp_router_out1_13[i]=0;
             sp_router_out2_13[i]=0;
             sp_router_out3_13[i]=0;
             sp_router_out4_13[i]=0;
             sp_router_out1_20[i]=0;
             sp_router_out2_20[i]=0;
             sp_router_out3_20[i]=0;
             sp_router_out4_20[i]=0;
             sp_router_out1_21[i]=0;
             sp_router_out2_21[i]=0;
             sp_router_out3_21[i]=0;
             sp_router_out4_21[i]=0;
             sp_router_out1_22[i]=0;
             sp_router_out2_22[i]=0;
             sp_router_out3_22[i]=0;
             sp_router_out4_22[i]=0;
             sp_router_out1_23[i]=0;
             sp_router_out2_23[i]=0;
             sp_router_out3_23[i]=0;
             sp_router_out4_23[i]=0;
             sp_router_out1_30[i]=0;
             sp_router_out2_30[i]=0;
             sp_router_out3_30[i]=0;
             sp_router_out4_30[i]=0;
             sp_router_out1_31[i]=0;
             sp_router_out2_31[i]=0;
             sp_router_out3_31[i]=0;
             sp_router_out4_31[i]=0;
             sp_router_out1_32[i]=0;
             sp_router_out2_32[i]=0;
             sp_router_out3_32[i]=0;
             sp_router_out4_32[i]=0;
             sp_router_out1_33[i]=0;
             sp_router_out2_33[i]=0;
             sp_router_out3_33[i]=0;
             sp_router_out4_33[i]=0;
             sp_router_out1_r0_01[i]=0;
             sp_router_out2_r0_01[i]=0;
             sp_router_out3_r0_01[i]=0;
             sp_router_out1_r0_23[i]=0;
             sp_router_out2_r0_23[i]=0;
             sp_router_out3_r0_23[i]=0;
             sp_router_out1_r1_01[i]=0;
             sp_router_out2_r1_01[i]=0;
             sp_router_out3_r1_01[i]=0;
             sp_router_out1_r1_23[i]=0;
             sp_router_out2_r1_23[i]=0;
             sp_router_out3_r1_23[i]=0;
             sp_router_out1_r2_01[i]=0;
             sp_router_out2_r2_01[i]=0;
             sp_router_out3_r2_01[i]=0;
             sp_router_out1_r2_23[i]=0;
             sp_router_out2_r2_23[i]=0;
             sp_router_out3_r2_23[i]=0;
             sp_router_out1_r3_01[i]=0;
             sp_router_out2_r3_01[i]=0;
             sp_router_out3_r3_01[i]=0;
             sp_router_out1_r3_23[i]=0;
             sp_router_out2_r3_23[i]=0;
             sp_router_out3_r3_23[i]=0;
             sp_router_out1_c0_01[i]=0;
             sp_router_out2_c0_01[i]=0;
             sp_router_out3_c0_01[i]=0;
             sp_router_out1_c0_23[i]=0;
             sp_router_out2_c0_23[i]=0;
             sp_router_out3_c0_23[i]=0;
             sp_router_out1_c1_01[i]=0;
             sp_router_out2_c1_01[i]=0;
             sp_router_out3_c1_01[i]=0;
             sp_router_out1_c1_23[i]=0;
             sp_router_out2_c1_23[i]=0;
             sp_router_out3_c1_23[i]=0;
             sp_router_out1_c2_01[i]=0;
             sp_router_out2_c2_01[i]=0;
             sp_router_out3_c2_01[i]=0;
             sp_router_out1_c2_23[i]=0;
             sp_router_out2_c2_23[i]=0;
             sp_router_out3_c2_23[i]=0;
             sp_router_out1_c3_01[i]=0;
             sp_router_out2_c3_01[i]=0;
             sp_router_out3_c3_01[i]=0;
             sp_router_out1_c3_23[i]=0;
             sp_router_out2_c3_23[i]=0;
             sp_router_out3_c3_23[i]=0;
             sp_data_out1_r0[i]=0;
             sp_data_out2_r0[i]=0;
             sp_data_out1_r1[i]=0;
             sp_data_out2_r1[i]=0;
             sp_data_out1_r2[i]=0;
             sp_data_out2_r2[i]=0;
             sp_data_out1_r3[i]=0;
             sp_data_out2_r3[i]=0;
             sp_data_out1_c0[i]=0;
             sp_data_out2_c0[i]=0;
             sp_data_out1_c1[i]=0;
             sp_data_out2_c1[i]=0;
             sp_data_out1_c2[i]=0;
             sp_data_out2_c2[i]=0;
             sp_data_out1_c3[i]=0;
             sp_data_out2_c3[i]=0;
             sp_packet_out1_00[i]=0;
             sp_packet_out2_00[i]=0;
             sp_packet_out1_01[i]=0;
             sp_packet_out2_01[i]=0;
             sp_packet_out1_02[i]=0;
             sp_packet_out2_02[i]=0;
             sp_packet_out1_03[i]=0;
             sp_packet_out2_03[i]=0;
             sp_packet_out1_10[i]=0;
             sp_packet_out2_10[i]=0;
             sp_packet_out1_11[i]=0;
             sp_packet_out2_11[i]=0;
             sp_packet_out1_12[i]=0;
             sp_packet_out2_12[i]=0;
             sp_packet_out1_13[i]=0;
             sp_packet_out2_13[i]=0;
             sp_packet_out1_20[i]=0;
             sp_packet_out2_20[i]=0;
             sp_packet_out1_21[i]=0;
             sp_packet_out2_21[i]=0;
             sp_packet_out1_22[i]=0;
             sp_packet_out2_22[i]=0;
             sp_packet_out1_23[i]=0;
             sp_packet_out2_23[i]=0;
             sp_packet_out1_30[i]=0;
             sp_packet_out2_30[i]=0;
             sp_packet_out1_31[i]=0;
             sp_packet_out2_31[i]=0;
             sp_packet_out1_32[i]=0;
             sp_packet_out2_32[i]=0;
             sp_packet_out1_33[i]=0;
             sp_packet_out2_33[i]=0;

             pb1_router_out1_00[i]=0;
             pb1_router_out2_00[i]=0;
             pb1_router_out3_00[i]=0;
             pb1_router_out4_00[i]=0;
             pb1_router_out1_01[i]=0;
             pb1_router_out2_01[i]=0;
             pb1_router_out3_01[i]=0;
             pb1_router_out4_01[i]=0;
             pb1_router_out1_02[i]=0;
             pb1_router_out2_02[i]=0;
             pb1_router_out3_02[i]=0;
             pb1_router_out4_02[i]=0;
             pb1_router_out1_03[i]=0;
             pb1_router_out2_03[i]=0;
             pb1_router_out3_03[i]=0;
             pb1_router_out4_03[i]=0;
             pb1_router_out1_10[i]=0;
             pb1_router_out2_10[i]=0;
             pb1_router_out3_10[i]=0;
             pb1_router_out4_10[i]=0;
             pb1_router_out1_11[i]=0;
             pb1_router_out2_11[i]=0;
             pb1_router_out3_11[i]=0;
             pb1_router_out4_11[i]=0;
             pb1_router_out1_12[i]=0;
             pb1_router_out2_12[i]=0;
             pb1_router_out3_12[i]=0;
             pb1_router_out4_12[i]=0;
             pb1_router_out1_13[i]=0;
             pb1_router_out2_13[i]=0;
             pb1_router_out3_13[i]=0;
             pb1_router_out4_13[i]=0;
             pb1_router_out1_20[i]=0;
             pb1_router_out2_20[i]=0;
             pb1_router_out3_20[i]=0;
             pb1_router_out4_20[i]=0;
             pb1_router_out1_21[i]=0;
             pb1_router_out2_21[i]=0;
             pb1_router_out3_21[i]=0;
             pb1_router_out4_21[i]=0;
             pb1_router_out1_22[i]=0;
             pb1_router_out2_22[i]=0;
             pb1_router_out3_22[i]=0;
             pb1_router_out4_22[i]=0;
             pb1_router_out1_23[i]=0;
             pb1_router_out2_23[i]=0;
             pb1_router_out3_23[i]=0;
             pb1_router_out4_23[i]=0;
             pb1_router_out1_30[i]=0;
             pb1_router_out2_30[i]=0;
             pb1_router_out3_30[i]=0;
             pb1_router_out4_30[i]=0;
             pb1_router_out1_31[i]=0;
             pb1_router_out2_31[i]=0;
             pb1_router_out3_31[i]=0;
             pb1_router_out4_31[i]=0;
             pb1_router_out1_32[i]=0;
             pb1_router_out2_32[i]=0;
             pb1_router_out3_32[i]=0;
             pb1_router_out4_32[i]=0;
             pb1_router_out1_33[i]=0;
             pb1_router_out2_33[i]=0;
             pb1_router_out3_33[i]=0;
             pb1_router_out4_33[i]=0;
             pb1_router_out1_r0_01[i]=0;
             pb1_router_out2_r0_01[i]=0;
             pb1_router_out3_r0_01[i]=0;
             pb1_router_out1_r0_23[i]=0;
             pb1_router_out2_r0_23[i]=0;
             pb1_router_out3_r0_23[i]=0;
             pb1_router_out1_r1_01[i]=0;
             pb1_router_out2_r1_01[i]=0;
             pb1_router_out3_r1_01[i]=0;
             pb1_router_out1_r1_23[i]=0;
             pb1_router_out2_r1_23[i]=0;
             pb1_router_out3_r1_23[i]=0;
             pb1_router_out1_r2_01[i]=0;
             pb1_router_out2_r2_01[i]=0;
             pb1_router_out3_r2_01[i]=0;
             pb1_router_out1_r2_23[i]=0;
             pb1_router_out2_r2_23[i]=0;
             pb1_router_out3_r2_23[i]=0;
             pb1_router_out1_r3_01[i]=0;
             pb1_router_out2_r3_01[i]=0;
             pb1_router_out3_r3_01[i]=0;
             pb1_router_out1_r3_23[i]=0;
             pb1_router_out2_r3_23[i]=0;
             pb1_router_out3_r3_23[i]=0;
             pb1_router_out1_c0_01[i]=0;
             pb1_router_out2_c0_01[i]=0;
             pb1_router_out3_c0_01[i]=0;
             pb1_router_out1_c0_23[i]=0;
             pb1_router_out2_c0_23[i]=0;
             pb1_router_out3_c0_23[i]=0;
             pb1_router_out1_c1_01[i]=0;
             pb1_router_out2_c1_01[i]=0;
             pb1_router_out3_c1_01[i]=0;
             pb1_router_out1_c1_23[i]=0;
             pb1_router_out2_c1_23[i]=0;
             pb1_router_out3_c1_23[i]=0;
             pb1_router_out1_c2_01[i]=0;
             pb1_router_out2_c2_01[i]=0;
             pb1_router_out3_c2_01[i]=0;
             pb1_router_out1_c2_23[i]=0;
             pb1_router_out2_c2_23[i]=0;
             pb1_router_out3_c2_23[i]=0;
             pb1_router_out1_c3_01[i]=0;
             pb1_router_out2_c3_01[i]=0;
             pb1_router_out3_c3_01[i]=0;
             pb1_router_out1_c3_23[i]=0;
             pb1_router_out2_c3_23[i]=0;
             pb1_router_out3_c3_23[i]=0;
             pb1_data_out1_r0[i]=0;
             pb1_data_out2_r0[i]=0;
             pb1_data_out1_r1[i]=0;
             pb1_data_out2_r1[i]=0;
             pb1_data_out1_r2[i]=0;
             pb1_data_out2_r2[i]=0;
             pb1_data_out1_r3[i]=0;
             pb1_data_out2_r3[i]=0;
             pb1_data_out1_c0[i]=0;
             pb1_data_out2_c0[i]=0;
             pb1_data_out1_c1[i]=0;
             pb1_data_out2_c1[i]=0;
             pb1_data_out1_c2[i]=0;
             pb1_data_out2_c2[i]=0;
             pb1_data_out1_c3[i]=0;
             pb1_data_out2_c3[i]=0;
             pb1_packet_out1_00[i]=0;
             pb1_packet_out2_00[i]=0;
             pb1_packet_out1_01[i]=0;
             pb1_packet_out2_01[i]=0;
             pb1_packet_out1_02[i]=0;
             pb1_packet_out2_02[i]=0;
             pb1_packet_out1_03[i]=0;
             pb1_packet_out2_03[i]=0;
             pb1_packet_out1_10[i]=0;
             pb1_packet_out2_10[i]=0;
             pb1_packet_out1_11[i]=0;
             pb1_packet_out2_11[i]=0;
             pb1_packet_out1_12[i]=0;
             pb1_packet_out2_12[i]=0;
             pb1_packet_out1_13[i]=0;
             pb1_packet_out2_13[i]=0;
             pb1_packet_out1_20[i]=0;
             pb1_packet_out2_20[i]=0;
             pb1_packet_out1_21[i]=0;
             pb1_packet_out2_21[i]=0;
             pb1_packet_out1_22[i]=0;
             pb1_packet_out2_22[i]=0;
             pb1_packet_out1_23[i]=0;
             pb1_packet_out2_23[i]=0;
             pb1_packet_out1_30[i]=0;
             pb1_packet_out2_30[i]=0;
             pb1_packet_out1_31[i]=0;
             pb1_packet_out2_31[i]=0;
             pb1_packet_out1_32[i]=0;
             pb1_packet_out2_32[i]=0;
             pb1_packet_out1_33[i]=0;
             pb1_packet_out2_33[i]=0;
          }

        sp_data_in_req1_00=0;
        sp_data_in_req2_00=0;
        sp_data_in_req3_00=0;
        sp_data_in_req4_00=0;
        sp_data_in_req1_01=0;
        sp_data_in_req2_01=0;
        sp_data_in_req3_01=0;
        sp_data_in_req4_01=0;
        sp_data_in_req1_02=0;
        sp_data_in_req2_02=0;
        sp_data_in_req3_02=0;
        sp_data_in_req4_02=0;
        sp_data_in_req1_03=0;
        sp_data_in_req2_03=0;
        sp_data_in_req3_03=0;
        sp_data_in_req4_03=0;
        sp_data_in_req1_10=0;
        sp_data_in_req2_10=0;
        sp_data_in_req3_10=0;
        sp_data_in_req4_10=0;
        sp_data_in_req1_11=0;
        sp_data_in_req2_11=0;
        sp_data_in_req3_11=0;
        sp_data_in_req4_11=0;
        sp_data_in_req1_12=0;
        sp_data_in_req2_12=0;
        sp_data_in_req3_12=0;
        sp_data_in_req4_12=0;
        sp_data_in_req1_13=0;
        sp_data_in_req2_13=0;
        sp_data_in_req3_13=0;
        sp_data_in_req4_13=0;
        sp_data_in_req1_20=0;
        sp_data_in_req2_20=0;
        sp_data_in_req3_20=0;
        sp_data_in_req4_20=0;
        sp_data_in_req1_21=0;
        sp_data_in_req2_21=0;
        sp_data_in_req3_21=0;
        sp_data_in_req4_21=0;
        sp_data_in_req1_22=0;
        sp_data_in_req2_22=0;
        sp_data_in_req3_22=0;
        sp_data_in_req4_22=0;
        sp_data_in_req1_23=0;
        sp_data_in_req2_23=0;
        sp_data_in_req3_23=0;
        sp_data_in_req4_23=0;
        sp_data_in_req1_30=0;
        sp_data_in_req2_30=0;
        sp_data_in_req3_30=0;
        sp_data_in_req4_30=0;
        sp_data_in_req1_31=0;
        sp_data_in_req2_31=0;
        sp_data_in_req3_31=0;
        sp_data_in_req4_31=0;
        sp_data_in_req1_32=0;
        sp_data_in_req2_32=0;
        sp_data_in_req3_32=0;
        sp_data_in_req4_32=0;
        sp_data_in_req1_33=0;
        sp_data_in_req2_33=0;
        sp_data_in_req3_33=0;
        sp_data_in_req4_33=0;
        sp_data_in_req1_r0_01=0;
        sp_data_in_req2_r0_01=0;
        sp_data_in_req3_r0_01=0;
        sp_data_in_req1_r0_23=0;
        sp_data_in_req2_r0_23=0;
        sp_data_in_req3_r0_23=0;
        sp_data_in_req1_r1_01=0;
        sp_data_in_req2_r1_01=0;
        sp_data_in_req3_r1_01=0;
        sp_data_in_req1_r1_23=0;
        sp_data_in_req2_r1_23=0;
        sp_data_in_req3_r1_23=0;
        sp_data_in_req1_r2_01=0;
        sp_data_in_req2_r2_01=0;
        sp_data_in_req3_r2_01=0;
        sp_data_in_req1_r2_23=0;
        sp_data_in_req2_r2_23=0;
        sp_data_in_req3_r2_23=0;
        sp_data_in_req1_r3_01=0;
        sp_data_in_req2_r3_01=0;
        sp_data_in_req3_r3_01=0;
        sp_data_in_req1_r3_23=0;
        sp_data_in_req2_r3_23=0;
        sp_data_in_req3_r3_23=0;
        sp_data_in_req1_c0_01=0;
        sp_data_in_req2_c0_01=0;
        sp_data_in_req3_c0_01=0;
        sp_data_in_req1_c0_23=0;
        sp_data_in_req2_c0_23=0;
        sp_data_in_req3_c0_23=0;
        sp_data_in_req1_c1_01=0;
        sp_data_in_req2_c1_01=0;
        sp_data_in_req3_c1_01=0;
        sp_data_in_req1_c1_23=0;
        sp_data_in_req2_c1_23=0;
        sp_data_in_req3_c1_23=0;
        sp_data_in_req1_c2_01=0;
        sp_data_in_req2_c2_01=0;
        sp_data_in_req3_c2_01=0;
        sp_data_in_req1_c2_23=0;
        sp_data_in_req2_c2_23=0;
        sp_data_in_req3_c2_23=0;
        sp_data_in_req1_c3_01=0;
        sp_data_in_req2_c3_01=0;
        sp_data_in_req3_c3_01=0;
        sp_data_in_req1_c3_23=0;
        sp_data_in_req2_c3_23=0;
        sp_data_in_req3_c3_23=0;
        sp_data_in_req1_r0=0;
        sp_data_in_req2_r0=0;
        sp_data_in_req1_r1=0;
        sp_data_in_req2_r1=0;
        sp_data_in_req1_r2=0;
        sp_data_in_req2_r2=0;
        sp_data_in_req1_r3=0;
        sp_data_in_req2_r3=0;
        sp_data_in_req1_c0=0;
        sp_data_in_req2_c0=0;
        sp_data_in_req1_c1=0;
        sp_data_in_req2_c1=0;
        sp_data_in_req1_c2=0;
        sp_data_in_req2_c2=0;
        sp_data_in_req1_c3=0;
        sp_data_in_req2_c3=0;
        sp_data_in_req_NI1_00=0;
        sp_data_in_req_NI2_00=0;
        sp_data_in_req_NI1_01=0;
        sp_data_in_req_NI2_01=0;
        sp_data_in_req_NI1_02=0;
        sp_data_in_req_NI2_02=0;
        sp_data_in_req_NI1_03=0;
        sp_data_in_req_NI2_03=0;
        sp_data_in_req_NI1_10=0;
        sp_data_in_req_NI2_10=0;
        sp_data_in_req_NI1_11=0;
        sp_data_in_req_NI2_11=0;
        sp_data_in_req_NI1_12=0;
        sp_data_in_req_NI2_12=0;
        sp_data_in_req_NI1_13=0;
        sp_data_in_req_NI2_13=0;
        sp_data_in_req_NI1_20=0;
        sp_data_in_req_NI2_20=0;
        sp_data_in_req_NI1_21=0;
        sp_data_in_req_NI2_21=0;
        sp_data_in_req_NI1_22=0;
        sp_data_in_req_NI2_22=0;
        sp_data_in_req_NI1_23=0;
        sp_data_in_req_NI2_23=0;
        sp_data_in_req_NI1_30=0;
        sp_data_in_req_NI2_30=0;
        sp_data_in_req_NI1_31=0;
        sp_data_in_req_NI2_31=0;
        sp_data_in_req_NI1_32=0;
        sp_data_in_req_NI2_32=0;
        sp_data_in_req_NI1_33=0;
        sp_data_in_req_NI2_33=0;

        pb1_data_in_req1_00=0;
        pb1_data_in_req2_00=0;
        pb1_data_in_req3_00=0;
        pb1_data_in_req4_00=0;
        pb1_data_in_req1_01=0;
        pb1_data_in_req2_01=0;
        pb1_data_in_req3_01=0;
        pb1_data_in_req4_01=0;
        pb1_data_in_req1_02=0;
        pb1_data_in_req2_02=0;
        pb1_data_in_req3_02=0;
        pb1_data_in_req4_02=0;
        pb1_data_in_req1_03=0;
        pb1_data_in_req2_03=0;
        pb1_data_in_req3_03=0;
        pb1_data_in_req4_03=0;
        pb1_data_in_req1_10=0;
        pb1_data_in_req2_10=0;
        pb1_data_in_req3_10=0;
        pb1_data_in_req4_10=0;
        pb1_data_in_req1_11=0;
        pb1_data_in_req2_11=0;
        pb1_data_in_req3_11=0;
        pb1_data_in_req4_11=0;
        pb1_data_in_req1_12=0;
        pb1_data_in_req2_12=0;
        pb1_data_in_req3_12=0;
        pb1_data_in_req4_12=0;
        pb1_data_in_req1_13=0;
        pb1_data_in_req2_13=0;
        pb1_data_in_req3_13=0;
        pb1_data_in_req4_13=0;
        pb1_data_in_req1_20=0;
        pb1_data_in_req2_20=0;
        pb1_data_in_req3_20=0;
        pb1_data_in_req4_20=0;
        pb1_data_in_req1_21=0;
        pb1_data_in_req2_21=0;
        pb1_data_in_req3_21=0;
        pb1_data_in_req4_21=0;
        pb1_data_in_req1_22=0;
        pb1_data_in_req2_22=0;
        pb1_data_in_req3_22=0;
        pb1_data_in_req4_22=0;
        pb1_data_in_req1_23=0;
        pb1_data_in_req2_23=0;
        pb1_data_in_req3_23=0;
        pb1_data_in_req4_23=0;
        pb1_data_in_req1_30=0;
        pb1_data_in_req2_30=0;
        pb1_data_in_req3_30=0;
        pb1_data_in_req4_30=0;
        pb1_data_in_req1_31=0;
        pb1_data_in_req2_31=0;
        pb1_data_in_req3_31=0;
        pb1_data_in_req4_31=0;
        pb1_data_in_req1_32=0;
        pb1_data_in_req2_32=0;
        pb1_data_in_req3_32=0;
        pb1_data_in_req4_32=0;
        pb1_data_in_req1_33=0;
        pb1_data_in_req2_33=0;
        pb1_data_in_req3_33=0;
        pb1_data_in_req4_33=0;
        pb1_data_in_req1_r0_01=0;
        pb1_data_in_req2_r0_01=0;
        pb1_data_in_req3_r0_01=0;
        pb1_data_in_req1_r0_23=0;
        pb1_data_in_req2_r0_23=0;
        pb1_data_in_req3_r0_23=0;
        pb1_data_in_req1_r1_01=0;
        pb1_data_in_req2_r1_01=0;
        pb1_data_in_req3_r1_01=0;
        pb1_data_in_req1_r1_23=0;
        pb1_data_in_req2_r1_23=0;
        pb1_data_in_req3_r1_23=0;
        pb1_data_in_req1_r2_01=0;
        pb1_data_in_req2_r2_01=0;
        pb1_data_in_req3_r2_01=0;
        pb1_data_in_req1_r2_23=0;
        pb1_data_in_req2_r2_23=0;
        pb1_data_in_req3_r2_23=0;
        pb1_data_in_req1_r3_01=0;
        pb1_data_in_req2_r3_01=0;
        pb1_data_in_req3_r3_01=0;
        pb1_data_in_req1_r3_23=0;
        pb1_data_in_req2_r3_23=0;
        pb1_data_in_req3_r3_23=0;
        pb1_data_in_req1_c0_01=0;
        pb1_data_in_req2_c0_01=0;
        pb1_data_in_req3_c0_01=0;
        pb1_data_in_req1_c0_23=0;
        pb1_data_in_req2_c0_23=0;
        pb1_data_in_req3_c0_23=0;
        pb1_data_in_req1_c1_01=0;
        pb1_data_in_req2_c1_01=0;
        pb1_data_in_req3_c1_01=0;
        pb1_data_in_req1_c1_23=0;
        pb1_data_in_req2_c1_23=0;
        pb1_data_in_req3_c1_23=0;
        pb1_data_in_req1_c2_01=0;
        pb1_data_in_req2_c2_01=0;
        pb1_data_in_req3_c2_01=0;
        pb1_data_in_req1_c2_23=0;
        pb1_data_in_req2_c2_23=0;
        pb1_data_in_req3_c2_23=0;
        pb1_data_in_req1_c3_01=0;
        pb1_data_in_req2_c3_01=0;
        pb1_data_in_req3_c3_01=0;
        pb1_data_in_req1_c3_23=0;
        pb1_data_in_req2_c3_23=0;
        pb1_data_in_req3_c3_23=0;
        pb1_data_in_req1_r0=0;
        pb1_data_in_req2_r0=0;
        pb1_data_in_req1_r1=0;
        pb1_data_in_req2_r1=0;
        pb1_data_in_req1_r2=0;
        pb1_data_in_req2_r2=0;
        pb1_data_in_req1_r3=0;
        pb1_data_in_req2_r3=0;
        pb1_data_in_req1_c0=0;
        pb1_data_in_req2_c0=0;
        pb1_data_in_req1_c1=0;
        pb1_data_in_req2_c1=0;
        pb1_data_in_req1_c2=0;
        pb1_data_in_req2_c2=0;
        pb1_data_in_req1_c3=0;
        pb1_data_in_req2_c3=0;
        pb1_data_in_req_NI1_00=0;
        pb1_data_in_req_NI2_00=0;
        pb1_data_in_req_NI1_01=0;
        pb1_data_in_req_NI2_01=0;
        pb1_data_in_req_NI1_02=0;
        pb1_data_in_req_NI2_02=0;
        pb1_data_in_req_NI1_03=0;
        pb1_data_in_req_NI2_03=0;
        pb1_data_in_req_NI1_10=0;
        pb1_data_in_req_NI2_10=0;
        pb1_data_in_req_NI1_11=0;
        pb1_data_in_req_NI2_11=0;
        pb1_data_in_req_NI1_12=0;
        pb1_data_in_req_NI2_12=0;
        pb1_data_in_req_NI1_13=0;
        pb1_data_in_req_NI2_13=0;
        pb1_data_in_req_NI1_20=0;
        pb1_data_in_req_NI2_20=0;
        pb1_data_in_req_NI1_21=0;
        pb1_data_in_req_NI2_21=0;
        pb1_data_in_req_NI1_22=0;
        pb1_data_in_req_NI2_22=0;
        pb1_data_in_req_NI1_23=0;
        pb1_data_in_req_NI2_23=0;
        pb1_data_in_req_NI1_30=0;
        pb1_data_in_req_NI2_30=0;
        pb1_data_in_req_NI1_31=0;
        pb1_data_in_req_NI2_31=0;
        pb1_data_in_req_NI1_32=0;
        pb1_data_in_req_NI2_32=0;
        pb1_data_in_req_NI1_33=0;
        pb1_data_in_req_NI2_33=0;

        sp_out_val1_00=0;
        sp_out_val2_00=0;
        sp_out_val3_00=0;
        sp_out_val4_00=0;
        sp_out_val1_01=0;
        sp_out_val2_01=0;
        sp_out_val3_01=0;
        sp_out_val4_01=0;
        sp_out_val1_02=0;
        sp_out_val2_02=0;
        sp_out_val3_02=0;
        sp_out_val4_02=0;
        sp_out_val1_03=0;
        sp_out_val2_03=0;
        sp_out_val3_03=0;
        sp_out_val4_03=0;
        sp_out_val1_10=0;
        sp_out_val2_10=0;
        sp_out_val3_10=0;
        sp_out_val4_10=0;
        sp_out_val1_11=0;
        sp_out_val2_11=0;
        sp_out_val3_11=0;
        sp_out_val4_11=0;
        sp_out_val1_12=0;
        sp_out_val2_12=0;
        sp_out_val3_12=0;
        sp_out_val4_12=0;
        sp_out_val1_13=0;
        sp_out_val2_13=0;
        sp_out_val3_13=0;
        sp_out_val4_13=0;
        sp_out_val1_20=0;
        sp_out_val2_20=0;
        sp_out_val3_20=0;
        sp_out_val4_20=0;
        sp_out_val1_21=0;
        sp_out_val2_21=0;
        sp_out_val3_21=0;
        sp_out_val4_21=0;
        sp_out_val1_22=0;
        sp_out_val2_22=0;
        sp_out_val3_22=0;
        sp_out_val4_22=0;
        sp_out_val1_23=0;
        sp_out_val2_23=0;
        sp_out_val3_23=0;
        sp_out_val4_23=0;
        sp_out_val1_30=0;
        sp_out_val2_30=0;
        sp_out_val3_30=0;
        sp_out_val4_30=0;
        sp_out_val1_31=0;
        sp_out_val2_31=0;
        sp_out_val3_31=0;
        sp_out_val4_31=0;
        sp_out_val1_32=0;
        sp_out_val2_32=0;
        sp_out_val3_32=0;
        sp_out_val4_32=0;
        sp_out_val1_33=0;
        sp_out_val2_33=0;
        sp_out_val3_33=0;
        sp_out_val4_33=0;
        sp_out_val1_r0_01=0;
        sp_out_val2_r0_01=0;
        sp_out_val3_r0_01=0;
        sp_out_val1_r0_23=0;
        sp_out_val2_r0_23=0;
        sp_out_val3_r0_23=0;
        sp_out_val1_r1_01=0;
        sp_out_val2_r1_01=0;
        sp_out_val3_r1_01=0;
        sp_out_val1_r1_23=0;
        sp_out_val2_r1_23=0;
        sp_out_val3_r1_23=0;
        sp_out_val1_r2_01=0;
        sp_out_val2_r2_01=0;
        sp_out_val3_r2_01=0;
        sp_out_val1_r2_23=0;
        sp_out_val2_r2_23=0;
        sp_out_val3_r2_23=0;
        sp_out_val1_r3_01=0;
        sp_out_val2_r3_01=0;
        sp_out_val3_r3_01=0;
        sp_out_val1_r3_23=0;
        sp_out_val2_r3_23=0;
        sp_out_val3_r3_23=0;
        sp_out_val1_c0_01=0;
        sp_out_val2_c0_01=0;
        sp_out_val3_c0_01=0;
        sp_out_val1_c0_23=0;
        sp_out_val2_c0_23=0;
        sp_out_val3_c0_23=0;
        sp_out_val1_c1_01=0;
        sp_out_val2_c1_01=0;
        sp_out_val3_c1_01=0;
        sp_out_val1_c1_23=0;
        sp_out_val2_c1_23=0;
        sp_out_val3_c1_23=0;
        sp_out_val1_c2_01=0;
        sp_out_val2_c2_01=0;
        sp_out_val3_c2_01=0;
        sp_out_val1_c2_23=0;
        sp_out_val2_c2_23=0;
        sp_out_val3_c2_23=0;
        sp_out_val1_c3_01=0;
        sp_out_val2_c3_01=0;
        sp_out_val3_c3_01=0;
        sp_out_val1_c3_23=0;
        sp_out_val2_c3_23=0;
        sp_out_val3_c3_23=0;
        sp_out_val1_r0=0;
        sp_out_val2_r0=0;
        sp_out_val1_r1=0;
        sp_out_val2_r1=0;
        sp_out_val1_r2=0;
        sp_out_val2_r2=0;
        sp_out_val1_r3=0;
        sp_out_val2_r3=0;
        sp_out_val1_c0=0;
        sp_out_val2_c0=0;
        sp_out_val1_c1=0;
        sp_out_val2_c1=0;
        sp_out_val1_c2=0;
        sp_out_val2_c2=0;
        sp_out_val1_c3=0;
        sp_out_val2_c3=0;
        sp_data_valid1_00=0;
        sp_data_valid2_00=0;
        sp_data_valid1_01=0;
        sp_data_valid2_01=0;
        sp_data_valid1_02=0;
        sp_data_valid2_02=0;
        sp_data_valid1_03=0;
        sp_data_valid2_03=0;
        sp_data_valid1_10=0;
        sp_data_valid2_10=0;
        sp_data_valid1_11=0;
        sp_data_valid2_11=0;
        sp_data_valid1_12=0;
        sp_data_valid2_12=0;
        sp_data_valid1_13=0;
        sp_data_valid2_13=0;
        sp_data_valid1_20=0;
        sp_data_valid2_20=0;
        sp_data_valid1_21=0;
        sp_data_valid2_21=0;
        sp_data_valid1_22=0;
        sp_data_valid2_22=0;
        sp_data_valid1_23=0;
        sp_data_valid2_23=0;
        sp_data_valid1_30=0;
        sp_data_valid2_30=0;
        sp_data_valid1_31=0;
        sp_data_valid2_31=0;
        sp_data_valid1_32=0;
        sp_data_valid2_32=0;
        sp_data_valid1_33=0;
        sp_data_valid2_33=0;

        pb1_out_val1_00=0;
        pb1_out_val2_00=0;
        pb1_out_val3_00=0;
        pb1_out_val4_00=0;
        pb1_out_val1_01=0;
        pb1_out_val2_01=0;
        pb1_out_val3_01=0;
        pb1_out_val4_01=0;
        pb1_out_val1_02=0;
        pb1_out_val2_02=0;
        pb1_out_val3_02=0;
        pb1_out_val4_02=0;
        pb1_out_val1_03=0;
        pb1_out_val2_03=0;
        pb1_out_val3_03=0;
        pb1_out_val4_03=0;
        pb1_out_val1_10=0;
        pb1_out_val2_10=0;
        pb1_out_val3_10=0;
        pb1_out_val4_10=0;
        pb1_out_val1_11=0;
        pb1_out_val2_11=0;
        pb1_out_val3_11=0;
        pb1_out_val4_11=0;
        pb1_out_val1_12=0;
        pb1_out_val2_12=0;
        pb1_out_val3_12=0;
        pb1_out_val4_12=0;
        pb1_out_val1_13=0;
        pb1_out_val2_13=0;
        pb1_out_val3_13=0;
        pb1_out_val4_13=0;
        pb1_out_val1_20=0;
        pb1_out_val2_20=0;
        pb1_out_val3_20=0;
        pb1_out_val4_20=0;
        pb1_out_val1_21=0;
        pb1_out_val2_21=0;
        pb1_out_val3_21=0;
        pb1_out_val4_21=0;
        pb1_out_val1_22=0;
        pb1_out_val2_22=0;
        pb1_out_val3_22=0;
        pb1_out_val4_22=0;
        pb1_out_val1_23=0;
        pb1_out_val2_23=0;
        pb1_out_val3_23=0;
        pb1_out_val4_23=0;
        pb1_out_val1_30=0;
        pb1_out_val2_30=0;
        pb1_out_val3_30=0;
        pb1_out_val4_30=0;
        pb1_out_val1_31=0;
        pb1_out_val2_31=0;
        pb1_out_val3_31=0;
        pb1_out_val4_31=0;
        pb1_out_val1_32=0;
        pb1_out_val2_32=0;
        pb1_out_val3_32=0;
        pb1_out_val4_32=0;
        pb1_out_val1_33=0;
        pb1_out_val2_33=0;
        pb1_out_val3_33=0;
        pb1_out_val4_33=0;
        pb1_out_val1_r0_01=0;
        pb1_out_val2_r0_01=0;
        pb1_out_val3_r0_01=0;
        pb1_out_val1_r0_23=0;
        pb1_out_val2_r0_23=0;
        pb1_out_val3_r0_23=0;
        pb1_out_val1_r1_01=0;
        pb1_out_val2_r1_01=0;
        pb1_out_val3_r1_01=0;
        pb1_out_val1_r1_23=0;
        pb1_out_val2_r1_23=0;
        pb1_out_val3_r1_23=0;
        pb1_out_val1_r2_01=0;
        pb1_out_val2_r2_01=0;
        pb1_out_val3_r2_01=0;
        pb1_out_val1_r2_23=0;
        pb1_out_val2_r2_23=0;
        pb1_out_val3_r2_23=0;
        pb1_out_val1_r3_01=0;
        pb1_out_val2_r3_01=0;
        pb1_out_val3_r3_01=0;
        pb1_out_val1_r3_23=0;
        pb1_out_val2_r3_23=0;
        pb1_out_val3_r3_23=0;
        pb1_out_val1_c0_01=0;
        pb1_out_val2_c0_01=0;
        pb1_out_val3_c0_01=0;
        pb1_out_val1_c0_23=0;
        pb1_out_val2_c0_23=0;
        pb1_out_val3_c0_23=0;
        pb1_out_val1_c1_01=0;
        pb1_out_val2_c1_01=0;
        pb1_out_val3_c1_01=0;
        pb1_out_val1_c1_23=0;
        pb1_out_val2_c1_23=0;
        pb1_out_val3_c1_23=0;
        pb1_out_val1_c2_01=0;
        pb1_out_val2_c2_01=0;
        pb1_out_val3_c2_01=0;
        pb1_out_val1_c2_23=0;
        pb1_out_val2_c2_23=0;
        pb1_out_val3_c2_23=0;
        pb1_out_val1_c3_01=0;
        pb1_out_val2_c3_01=0;
        pb1_out_val3_c3_01=0;
        pb1_out_val1_c3_23=0;
        pb1_out_val2_c3_23=0;
        pb1_out_val3_c3_23=0;
        pb1_out_val1_r0=0;
        pb1_out_val2_r0=0;
        pb1_out_val1_r1=0;
        pb1_out_val2_r1=0;
        pb1_out_val1_r2=0;
        pb1_out_val2_r2=0;
        pb1_out_val1_r3=0;
        pb1_out_val2_r3=0;
        pb1_out_val1_c0=0;
        pb1_out_val2_c0=0;
        pb1_out_val1_c1=0;
        pb1_out_val2_c1=0;
        pb1_out_val1_c2=0;
        pb1_out_val2_c2=0;
        pb1_out_val1_c3=0;
        pb1_out_val2_c3=0;
        pb1_data_valid1_00=0;
        pb1_data_valid2_00=0;
        pb1_data_valid1_01=0;
        pb1_data_valid2_01=0;
        pb1_data_valid1_02=0;
        pb1_data_valid2_02=0;
        pb1_data_valid1_03=0;
        pb1_data_valid2_03=0;
        pb1_data_valid1_10=0;
        pb1_data_valid2_10=0;
        pb1_data_valid1_11=0;
        pb1_data_valid2_11=0;
        pb1_data_valid1_12=0;
        pb1_data_valid2_12=0;
        pb1_data_valid1_13=0;
        pb1_data_valid2_13=0;
        pb1_data_valid1_20=0;
        pb1_data_valid2_20=0;
        pb1_data_valid1_21=0;
        pb1_data_valid2_21=0;
        pb1_data_valid1_22=0;
        pb1_data_valid2_22=0;
        pb1_data_valid1_23=0;
        pb1_data_valid2_23=0;
        pb1_data_valid1_30=0;
        pb1_data_valid2_30=0;
        pb1_data_valid1_31=0;
        pb1_data_valid2_31=0;
        pb1_data_valid1_32=0;
        pb1_data_valid2_32=0;
        pb1_data_valid1_33=0;
        pb1_data_valid2_33=0;

        Lg_router_out1_00=0;
        Lg_router_out2_00=0;
        Lg_router_out3_00=0;
        Lg_router_out4_00=0;
        Lg_router_out1_01=0;
        Lg_router_out2_01=0;
        Lg_router_out3_01=0;
        Lg_router_out4_01=0;
        Lg_router_out1_02=0;
        Lg_router_out2_02=0;
        Lg_router_out3_02=0;
        Lg_router_out4_02=0;
        Lg_router_out1_03=0;
        Lg_router_out2_03=0;
        Lg_router_out3_03=0;
        Lg_router_out4_03=0;
        Lg_router_out1_10=0;
        Lg_router_out2_10=0;
        Lg_router_out3_10=0;
        Lg_router_out4_10=0;
        Lg_router_out1_11=0;
        Lg_router_out2_11=0;
        Lg_router_out3_11=0;
        Lg_router_out4_11=0;
        Lg_router_out1_12=0;
        Lg_router_out2_12=0;
        Lg_router_out3_12=0;
        Lg_router_out4_12=0;
        Lg_router_out1_13=0;
        Lg_router_out2_13=0;
        Lg_router_out3_13=0;
        Lg_router_out4_13=0;
        Lg_router_out1_20=0;
        Lg_router_out2_20=0;
        Lg_router_out3_20=0;
        Lg_router_out4_20=0;
        Lg_router_out1_21=0;
        Lg_router_out2_21=0;
        Lg_router_out3_21=0;
        Lg_router_out4_21=0;
        Lg_router_out1_22=0;
        Lg_router_out2_22=0;
        Lg_router_out3_22=0;
        Lg_router_out4_22=0;
        Lg_router_out1_23=0;
        Lg_router_out2_23=0;
        Lg_router_out3_23=0;
        Lg_router_out4_23=0;
        Lg_router_out1_30=0;
        Lg_router_out2_30=0;
        Lg_router_out3_30=0;
        Lg_router_out4_30=0;
        Lg_router_out1_31=0;
        Lg_router_out2_31=0;
        Lg_router_out3_31=0;
        Lg_router_out4_31=0;
        Lg_router_out1_32=0;
        Lg_router_out2_32=0;
        Lg_router_out3_32=0;
        Lg_router_out4_32=0;
        Lg_router_out1_33=0;
        Lg_router_out2_33=0;
        Lg_router_out3_33=0;
        Lg_router_out4_33=0;
        Lg_router_out1_r0_01=0;
        Lg_router_out2_r0_01=0;
        Lg_router_out3_r0_01=0;
        Lg_router_out1_r0_23=0;
        Lg_router_out2_r0_23=0;
        Lg_router_out3_r0_23=0;
        Lg_router_out1_r1_01=0;
        Lg_router_out2_r1_01=0;
        Lg_router_out3_r1_01=0;
        Lg_router_out1_r1_23=0;
        Lg_router_out2_r1_23=0;
        Lg_router_out3_r1_23=0;
        Lg_router_out1_r2_01=0;
        Lg_router_out2_r2_01=0;
        Lg_router_out3_r2_01=0;
        Lg_router_out1_r2_23=0;
        Lg_router_out2_r2_23=0;
        Lg_router_out3_r2_23=0;
        Lg_router_out1_r3_01=0;
        Lg_router_out2_r3_01=0;
        Lg_router_out3_r3_01=0;
        Lg_router_out1_r3_23=0;
        Lg_router_out2_r3_23=0;
        Lg_router_out3_r3_23=0;
        Lg_router_out1_c0_01=0;
        Lg_router_out2_c0_01=0;
        Lg_router_out3_c0_01=0;
        Lg_router_out1_c0_23=0;
        Lg_router_out2_c0_23=0;
        Lg_router_out3_c0_23=0;
        Lg_router_out1_c1_01=0;
        Lg_router_out2_c1_01=0;
        Lg_router_out3_c1_01=0;
        Lg_router_out1_c1_23=0;
        Lg_router_out2_c1_23=0;
        Lg_router_out3_c1_23=0;
        Lg_router_out1_c2_01=0;
        Lg_router_out2_c2_01=0;
        Lg_router_out3_c2_01=0;
        Lg_router_out1_c2_23=0;
        Lg_router_out2_c2_23=0;
        Lg_router_out3_c2_23=0;
        Lg_router_out1_c3_01=0;
        Lg_router_out2_c3_01=0;
        Lg_router_out3_c3_01=0;
        Lg_router_out1_c3_23=0;
        Lg_router_out2_c3_23=0;
        Lg_router_out3_c3_23=0;
        Lg_data_out1_r0=0;
        Lg_data_out2_r0=0;
        Lg_data_out1_r1=0;
        Lg_data_out2_r1=0;
        Lg_data_out1_r2=0;
        Lg_data_out2_r2=0;
        Lg_data_out1_r3=0;
        Lg_data_out2_r3=0;
        Lg_data_out1_c0=0;
        Lg_data_out2_c0=0;
        Lg_data_out1_c1=0;
        Lg_data_out2_c1=0;
        Lg_data_out1_c2=0;
        Lg_data_out2_c2=0;
        Lg_data_out1_c3=0;
        Lg_data_out2_c3=0;
        Lg_packet_out1_00=0;
        Lg_packet_out2_00=0;
        Lg_packet_out1_01=0;
        Lg_packet_out2_01=0;
        Lg_packet_out1_02=0;
        Lg_packet_out2_02=0;
        Lg_packet_out1_03=0;
        Lg_packet_out2_03=0;
        Lg_packet_out1_10=0;
        Lg_packet_out2_10=0;
        Lg_packet_out1_11=0;
        Lg_packet_out2_11=0;
        Lg_packet_out1_12=0;
        Lg_packet_out2_12=0;
        Lg_packet_out1_13=0;
        Lg_packet_out2_13=0;
        Lg_packet_out1_20=0;
        Lg_packet_out2_20=0;
        Lg_packet_out1_21=0;
        Lg_packet_out2_21=0;
        Lg_packet_out1_22=0;
        Lg_packet_out2_22=0;
        Lg_packet_out1_23=0;
        Lg_packet_out2_23=0;
        Lg_packet_out1_30=0;
        Lg_packet_out2_30=0;
        Lg_packet_out1_31=0;
        Lg_packet_out2_31=0;
        Lg_packet_out1_32=0;
        Lg_packet_out2_32=0;
        Lg_packet_out1_33=0;
        Lg_packet_out2_33=0;

        Cc_router_out1_00=0;
        Cc_router_out2_00=0;
        Cc_router_out3_00=0;
        Cc_router_out4_00=0;
        Cc_router_out1_01=0;
        Cc_router_out2_01=0;
        Cc_router_out3_01=0;
        Cc_router_out4_01=0;
        Cc_router_out1_02=0;
        Cc_router_out2_02=0;
        Cc_router_out3_02=0;
        Cc_router_out4_02=0;
        Cc_router_out1_03=0;
        Cc_router_out2_03=0;
        Cc_router_out3_03=0;
        Cc_router_out4_03=0;
        Cc_router_out1_10=0;
        Cc_router_out2_10=0;
        Cc_router_out3_10=0;
        Cc_router_out4_10=0;
        Cc_router_out1_11=0;
        Cc_router_out2_11=0;
        Cc_router_out3_11=0;
        Cc_router_out4_11=0;
        Cc_router_out1_12=0;
        Cc_router_out2_12=0;
        Cc_router_out3_12=0;
        Cc_router_out4_12=0;
        Cc_router_out1_13=0;
        Cc_router_out2_13=0;
        Cc_router_out3_13=0;
        Cc_router_out4_13=0;
        Cc_router_out1_20=0;
        Cc_router_out2_20=0;
        Cc_router_out3_20=0;
        Cc_router_out4_20=0;
        Cc_router_out1_21=0;
        Cc_router_out2_21=0;
        Cc_router_out3_21=0;
        Cc_router_out4_21=0;
        Cc_router_out1_22=0;
        Cc_router_out2_22=0;
        Cc_router_out3_22=0;
        Cc_router_out4_22=0;
        Cc_router_out1_23=0;
        Cc_router_out2_23=0;
        Cc_router_out3_23=0;
        Cc_router_out4_23=0;
        Cc_router_out1_30=0;
        Cc_router_out2_30=0;
        Cc_router_out3_30=0;
        Cc_router_out4_30=0;
        Cc_router_out1_31=0;
        Cc_router_out2_31=0;
        Cc_router_out3_31=0;
        Cc_router_out4_31=0;
        Cc_router_out1_32=0;
        Cc_router_out2_32=0;
        Cc_router_out3_32=0;
        Cc_router_out4_32=0;
        Cc_router_out1_33=0;
        Cc_router_out2_33=0;
        Cc_router_out3_33=0;
        Cc_router_out4_33=0;
        Cc_router_out1_r0_01=0;
        Cc_router_out2_r0_01=0;
        Cc_router_out3_r0_01=0;
        Cc_router_out1_r0_23=0;
        Cc_router_out2_r0_23=0;
        Cc_router_out3_r0_23=0;
        Cc_router_out1_r1_01=0;
        Cc_router_out2_r1_01=0;
        Cc_router_out3_r1_01=0;
        Cc_router_out1_r1_23=0;
        Cc_router_out2_r1_23=0;
        Cc_router_out3_r1_23=0;
        Cc_router_out1_r2_01=0;
        Cc_router_out2_r2_01=0;
        Cc_router_out3_r2_01=0;
        Cc_router_out1_r2_23=0;
        Cc_router_out2_r2_23=0;
        Cc_router_out3_r2_23=0;
        Cc_router_out1_r3_01=0;
        Cc_router_out2_r3_01=0;
        Cc_router_out3_r3_01=0;
        Cc_router_out1_r3_23=0;
        Cc_router_out2_r3_23=0;
        Cc_router_out3_r3_23=0;
        Cc_router_out1_c0_01=0;
        Cc_router_out2_c0_01=0;
        Cc_router_out3_c0_01=0;
        Cc_router_out1_c0_23=0;
        Cc_router_out2_c0_23=0;
        Cc_router_out3_c0_23=0;
        Cc_router_out1_c1_01=0;
        Cc_router_out2_c1_01=0;
        Cc_router_out3_c1_01=0;
        Cc_router_out1_c1_23=0;
        Cc_router_out2_c1_23=0;
        Cc_router_out3_c1_23=0;
        Cc_router_out1_c2_01=0;
        Cc_router_out2_c2_01=0;
        Cc_router_out3_c2_01=0;
        Cc_router_out1_c2_23=0;
        Cc_router_out2_c2_23=0;
        Cc_router_out3_c2_23=0;
        Cc_router_out1_c3_01=0;
        Cc_router_out2_c3_01=0;
        Cc_router_out3_c3_01=0;
        Cc_router_out1_c3_23=0;
        Cc_router_out2_c3_23=0;
        Cc_router_out3_c3_23=0;
        Cc_data_out1_r0=0;
        Cc_data_out2_r0=0;
        Cc_data_out1_r1=0;
        Cc_data_out2_r1=0;
        Cc_data_out1_r2=0;
        Cc_data_out2_r2=0;
        Cc_data_out1_r3=0;
        Cc_data_out2_r3=0;
        Cc_data_out1_c0=0;
        Cc_data_out2_c0=0;
        Cc_data_out1_c1=0;
        Cc_data_out2_c1=0;
        Cc_data_out1_c2=0;
        Cc_data_out2_c2=0;
        Cc_data_out1_c3=0;
        Cc_data_out2_c3=0;
        Cc_packet_out1_00=0;
        Cc_packet_out2_00=0;
        Cc_packet_out1_01=0;
        Cc_packet_out2_01=0;
        Cc_packet_out1_02=0;
        Cc_packet_out2_02=0;
        Cc_packet_out1_03=0;
        Cc_packet_out2_03=0;
        Cc_packet_out1_10=0;
        Cc_packet_out2_10=0;
        Cc_packet_out1_11=0;
        Cc_packet_out2_11=0;
        Cc_packet_out1_12=0;
        Cc_packet_out2_12=0;
        Cc_packet_out1_13=0;
        Cc_packet_out2_13=0;
        Cc_packet_out1_20=0;
        Cc_packet_out2_20=0;
        Cc_packet_out1_21=0;
        Cc_packet_out2_21=0;
        Cc_packet_out1_22=0;
        Cc_packet_out2_22=0;
        Cc_packet_out1_23=0;
        Cc_packet_out2_23=0;
        Cc_packet_out1_30=0;
        Cc_packet_out2_30=0;
        Cc_packet_out1_31=0;
        Cc_packet_out2_31=0;
        Cc_packet_out1_32=0;
        Cc_packet_out2_32=0;
        Cc_packet_out1_33=0;
        Cc_packet_out2_33=0;

         fLg[0]=43.3593/19.0916;fLgz[0]=fLg[0];
         fLg[1]=20.9380/19.0916;fLgz[1]=fLg[1];
         fLg[2]=19.457/19.0916;fLgz[2]=fLg[2];
         for(i=3;i<63;i++)
            fLg[i]=1;
         //fLg[29]=fLg[2];
         //fLg[30]=fLg[1];
         for(i=3;i<31;i++)
            fLgz[i]=1;
         fLg[63]=fLg[2];
         fLgz[31]=fLgz[2];
         fLg_x=fLg[1];
         fLg_y=fLg[0];


        
        SC_METHOD(router_00_process);
        sensitive << router_clk_00.pos();



        SC_METHOD(router_01_process);
        sensitive << router_clk_01.pos();



        SC_METHOD(router_02_process);
        sensitive << router_clk_02.pos();



        SC_METHOD(router_03_process);
        sensitive << router_clk_03.pos();



        SC_METHOD(router_10_process);
        sensitive << router_clk_10.pos();



        SC_METHOD(router_11_process);
        sensitive << router_clk_11.pos();



        SC_METHOD(router_12_process);
        sensitive << router_clk_12.pos();



        SC_METHOD(router_13_process);
        sensitive << router_clk_13.pos();



        SC_METHOD(router_20_process);
        sensitive << router_clk_20.pos();



        SC_METHOD(router_21_process);
        sensitive << router_clk_21.pos();



        SC_METHOD(router_22_process);
        sensitive << router_clk_22.pos();



        SC_METHOD(router_23_process);
        sensitive << router_clk_23.pos();



        SC_METHOD(router_30_process);
        sensitive << router_clk_30.pos();



        SC_METHOD(router_31_process);
        sensitive << router_clk_31.pos();



        SC_METHOD(router_32_process);
        sensitive << router_clk_32.pos();



        SC_METHOD(router_33_process);
        sensitive << router_clk_33.pos();



        SC_METHOD(router_r0_01_process);
        sensitive << router_clk_r0_01.pos();



        SC_METHOD(router_r0_23_process);
        sensitive << router_clk_r0_23.pos();



        SC_METHOD(router_r1_01_process);
        sensitive << router_clk_r1_01.pos();



        SC_METHOD(router_r1_23_process);
        sensitive << router_clk_r1_23.pos();



        SC_METHOD(router_r2_01_process);
        sensitive << router_clk_r2_01.pos();



        SC_METHOD(router_r2_23_process);
        sensitive << router_clk_r2_23.pos();



        SC_METHOD(router_r3_01_process);
        sensitive << router_clk_r3_01.pos();



        SC_METHOD(router_r3_23_process);
        sensitive << router_clk_r3_23.pos();



        SC_METHOD(router_c0_01_process);
        sensitive << router_clk_c0_01.pos();



        SC_METHOD(router_c0_23_process);
        sensitive << router_clk_c0_23.pos();



        SC_METHOD(router_c1_01_process);
        sensitive << router_clk_c1_01.pos();



        SC_METHOD(router_c1_23_process);
        sensitive << router_clk_c1_23.pos();



        SC_METHOD(router_c2_01_process);
        sensitive << router_clk_c2_01.pos();



        SC_METHOD(router_c2_23_process);
        sensitive << router_clk_c2_23.pos();



        SC_METHOD(router_c3_01_process);
        sensitive << router_clk_c3_01.pos();



        SC_METHOD(router_c3_23_process);
        sensitive << router_clk_c3_23.pos();



        SC_METHOD(router_r0_process);
        sensitive << router_clk_r0.pos();



        SC_METHOD(router_r1_process);
        sensitive << router_clk_r1.pos();



        SC_METHOD(router_r2_process);
        sensitive << router_clk_r2.pos();



        SC_METHOD(router_r3_process);
        sensitive << router_clk_r3.pos();



        SC_METHOD(router_c0_process);
        sensitive << router_clk_c0.pos();



        SC_METHOD(router_c1_process);
        sensitive << router_clk_c1.pos();



        SC_METHOD(router_c2_process);
        sensitive << router_clk_c2.pos();



        SC_METHOD(router_c3_process);
        sensitive << router_clk_c3.pos();



        SC_METHOD(packet_1_00_process);
        sensitive  << clk_core1_00.pos();



        SC_METHOD(packet_2_00_process);
        sensitive  << clk_core2_00.pos();



        SC_METHOD(packet_1_01_process);
        sensitive  << clk_core1_01.pos();



        SC_METHOD(packet_2_01_process);
        sensitive  << clk_core2_01.pos();



        SC_METHOD(packet_1_02_process);
        sensitive  << clk_core1_02.pos();



        SC_METHOD(packet_2_02_process);
        sensitive  << clk_core2_02.pos();



        SC_METHOD(packet_1_03_process);
        sensitive  << clk_core1_03.pos();



        SC_METHOD(packet_2_03_process);
        sensitive  << clk_core2_03.pos();



        SC_METHOD(packet_1_10_process);
        sensitive  << clk_core1_10.pos();



        SC_METHOD(packet_2_10_process);
        sensitive  << clk_core2_10.pos();



        SC_METHOD(packet_1_11_process);
        sensitive  << clk_core1_11.pos();



        SC_METHOD(packet_2_11_process);
        sensitive  << clk_core2_11.pos();



        SC_METHOD(packet_1_12_process);
        sensitive  << clk_core1_12.pos();



        SC_METHOD(packet_2_12_process);
        sensitive  << clk_core2_12.pos();



        SC_METHOD(packet_1_13_process);
        sensitive  << clk_core1_13.pos();



        SC_METHOD(packet_2_13_process);
        sensitive  << clk_core2_13.pos();



        SC_METHOD(packet_1_20_process);
        sensitive  << clk_core1_20.pos();



        SC_METHOD(packet_2_20_process);
        sensitive  << clk_core2_20.pos();



        SC_METHOD(packet_1_21_process);
        sensitive  << clk_core1_21.pos();



        SC_METHOD(packet_2_21_process);
        sensitive  << clk_core2_21.pos();



        SC_METHOD(packet_1_22_process);
        sensitive  << clk_core1_22.pos();



        SC_METHOD(packet_2_22_process);
        sensitive  << clk_core2_22.pos();



        SC_METHOD(packet_1_23_process);
        sensitive  << clk_core1_23.pos();



        SC_METHOD(packet_2_23_process);
        sensitive  << clk_core2_23.pos();



        SC_METHOD(packet_1_30_process);
        sensitive  << clk_core1_30.pos();



        SC_METHOD(packet_2_30_process);
        sensitive  << clk_core2_30.pos();



        SC_METHOD(packet_1_31_process);
        sensitive  << clk_core1_31.pos();



        SC_METHOD(packet_2_31_process);
        sensitive  << clk_core2_31.pos();



        SC_METHOD(packet_1_32_process);
        sensitive  << clk_core1_32.pos();



        SC_METHOD(packet_2_32_process);
        sensitive  << clk_core2_32.pos();



        SC_METHOD(packet_1_33_process);
        sensitive  << clk_core1_33.pos();



        SC_METHOD(packet_2_33_process);
        sensitive  << clk_core2_33.pos();

      }

 };
