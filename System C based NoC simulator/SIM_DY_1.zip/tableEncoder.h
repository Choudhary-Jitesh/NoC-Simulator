#ifndef eee
#define eee

#include "configParam.h"

SC_MODULE(encoder)
{	
	int total_link;
	sc_in<bool> *g;
	sc_out<sc_uint<LINK_BIT + VC_BIT> > encoded_addr;

	void encoder_process()
	{	
		sc_bv<LINK_BIT + VC_BIT> temp;

		int input_size, out_size, count, index;
			
		for(out_size = 0; out_size < LINK_BIT + VC_BIT; out_size++)
		{
			count = (int)pow(2.0,out_size);
			temp[out_size] = 0;

			for(index = count; index < MAX_VC*(total_link); index = input_size + count)
				for(input_size = index; input_size < MAX_VC*(total_link) && input_size < (index + count); input_size++)
					temp[out_size] |= g[input_size];
			
		}		
		encoded_addr.write(temp);
	}
	
	SC_HAS_PROCESS(encoder);	
	encoder(sc_module_name(nm), int total): sc_module(nm), total_link(total)
	{ //cout<<"here in encoder\n";
		g = new sc_in<bool>[MAX_VC*(total_link)];
	
		SC_METHOD(encoder_process);
		for(int input_size = 0; input_size < MAX_VC*(total_link); input_size++)
			sensitive << g[input_size];
	}

	~encoder()	{	delete[] g;	}			//*** destructor			

};

#endif
